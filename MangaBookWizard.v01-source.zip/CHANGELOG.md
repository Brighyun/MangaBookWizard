# Release notes

## Friendly Edition

- Rebuilt the Windows/macOS window around a simple drop → choose → create flow.
- Added the blue, cream, and black visual identity based on the wizard-book icon.
- Moved specialist controls behind **More choices** and rewrote their labels in plain language.
- Removed the unreliable page checker so it cannot interrupt or block conversions.
- Added preserved-layout EPUB-to-MOBI conversion for ordinary books.
- Added AniList manga recommendations plus r/manga, r/kindle, and r/MangaCollectors community links.
- Added an in-app Help & FAQ and an original written guide.
- Added a friendly completion message with a link to connect with Isaiah Lee on LinkedIn.
- Added native ZIP/CBZ/EPUB extraction and safer archive handling.
- Made wide two-page spreads rotate as one page by default on every reader profile.
- Made “Trim empty page borders” unchecked by default in the app and command-line engine.
- Preserved the spread choice through Webtoon mode and made drag-and-drop paths more reliable.
- Removed the unnecessary 7-Zip requirement for ordinary ZIP and CBZ files in the command-line workflow.
- Renamed the app, package artifacts, settings namespace, and desktop icons.

Earlier engine history is retained in version control and the ISC copyright notices remain in `LICENSE.txt`.
