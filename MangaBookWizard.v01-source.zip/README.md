# MangaBookWizard

<p align="center">
  <img src="icons/manga-book-wizard.png" width="180" alt="A white wizard hat resting on a graphite manga book">
</p>

**MangaBookWizard** is a friendly Windows and macOS app for preparing manga, comics, and EPUB books for e-readers. It is designed for people who do not want to learn conversion jargon: drop in a book, pick a reader, and let the Wizard do the careful work.

## The three-step recipe

1. **Drop in your book.** Use an EPUB, PDF, CBZ, ZIP, or a folder containing JPG/PNG pages.
2. **Pick your reader and finished file.** The plain-language choices explain what each format is for.
3. **Click “Make my book.”** The finished file is saved beside the original unless you choose another folder.

Helpful defaults are visible on the home screen. Less-common controls stay under **More choices**, so new users are not confronted with a wall of technical switches.

Wide two-page artwork is kept together and rotated by default on every reader profile. Readers can still choose split pages or split-and-rotate under **More choices**.

Empty-page border trimming starts turned off so the Wizard preserves the original page edges unless the reader enables it.

## What it can make

- **Kindle manga — best fit (MOBI):** optimized page-based manga and comics for Kindle.
- **Send to Kindle — EPUB:** a modern EPUB prepared for Amazon's Send to Kindle workflow.
- **EPUB book → older Kindle (MOBI):** converts an ordinary text EPUB while preserving its text, chapters, navigation, styles, and resources.
- **EPUB:** a widely supported e-book file.
- **CBZ:** a simple comic archive that keeps page images together.
- **PDF:** a portable, easy-to-share copy.

MOBI creation requires the tools included with [Amazon Kindle Previewer](https://kdp.amazon.com/en_US/help/topic/G202131170). EPUB, CBZ, ZIP, PDF, and page-folder workflows do not require it.

## Manga discovery and reader communities

- [AniList](https://anilist.co/) — manga recommendations and reading-list tracking.
- [r/manga](https://www.reddit.com/r/manga/) — manga discussion and recommendations.
- [r/kindle](https://www.reddit.com/r/kindle/) — Kindle help and reader discussion.
- [r/MangaCollectors](https://www.reddit.com/r/MangaCollectors/) — physical manga collecting and shelf inspiration.
- [Connect with Isaiah Lee on LinkedIn](https://www.linkedin.com/in/brigh-yun-lee-01130025b/).
- [Support MangaBookWizard on Buy Me a Coffee](https://buymeacoffee.com/mangabookwizard) — completely optional; every app feature remains free.

AniList and Reddit are recommendation/community links, not download sources. Only convert books you own or have permission to use.

## Help

The app includes a **Help & FAQ** button. The longer written guide is in [FAQ.md](FAQ.md).

## Running from source

Install the packages in `requirements.txt`, then run:

```console
python manga_book_wizard.py
```

Build the desktop app with:

```console
python setup.py build_binary
```

Automated Windows and macOS builds are included under `.github/workflows`.

### Mac compatibility

The macOS release workflow creates two separate downloads:

- **`MangaBookWizard.v01-macOS-ARM64`** for M-series Apple-silicon Macs.
- **`MangaBookWizard.v01-macOS-Intel-x86_64`** for older Intel Macs.

Both Mac builds target **macOS Monterey 12 or newer**, the oldest version supported by the current interface framework. The Intel build must be produced on the Intel GitHub runner; renaming the Apple-silicon download does not make it Intel-compatible.

## Open-source foundation

This edition keeps the ISC-licensed conversion foundation and its required copyright notices. See [LICENSE.txt](LICENSE.txt) for the original authors and license terms. The friendly product design, safety workflow, preserved-book converter, documentation, and community experience in this edition are maintained separately. This project is not endorsed by Amazon, AniList, Reddit, or LinkedIn; their names are used only to describe compatibility or link to their services.
