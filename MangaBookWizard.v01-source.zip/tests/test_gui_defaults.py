import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from PIL import Image
from PySide6.QtCore import Qt

from kindlecomicconverter import branding
from kindlecomicconverter.KCC_gui import default_gui_options, spread_splitter_mode
from kindlecomicconverter.image import ComicPageParser


class GuiDefaultsTests(unittest.TestCase):
    def test_support_link_is_shared_by_every_desktop_build(self):
        self.assertEqual(
            branding.BUY_ME_A_COFFEE_URL,
            'https://buymeacoffee.com/mangabookwizard',
        )
        gui_source = (Path(__file__).resolve().parents[1] / 'kindlecomicconverter' / 'KCC_gui.py').read_text()
        self.assertIn("QPushButton('Buy Me a Coffee'", gui_source)
        self.assertIn('GUI.supportButton.clicked.connect(self.openBuyMeACoffee)', gui_source)

    def test_official_name_and_matte_monochrome_theme(self):
        theme = branding.stylesheet(False)

        self.assertEqual(branding.APP_NAME, 'MangaBookWizard')
        for color in ('#0E0F10', '#18191A', '#F3F2EE', '#FAFAF7', '#111214'):
            self.assertIn(color, theme)
        for old_accent in ('#1749D1', '#2360F0', '#F7B928', '#FFF4E3'):
            self.assertNotIn(old_accent, theme)

    def test_windows_device_menu_has_readable_bounded_popup(self):
        theme = branding.stylesheet(False)
        gui_source = (Path(__file__).resolve().parents[1] / 'kindlecomicconverter' / 'KCC_gui.py').read_text()

        self.assertIn('QComboBox QAbstractItemView', theme)
        self.assertIn('selection-background-color: #292B2D', theme)
        self.assertIn("QPalette.ColorRole.Base, QColor('#FAFAF7')", gui_source)
        self.assertIn("QPalette.ColorRole.Text, QColor('#111214')", gui_source)
        self.assertIn("QPalette.ColorRole.Highlight, QColor('#292B2D')", gui_source)
        self.assertIn('box.setMaxVisibleItems(10)', gui_source)
        self.assertIn('configure_combo_popup(box)', gui_source)

    def test_page_checker_is_completely_removed(self):
        project = Path(__file__).resolve().parents[1]
        gui_source = (project / 'kindlecomicconverter' / 'KCC_gui.py').read_text()
        engine_source = (project / 'kindlecomicconverter' / 'comic2ebook.py').read_text()

        self.assertNotIn('preflight', gui_source.lower())
        self.assertNotIn('preflight', engine_source.lower())
        self.assertNotIn('blankPageScanBox', gui_source)
        self.assertFalse((project / 'kindlecomicconverter' / 'preflight.py').exists())

    def test_empty_page_border_trimming_is_off_on_first_run(self):
        self.assertEqual(
            default_gui_options()['croppingBox'],
            Qt.CheckState.Unchecked.value,
        )

    def test_double_page_spreads_rotate_on_first_run(self):
        self.assertEqual(
            default_gui_options()['rotateBox'],
            Qt.CheckState.Checked.value,
        )

    def test_spread_states_map_to_converter_modes(self):
        self.assertEqual(spread_splitter_mode(Qt.CheckState.Unchecked), 0)
        self.assertEqual(spread_splitter_mode(Qt.CheckState.PartiallyChecked), 2)
        self.assertEqual(spread_splitter_mode(Qt.CheckState.Checked), 1)

    def test_default_settings_are_not_shared_between_callers(self):
        first = default_gui_options()
        first['rotateBox'] = Qt.CheckState.Unchecked.value
        self.assertEqual(
            default_gui_options()['rotateBox'],
            Qt.CheckState.Checked.value,
        )

    def test_rotate_mode_keeps_a_wide_spread_together(self):
        with TemporaryDirectory() as directory:
            source = Path(directory, 'spread.png')
            Image.new('RGB', (1200, 600), 'white').save(source)
            options = SimpleNamespace(
                profileData=('Test reader', (800, 1200), None, 1.0),
                maximizestrips=False,
                webtoon=False,
                splitter=spread_splitter_mode(DEFAULT_CHECKED_STATE),
                norotate=False,
                rotateright=False,
                righttoleft=True,
                bordersColor=None,
            )

            parsed = ComicPageParser((directory, source.name), options)

            self.assertEqual(len(parsed.payload), 1)
            self.assertEqual(parsed.payload[0][0], 'R')
            self.assertEqual(parsed.payload[0][2].size, (600, 1200))


DEFAULT_CHECKED_STATE = Qt.CheckState.Checked


if __name__ == "__main__":
    unittest.main()
