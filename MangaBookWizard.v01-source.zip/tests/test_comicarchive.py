from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from zipfile import ZipFile

from kindlecomicconverter.comicarchive import ComicArchive


class ComicArchiveTests(unittest.TestCase):
    def test_builtin_zip_extraction(self):
        with TemporaryDirectory() as directory:
            source = Path(directory, "book.epub")
            output = Path(directory, "output")
            output.mkdir()
            with ZipFile(source, "w") as archive:
                archive.writestr("OEBPS/Text/page.xhtml", "<html/>")
            ComicArchive(str(source)).extract(str(output))
            self.assertEqual((output / "OEBPS/Text/page.xhtml").read_text(), "<html/>")

    def test_zip_traversal_is_rejected(self):
        with TemporaryDirectory() as directory:
            source = Path(directory, "unsafe.epub")
            output = Path(directory, "output")
            output.mkdir()
            with ZipFile(source, "w") as archive:
                archive.writestr("../escaped.txt", "nope")
            with self.assertRaises(OSError):
                ComicArchive(str(source)).extract(str(output))
            self.assertFalse(Path(directory, "escaped.txt").exists())


if __name__ == "__main__":
    unittest.main()
