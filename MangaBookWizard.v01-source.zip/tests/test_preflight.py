from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

from PIL import Image, ImageDraw

from kindlecomicconverter.preflight import scan_epub, scan_image_tree


CONTAINER = """<?xml version="1.0"?>
<container xmlns="urn:oasis:names:tc:opendocument:xmlns:container" version="1.0">
  <rootfiles><rootfile full-path="OEBPS/book.opf" media-type="application/oebps-package+xml"/></rootfiles>
</container>
"""


def image_bytes(blank=False):
    image = Image.new("RGB", (120, 160), "white")
    if not blank:
        draw = ImageDraw.Draw(image)
        draw.rectangle((15, 20, 105, 140), fill="black")
        draw.rectangle((25, 30, 95, 130), fill="white")
    output = BytesIO()
    image.save(output, "PNG")
    return output.getvalue()


def write_epub(path, *, missing_image=False, blank_image=False, text_only=False, case_mismatch=False):
    image_manifest = "" if text_only else '<item id="image" href="images/page.png" media-type="image/png"/>'
    opf = f"""<?xml version="1.0" encoding="UTF-8"?>
    <package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id">
      <metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">test</dc:identifier></metadata>
      <manifest><item id="page" href="text/page.xhtml" media-type="application/xhtml+xml"/>{image_manifest}</manifest>
      <spine><itemref idref="page"/></spine>
    </package>"""
    if text_only:
        page = '<html xmlns="http://www.w3.org/1999/xhtml"><body><p>A real chapter of text.</p></body></html>'
    else:
        image_name = "../Images/page.png" if case_mismatch else "../images/page.png"
        page = f'<html xmlns="http://www.w3.org/1999/xhtml"><body><img src="{image_name}"/></body></html>'
    with ZipFile(path, "w") as archive:
        archive.writestr("mimetype", "application/epub+zip", compress_type=ZIP_STORED)
        archive.writestr("META-INF/container.xml", CONTAINER, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/book.opf", opf, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/text/page.xhtml", page, compress_type=ZIP_DEFLATED)
        if not text_only and not missing_image:
            archive.writestr("OEBPS/images/page.png", image_bytes(blank_image), compress_type=ZIP_DEFLATED)


class PreflightTests(unittest.TestCase):
    def test_valid_image_epub_passes(self):
        with TemporaryDirectory() as directory:
            epub = Path(directory, "valid.epub")
            write_epub(epub)
            report = scan_epub(epub, "KPW6", "MOBI")
            self.assertFalse(report.errors, report.formatted())
            self.assertEqual(report.pages_checked, 1)
            self.assertEqual(report.images_checked, 1)

    def test_colorsoft_firmware_risk_is_reported(self):
        with TemporaryDirectory() as directory:
            epub = Path(directory, "colorsoft.epub")
            write_epub(epub, text_only=True)
            report = scan_epub(epub, "KCS", "MOBI-PASSTHROUGH")
            self.assertIn("COLORSOFT_FIRMWARE_RISK", {issue.code for issue in report.warnings})

    def test_missing_referenced_image_is_blocking(self):
        with TemporaryDirectory() as directory:
            epub = Path(directory, "missing.epub")
            write_epub(epub, missing_image=True)
            report = scan_epub(epub)
            self.assertIn("MISSING_IMAGE", {issue.code for issue in report.errors})

    def test_blank_image_is_reported_as_warning(self):
        with TemporaryDirectory() as directory:
            epub = Path(directory, "blank.epub")
            write_epub(epub, blank_image=True)
            report = scan_epub(epub)
            self.assertIn("BLANK_IMAGE", {issue.code for issue in report.warnings})

    def test_text_only_epub_is_not_treated_as_blank(self):
        with TemporaryDirectory() as directory:
            epub = Path(directory, "book.epub")
            write_epub(epub, text_only=True)
            report = scan_epub(epub)
            self.assertFalse(report.errors, report.formatted())
            self.assertNotIn("BLANK_SPINE_PAGE", {issue.code for issue in report.warnings})

    def test_case_mismatch_is_reported(self):
        with TemporaryDirectory() as directory:
            epub = Path(directory, "case.epub")
            write_epub(epub, case_mismatch=True)
            report = scan_epub(epub)
            self.assertIn("CASE_MISMATCH", {issue.code for issue in report.warnings})

    def test_corrupt_image_tree_is_blocking(self):
        with TemporaryDirectory() as directory:
            image = Path(directory, "page.png")
            image.write_bytes(b"not an image")
            report = scan_image_tree(directory)
            self.assertIn("CORRUPT_IMAGE", {issue.code for issue in report.errors})


if __name__ == "__main__":
    unittest.main()
