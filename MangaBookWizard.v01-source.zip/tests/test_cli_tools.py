from types import SimpleNamespace
import unittest

from kindlecomicconverter import comic2ebook


class CliToolChecksTests(unittest.TestCase):
    def test_empty_page_border_trimming_is_disabled_by_default(self):
        options = comic2ebook.makeParser().parse_args([])
        self.assertEqual(options.cropping, 0)

    def test_double_page_spreads_rotate_by_default(self):
        options = comic2ebook.makeParser().parse_args([])
        self.assertEqual(options.splitter, 1)

    def test_cbz_does_not_require_external_7zip(self):
        previous_options = getattr(comic2ebook, 'options', None)
        comic2ebook.options = SimpleNamespace(format='EPUB')
        try:
            comic2ebook.checkTools('manga.cbz')
        finally:
            if previous_options is None:
                del comic2ebook.options
            else:
                comic2ebook.options = previous_options


if __name__ == "__main__":
    unittest.main()
