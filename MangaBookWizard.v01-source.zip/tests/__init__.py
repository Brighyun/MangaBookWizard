"""Test package for the modernized desktop fork."""
