import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ReleaseConfigurationTests(unittest.TestCase):
    def test_macos_workflow_builds_apple_silicon_and_intel(self):
        workflow = (ROOT / '.github/workflows/package-macos.yml').read_text()

        self.assertIn('runner: macos-15\n', workflow)
        self.assertIn('runner: macos-15-intel\n', workflow)
        self.assertIn('architecture: arm64', workflow)
        self.assertIn('architecture: x86_64', workflow)
        self.assertIn('MangaBookWizard.v01-macOS-ARM64', workflow)
        self.assertIn('MangaBookWizard.v01-macOS-Intel-x86_64', workflow)

    def test_macos_build_targets_monterey_or_newer(self):
        workflow = (ROOT / '.github/workflows/package-macos.yml').read_text()
        spec = (ROOT / 'kcc-macos.spec').read_text()
        requirements = (ROOT / 'requirements.txt').read_text()

        self.assertIn('MACOSX_DEPLOYMENT_TARGET: "12.0"', workflow)
        self.assertIn("'LSMinimumSystemVersion': MINIMUM_MACOS_VERSION", spec)
        self.assertIn('numpy>=1.26.4,<2.0', requirements)
        self.assertIn('scripts/verify_macos_bundle.py', workflow)


if __name__ == '__main__':
    unittest.main()
