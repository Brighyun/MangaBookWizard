from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from kindlecomicconverter import comic2ebook
from tests.test_preflight import write_epub


class PassthroughTests(unittest.TestCase):
    def test_default_mobi_name_is_next_to_source(self):
        with TemporaryDirectory() as directory:
            source = Path(directory, "My Book.epub")
            source.touch()
            destination = comic2ebook.get_passthrough_destination(str(source), None)
            self.assertEqual(destination, str(Path(directory, "My Book.mobi").absolute()))

    def test_preserve_book_format_stages_original_epub(self):
        with TemporaryDirectory() as directory:
            source = Path(directory, "source.epub")
            output = Path(directory, "output")
            output.mkdir()
            write_epub(source, text_only=True)

            parser = comic2ebook.makeParser()
            parsed = parser.parse_args([
                "--profile", "KPW6",
                "--format", "MOBI-PASSTHROUGH",
                "--output", str(output),
                str(source),
            ])
            comic2ebook.options = comic2ebook.checkOptions(parsed)
            comic2ebook.GUI = None
            staged = comic2ebook.prepare_passthrough_epub(str(source))

            self.assertTrue(comic2ebook.options.epub_passthrough)
            self.assertEqual(comic2ebook.options.format, "MOBI")
            self.assertEqual(len(staged), 1)
            staged_path = Path(staged[0])
            self.assertEqual(staged_path.read_bytes(), source.read_bytes())
            self.assertEqual(
                comic2ebook.options.passthrough_destinations[str(staged_path)],
                str((output / "source.mobi").absolute()),
            )
            self.assertEqual(len(comic2ebook.options.covers), 1)
            staged_mobi = staged_path.with_suffix(".mobi")
            staged_mobi.write_bytes(b"fake mobi for movement test")
            original_fixer = comic2ebook.dualmetafix.DualMobiMetaFix
            comic2ebook.dualmetafix.DualMobiMetaFix = lambda *_args, **_kwargs: None
            try:
                result = comic2ebook.makeMOBIFix(str(staged_path), comic2ebook.options.uuid)
            finally:
                comic2ebook.dualmetafix.DualMobiMetaFix = original_fixer
            self.assertEqual(result, [True])
            self.assertEqual((output / "source.mobi").read_bytes(), b"fake mobi for movement test")
            self.assertFalse(staged_path.parent.exists())


if __name__ == "__main__":
    unittest.main()
