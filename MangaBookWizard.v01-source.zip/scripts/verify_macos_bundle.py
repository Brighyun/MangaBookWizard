#!/usr/bin/env python3
"""Verify the processor and oldest supported macOS version of an app bundle."""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path


MINIMUM_VERSION = re.compile(r"^\s+minos\s+(\d+(?:\.\d+){1,2})", re.MULTILINE)


def version_tuple(value: str) -> tuple[int, ...]:
    return tuple(int(part) for part in value.split('.'))


def command_output(*command: str) -> str:
    return subprocess.run(command, check=True, capture_output=True, text=True).stdout


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('app', type=Path)
    parser.add_argument('--architecture', required=True, choices=('arm64', 'x86_64'))
    parser.add_argument('--maximum-minimum-version', default='12.0')
    args = parser.parse_args()

    if not args.app.is_dir():
        parser.error(f'App bundle not found: {args.app}')

    maximum = version_tuple(args.maximum_minimum_version)
    checked = 0
    problems: list[str] = []

    for candidate in sorted(path for path in args.app.rglob('*') if path.is_file()):
        if 'Mach-O' not in command_output('file', str(candidate)):
            continue

        checked += 1
        architectures = command_output('lipo', '-archs', str(candidate)).split()
        if args.architecture not in architectures:
            problems.append(f'{candidate}: missing {args.architecture}; found {architectures}')
            continue

        build_info = command_output('vtool', '-show-build', str(candidate))
        for minimum in MINIMUM_VERSION.findall(build_info):
            if version_tuple(minimum) > maximum:
                problems.append(
                    f'{candidate}: requires macOS {minimum}, newer than {args.maximum_minimum_version}'
                )

    if checked == 0:
        problems.append(f'{args.app}: no Mach-O files found')

    if problems:
        print('\n'.join(problems), file=sys.stderr)
        return 1

    print(
        f'Verified {checked} native files: {args.architecture}, '
        f'macOS {args.maximum_minimum_version} or older deployment floor.'
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
