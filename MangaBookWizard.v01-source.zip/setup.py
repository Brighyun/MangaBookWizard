#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pip/pyinstaller build script for MangaBookWizard.

Install as Python package:
    python3 setup.py install

Create EXE/APP:
    python3 setup.py build_binary
"""

import os
import platform
import subprocess
import sys
import setuptools
from kindlecomicconverter import __version__

NAME = 'MangaBookWizard'
MAIN = 'manga_book_wizard.py'
VERSION = __version__


# noinspection PyUnresolvedReferences
class BuildBinaryCommand(setuptools.Command):
    description = 'build binary release'
    user_options = []

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    # noinspection PyShadowingNames
    def run(self):
        VERSION = __version__
        if sys.platform == 'darwin':
            subprocess.run([sys.executable, '-m', 'PyInstaller', '-y', 'kcc-macos.spec'], check=True)
            # Production distribution can add Apple Developer ID signing and notarization here.
            build_arch = os.getenv('MBW_BUILD_ARCH') or platform.machine() or platform.processor() or 'unknown'
            release_platform = {
                'arm64': 'ARM64',
                'aarch64': 'ARM64',
                'x86_64': 'Intel-x86_64',
                'amd64': 'Intel-x86_64',
            }.get(build_arch.lower(), build_arch)
            subprocess.run([
                'appdmg',
                'kcc.json',
                f'dist/MangaBookWizard.v01-macOS-{release_platform}.dmg',
            ], check=True)
            sys.exit(0)
        elif sys.platform == 'win32':
            if os.getenv('WINDOWS_7'):
                os.system('pyinstaller --hidden-import=_cffi_backend -y -F -i icons\\manga-book-wizard.ico -n manga_book_wizard_win7_legacy_' + VERSION + ' -w --noupx manga_book_wizard.py')
            else:
                os.system('pyinstaller --hidden-import=_cffi_backend -y -F -i icons\\manga-book-wizard.ico -n MangaBookWizard-' + VERSION + ' -w --noupx manga_book_wizard.py')
            sys.exit(0)
        elif sys.platform == 'linux':
            os.system(
                'pyinstaller --hidden-import=_cffi_backend --hidden-import=queue -y -F -i icons/manga-book-wizard.ico -n manga_book_wizard_linux_' + VERSION + ' manga_book_wizard.py')
            sys.exit(0)
        else:
            sys.exit(0)

# noinspection PyUnresolvedReferences
class BuildC2ECommand(setuptools.Command):
    description = 'build binary c2e release'
    user_options = []

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    # noinspection PyShadowingNames
    def run(self):
        VERSION = __version__
        if sys.platform == 'darwin':
            os.system('pyinstaller --hidden-import=_cffi_backend -y -D -i icons/manga-book-wizard.icns -n "Manga Book Wizard Engine" -c -s kcc-c2e.py')
            sys.exit(0)
        elif sys.platform == 'win32':
            if os.getenv('WINDOWS_7'):
                os.system('pyinstaller --hidden-import=_cffi_backend -y -F -i icons\\manga-book-wizard.ico -n manga_book_wizard_engine_win7_' + VERSION + ' -c --noupx kcc-c2e.py')
            else:
                os.system('pyinstaller --hidden-import=_cffi_backend -y -F -i icons\\manga-book-wizard.ico -n manga_book_wizard_engine_' + VERSION + ' -c --noupx kcc-c2e.py')
            sys.exit(0)
        elif sys.platform == 'linux':
            os.system(
                'pyinstaller --hidden-import=_cffi_backend --hidden-import=queue -y -F -i icons/manga-book-wizard.ico -n manga_book_wizard_engine_linux_' + VERSION + ' kcc-c2e.py')
            sys.exit(0)
        else:
            sys.exit(0)


# noinspection PyUnresolvedReferences
class BuildC2PCommand(setuptools.Command):
    description = 'build binary c2p release'
    user_options = []

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    # noinspection PyShadowingNames
    def run(self):
        VERSION = __version__
        if sys.platform == 'darwin':
            os.system('pyinstaller --hidden-import=_cffi_backend -y -n "Manga Book Wizard Panel Tool" -c -s kcc-c2p.py')
            sys.exit(0)
        elif sys.platform == 'win32':
            if os.getenv('WINDOWS_7'):
                os.system('pyinstaller --hidden-import=_cffi_backend -y -F -i icons\\manga-book-wizard.ico -n manga_book_wizard_panels_win7_' + VERSION + ' -c --noupx kcc-c2p.py')
            else:
                os.system('pyinstaller --hidden-import=_cffi_backend -y -F -i icons\\manga-book-wizard.ico -n manga_book_wizard_panels_' + VERSION + ' -c --noupx kcc-c2p.py')
            sys.exit(0)
        elif sys.platform == 'linux':
            os.system(
                'pyinstaller --hidden-import=_cffi_backend --hidden-import=queue -y -F -i icons/manga-book-wizard.ico -n manga_book_wizard_panels_linux_' + VERSION + ' kcc-c2p.py')
            sys.exit(0)
        else:
            sys.exit(0)


setuptools.setup(
    cmdclass={
        'build_binary': BuildBinaryCommand,
        'build_c2e': BuildC2ECommand,
        'build_c2p': BuildC2PCommand,
    },
    name=NAME,
    version=VERSION,
    author='Isaiah Lee and ISC-licensed engine contributors',
    description='A friendly manga, comic, and EPUB converter for Kindle and other e-readers.',
    license='ISC License (ISCL)',
    keywords=['kindle', 'kobo', 'comic', 'manga', 'mobi', 'epub', 'cbz'],
    url='https://www.linkedin.com/in/brigh-yun-lee-01130025b/',
    entry_points={
        'console_scripts': [
            'manga-book-wizard-engine = kindlecomicconverter.startup:startC2E',
            'manga-book-wizard-panels = kindlecomicconverter.startup:startC2P',
        ],
        'gui_scripts': [
            'manga-book-wizard = kindlecomicconverter.startup:start',
        ],
    },
    packages=['kindlecomicconverter'],
    install_requires=[
        'PySide6>=6.0.0',
        'Pillow>=9.3.0',
        'psutil>=5.9.5',
        'python-slugify>=1.2.1,<9.0.0',
        'mozjpeg-lossless-optimization>=1.2.0',
        'natsort>=8.4.0',
        'numpy>=1.22.4',
        'packaging>=23.2',
        'PyMuPDF>=1.16.1',
    ],
    classifiers=[],
    zip_safe=False,
)
