# -*- coding: utf-8 -*-
#
# Copyright (c) 2012-2014 Ciro Mattia Gonano <ciromattia@gmail.com>
# Copyright (c) 2013-2019 Pawel Jastrzebski <pawelj@iosphe.re>
#
# Permission to use, copy, modify, and/or distribute this software for
# any purpose with or without fee is hereby granted, provided that the
# above copyright notice and this permission notice appear in all
# copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE
# AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
# DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA
# OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
# PERFORMANCE OF THIS SOFTWARE.

import itertools
import json
from pathlib import Path
from PySide6.QtCore import (QSize, QUrl, Qt, Signal, QIODeviceBase, QEvent, QThread, QSettings)
from PySide6.QtGui import (QColor, QIcon, QImage, QKeyEvent, QPixmap, QDesktopServices)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDialogButtonBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QListWidgetItem, QMainWindow, QPushButton, QScrollArea, QSizePolicy, QSystemTrayIcon, QFileDialog, QMessageBox, QDialog, QAbstractItemView, QListView, QTextBrowser, QTreeView, QVBoxLayout, QWidget)
from PySide6.QtNetwork import (QLocalSocket, QLocalServer)

import os
import sys
from time import sleep
from shutil import move, rmtree
from subprocess import STDOUT, PIPE, CalledProcessError

from xml.sax.saxutils import escape
from psutil import Process
from copy import copy
from packaging.version import Version
from tempfile import gettempdir, mkdtemp
from PIL import Image
from PIL.Image import Dither

from .KCC_spread_label import LabelSpreadsDialog

from .shared import HTMLStripper, sanitizeTrace, walkLevel, subprocess_run
from .comicarchive import SEVENZIP, TAR, available_archive_tools
from .comic2ebook import OS_SORT_KEY, flattenTree, getWorkFolder, removeNonImages, sanitizeTree
from . import __version__
from . import comic2ebook
from . import metadata
from . import kindle
from . import branding
from . import preflight
from . import KCC_ui
from . import KCC_ui_editor


DEFAULT_SPREAD_STATE = Qt.CheckState.Checked


def default_gui_options():
    """Return fresh first-run settings shared by every device profile."""
    return {
        'gammaSlider': 0,
        # Keep original page edges unless the reader explicitly enables trimming.
        'croppingBox': Qt.CheckState.Unchecked.value,
        'croppingPowerSlider': 100,
        # Rotate wide two-page artwork instead of splitting or duplicating it.
        'rotateBox': DEFAULT_SPREAD_STATE.value,
        'mangaBox': 2,
        'blankPageScanBox': 2,
    }


def spread_splitter_mode(check_state):
    """Translate the three-state spread control into the converter mode."""
    if check_state == Qt.CheckState.PartiallyChecked:
        return 2  # split and rotate
    if check_state == Qt.CheckState.Checked:
        return 1  # rotate only
    return 0  # split only


class QApplicationMessaging(QApplication):
    messageFromOtherInstance = Signal(bytes)

    def __init__(self, argv):
        QApplication.__init__(self, argv)
        self._key = branding.APP_ID
        self._timeout = 1000
        self._locked = False
        socket = QLocalSocket(self)
        socket.connectToServer(self._key, QIODeviceBase.OpenModeFlag.WriteOnly)
        if not socket.waitForConnected(self._timeout):
            self._server = QLocalServer(self)
            self._server.newConnection.connect(self.handleMessage)
            self._server.listen(self._key)
        else:
            self._locked = True
        socket.disconnectFromServer()

    def __del__(self):
        if not self._locked:
            self._server.close()

    def event(self, e):
        if e.type() == QEvent.Type.FileOpen:
            self.messageFromOtherInstance.emit(bytes(e.file(), 'UTF-8'))
            return True
        else:
            return QApplication.event(self, e)

    def isRunning(self):
        return self._locked

    def handleMessage(self):
        socket = self._server.nextPendingConnection()
        if socket.waitForReadyRead(self._timeout):
            self.messageFromOtherInstance.emit(socket.readAll().data())

    def sendMessage(self, message):
        socket = QLocalSocket(self)
        socket.connectToServer(self._key, QIODeviceBase.OpenModeFlag.WriteOnly)
        socket.waitForConnected(self._timeout)
        socket.write(bytes(message, 'UTF-8'))
        socket.waitForBytesWritten(self._timeout)
        socket.disconnectFromServer()


class QMainWindowKCC(QMainWindow):
    progressBarTick = Signal(str)
    modeConvert = Signal(int)
    addMessage = Signal(str, str, bool)
    addTrayMessage = Signal(str, str)
    showDialog = Signal(str, str)
    hideProgressBar = Signal()
    forceShutdown = Signal()


class Icons:
    def __init__(self):
        self.deviceKindle = QIcon()
        self.deviceKindle.addPixmap(QPixmap(":/Devices/icons/Kindle.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.deviceKobo = QIcon()
        self.deviceKobo.addPixmap(QPixmap(":/Devices/icons/Kobo.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.deviceRmk = QIcon()
        self.deviceRmk.addPixmap(QPixmap(":/Devices/icons/Rmk.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.deviceOther = QIcon()
        self.deviceOther.addPixmap(QPixmap(":/Devices/icons/Other.png"), QIcon.Mode.Normal, QIcon.State.Off)

        self.MOBIFormat = QIcon()
        self.MOBIFormat.addPixmap(QPixmap(":/Formats/icons/MOBI.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.CBZFormat = QIcon()
        self.CBZFormat.addPixmap(QPixmap(":/Formats/icons/CBZ.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.EPUBFormat = QIcon()
        self.EPUBFormat.addPixmap(QPixmap(":/Formats/icons/EPUB.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.KFXFormat = QIcon()
        self.KFXFormat.addPixmap(QPixmap(":/Formats/icons/KFX.png"), QIcon.Mode.Normal, QIcon.State.Off)

        self.info = QIcon()
        self.info.addPixmap(QPixmap(":/Status/icons/info.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.warning = QIcon()
        self.warning.addPixmap(QPixmap(":/Status/icons/warning.png"), QIcon.Mode.Normal, QIcon.State.Off)
        self.error = QIcon()
        self.error.addPixmap(QPixmap(":/Status/icons/error.png"), QIcon.Mode.Normal, QIcon.State.Off)

        self.programIcon = QIcon()
        self.programIcon.addPixmap(QPixmap(":/Icon/icons/manga-book-wizard.png"), QIcon.Mode.Normal, QIcon.State.Off)

class VersionThread(QThread):
    def __init__(self):
        QThread.__init__(self)
        self.newVersion = ''
        self.md5 = ''
        self.barProgress = 0
        self.answer = None

    def __del__(self):
        self.wait()

    def run(self):
        # Kept as a lightweight answer holder for existing worker dialogs.
        # This app no longer contacts the original project's release or announcement feeds.
        return


    def setAnswer(self, dialoganswer):
        self.answer = dialoganswer


class ProgressThread(QThread):
    def __init__(self):
        QThread.__init__(self)
        self.running = False
        self.content = None
        self.progress = 0

    def __del__(self):
        self.wait()

    def run(self):
        self.running = True
        while self.running:
            sleep(1)
            if self.content and GUI.conversionAlive:
                MW.addMessage.emit(self.content + self.progress * '.', 'info', True)
                self.progress += 1
                if self.progress == 4:
                    self.progress = 0

    def stop(self):
        self.running = False


class SourcePreflightThread(QThread):
    resultsReady = Signal(object)

    def __init__(self, sources, profile, output_format):
        super().__init__()
        self.sources = sources
        self.profile = profile
        self.output_format = output_format

    def run(self):
        reports = []
        for source in self.sources:
            try:
                reports.append(preflight.scan_source(source, self.profile, self.output_format))
            except Exception as exc:
                report = preflight.PreflightReport(source)
                report.add('error', 'SCAN_FAILED', f'The safety scan could not inspect this source: {exc}')
                reports.append(report)
        self.resultsReady.emit(reports)


def get_options():
    parser = comic2ebook.makeParser()
    options = parser.parse_args()

    options.profile = GUI.profiles[str(GUI.deviceBox.currentText())]['Label']
    gui_current_format = GUI.formats[str(GUI.formatBox.currentText())]['format']
    options.format = gui_current_format
    if not GUI.blankPageScanBox.isChecked():
        options.preflight = False
    if GUI.mangaBox.isChecked():
        options.righttoleft = True
    if GUI.lightnovelBox.isChecked():
        options.lightnovel = True
    if GUI.ebokBox.isChecked():
        options.ebok = True
    if GUI.invertDirectionBox.isChecked():
        options.invertdirection = True
    options.splitter = spread_splitter_mode(GUI.rotateBox.checkState())
    if GUI.qualityBox.checkState() == Qt.CheckState.PartiallyChecked:
        options.autoscale = True
    elif GUI.qualityBox.checkState() == Qt.CheckState.Checked:
        options.hq = True
    if GUI.vertical4PanelBox.isChecked():
        options.vertical4panel = True
    if GUI.webtoonBox.isChecked():
        options.webtoon = True
    if GUI.upscaleBox.checkState() == Qt.CheckState.PartiallyChecked:
        options.stretch = True
    elif GUI.upscaleBox.checkState() == Qt.CheckState.Checked:
        options.upscale = True
    if GUI.gammaBox.isChecked() and float(GUI.gammaValue) > 0.09:
        options.gamma = float(GUI.gammaValue)
    if GUI.autoLevelBox.isChecked():
        options.autolevel = True
    if GUI.autocontrastBox.checkState() == Qt.CheckState.PartiallyChecked:
        options.noautocontrast = True
    elif GUI.autocontrastBox.checkState() == Qt.CheckState.Checked:
        options.colorautocontrast = True
    if GUI.croppingBox.isChecked():
        if GUI.croppingBox.checkState() == Qt.CheckState.PartiallyChecked:
            options.cropping = 1
        else:
            options.cropping = 2
    else:
        options.cropping = 0
    if GUI.croppingBox.checkState() != Qt.CheckState.Unchecked:
        options.croppingp = float(GUI.croppingPowerValue)
        options.preservemargin = GUI.preserveMarginBox.value()
    if GUI.interPanelCropBox.isChecked():
        if GUI.interPanelCropBox.checkState() == Qt.CheckState.PartiallyChecked:
            options.interpanelcrop = 1
        else:
            options.interpanelcrop = 2
    else:
        options.interpanelcrop = 0
    if GUI.borderBox.checkState() == Qt.CheckState.PartiallyChecked:
        options.white_borders = True
    elif GUI.borderBox.checkState() == Qt.CheckState.Checked:
        options.black_borders = True
    if GUI.outputSplit.isChecked():
        options.batchsplit = 2
    if GUI.colorBox.isChecked():
        options.forcecolor = True
    if GUI.eraseRainbowBox.isChecked():
        options.eraserainbow = True
    if GUI.maximizeStrips.isChecked():
        options.maximizestrips = True
    if GUI.disableProcessingBox.isChecked():
        options.noprocessing = True
    if GUI.legacyExtractBox.isChecked():
        options.legacyextract = True
    if GUI.pdfWidthBox.isChecked():
        options.pdfwidth = True
    if GUI.smartCoverCropBox.isChecked():
        options.smartcovercrop = True
    if GUI.coverFillBox.isChecked():
        options.coverfill = True
    if GUI.metadataTitleBox.checkState() == Qt.CheckState.PartiallyChecked:
        options.metadatatitle = 1
    elif GUI.metadataTitleBox.checkState() == Qt.CheckState.Checked:
        options.metadatatitle = 2
    if GUI.keepComicInfoBox.isChecked():
        options.keepcomicinfo = True
    if GUI.deleteBox.isChecked():
        options.delete = True
    if GUI.tempDirBox.isChecked():
        options.tempdir = True
    if GUI.spreadShiftBox.isChecked():
        options.spreadshift = True
    if GUI.onePageLandscapeBox.isChecked():
        options.onepagelandscape = True
    if GUI.fileFusionBox.isChecked():
        options.filefusion = True
    else:
        options.filefusion = False
    if GUI.noRotateBox.isChecked():
        options.norotate = True
    if GUI.rotateRightBox.isChecked():
        options.rotateright = True
    if GUI.rotateFirstBox.isChecked():
        options.rotatefirst = True
    if GUI.forcePngRgbBox.isChecked():
        options.force_png_rgb = True
    if GUI.mozJpegBox.checkState() == Qt.CheckState.PartiallyChecked:
        options.forcepng = True
    elif GUI.mozJpegBox.checkState() == Qt.CheckState.Checked:
        options.mozjpeg = True
    if GUI.webpBox.isChecked():
        options.webp = True
    if GUI.pngLegacyBox.isChecked():
        options.pnglegacy = True
    if GUI.noQuantizeBox.isChecked():
        options.noquantize = True
    if GUI.jpegQualityBox.isChecked():
        options.jpegquality = GUI.jpegQualitySpinBox.value()
    if GUI.currentMode > 2:
        options.customwidth = str(GUI.widthBox.value())
        options.customheight = str(GUI.heightBox.value())
    if GUI.targetDirectory != '':
        options.output = GUI.targetDirectory
    if GUI.titleEdit.text():
        options.title = str(GUI.titleEdit.text())
    if GUI.authorEdit.text():
        options.author = str(GUI.authorEdit.text())
    if GUI.languageEdit.text():
        options.language = str(GUI.languageEdit.text())
    if GUI.chunkSizeCheckBox.isChecked():
        options.targetsize = int(GUI.chunkSizeBox.value())

    return options, gui_current_format


def source_from_job_item(item):
    """Return the full source path while the list shows only a friendly file name."""
    stored_path = item.data(Qt.ItemDataRole.UserRole)
    return str(stored_path) if stored_path else str(item.text())

class WorkerThread(QThread):
    def __init__(self):
        QThread.__init__(self)
        self.conversionAlive = False
        self.errors = False
        self.kindlegenErrorCode = [0]
        self.workerOutput = []
        self.progressBarTick = MW.progressBarTick
        self.addMessage = MW.addMessage

    def __del__(self):
        self.wait()

    def sync(self):
        self.conversionAlive = GUI.conversionAlive

    def clean(self):
        GUI.progress.content = ''
        GUI.progress.stop()
        GUI.needClean = True
        MW.hideProgressBar.emit()
        MW.addMessage.emit('<b>Conversion interrupted.</b>', 'error', False)
        MW.addTrayMessage.emit('Conversion interrupted.', 'Critical')
        MW.modeConvert.emit(1)

    # noinspection PyUnboundLocalVariable
    def run(self):
        MW.modeConvert.emit(0)

        argv = ''
        currentJobs = []
        options, gui_current_format = get_options()

        for i in range(GUI.jobList.count()):
            # Make sure that we don't consider any system message as job to do
            if GUI.jobList.item(i).icon().isNull():
                currentJobs.append(source_from_job_item(GUI.jobList.item(i)))
        GUI.jobList.clear()
        if options.filefusion:
            bookDir = []
            MW.addMessage.emit('Attempting file fusion', 'info', False)
            for job in currentJobs:
                bookDir.append(job)
            try:
                fusion_source_parent = str(Path(bookDir[0]).parent)
                comic2ebook.options = comic2ebook.checkOptions(copy(options))
                if options.output is None:
                    options.output = fusion_source_parent
                currentJobs.clear()
                currentJobs.append(comic2ebook.makeFusion(bookDir))
                MW.addMessage.emit('Created fusion at ' + currentJobs[0], 'info', False)
            except Exception as e:
                print('Fusion Failed. ' + str(e))
                MW.addMessage.emit('Fusion Failed. ' + str(e), 'error', True)
        elif len(currentJobs) > 1 and options.title != 'defaulttitle':
            currentJobs.clear()
            error_message = 'Process Failed. Custom title can\'t be set when processing more than 1 source.\nDid you forget to check fusion?'
            print(error_message)
            MW.addMessage.emit(error_message, 'error', True)
        for i, job in enumerate(currentJobs, start=1):
            job_progress_number = f'[{i}/{len(currentJobs)}] '
            sleep(0.5)
            if not self.conversionAlive:
                self.clean()
                return
            self.errors = False
            MW.addMessage.emit(f'<b>{job_progress_number}Source:</b> ' + job, 'info', False)
            if gui_current_format == 'CBZ':
                MW.addMessage.emit('Creating CBZ files', 'info', False)
                GUI.progress.content = 'Creating CBZ files'
            elif gui_current_format == 'PDF':
                MW.addMessage.emit('Creating PDF files', 'info', False)
                GUI.progress.content = 'Creating PDF files'
            else:
                MW.addMessage.emit('Creating EPUB files', 'info', False)
                GUI.progress.content = 'Creating EPUB files'
            jobargv = list(argv)
            jobargv.append(job)
            try:
                comic2ebook.options = comic2ebook.checkOptions(copy(options))
                outputPath = comic2ebook.makeBook(job, self, job_progress_number)
                MW.hideProgressBar.emit()
            except UserWarning as warn:
                if not self.conversionAlive:
                    self.clean()
                    return
                else:
                    GUI.progress.content = ''
                    self.errors = True
                    MW.addMessage.emit(str(warn), 'warning', False)
                    MW.addMessage.emit('The Wizard could not finish this book. Open Help & FAQ for simple next steps.',
                                       'error', False)
                    MW.addTrayMessage.emit('Error during conversion!', 'Critical')
            except Exception as err:
                GUI.progress.content = ''
                self.errors = True
                _, _, traceback = sys.exc_info()
                MW.showDialog.emit("Error during conversion %s:\n\n%s\n\nTraceback:\n%s"
                                   % (jobargv[-1], str(err), sanitizeTrace(traceback)), 'error')
                MW.addMessage.emit('The Wizard could not finish this book. Open Help & FAQ for simple next steps.',
                                   'error', False)
                MW.addTrayMessage.emit('Error during conversion!', 'Critical')
            if not self.conversionAlive:
                if 'outputPath' in locals():
                    for item in outputPath:
                        if os.path.exists(item):
                            os.remove(item)
                self.clean()
                return
            if not self.errors:
                GUI.progress.content = ''
                if gui_current_format == 'CBZ':
                    MW.addMessage.emit('Creating CBZ files... <b>Done!</b>', 'info', True)
                elif gui_current_format == 'PDF':
                    MW.addMessage.emit('Creating PDF files... <b>Done!</b>', 'info', True)
                else:
                    MW.addMessage.emit('Creating EPUB files... <b>Done!</b>', 'info', True)
                if 'MOBI' in gui_current_format and not options.lightnovel:
                    MW.progressBarTick.emit(f'{job_progress_number}Creating MOBI files')
                    MW.progressBarTick.emit(str(len(outputPath) * 2 + 1))
                    MW.progressBarTick.emit('tick')
                    MW.addMessage.emit('Creating MOBI files', 'info', False)
                    GUI.progress.content = 'Creating MOBI files'
                    work = []
                    for item in outputPath:
                        work.append([item])
                    self.workerOutput = comic2ebook.makeMOBI(work, self)
                    self.kindlegenErrorCode = [0]
                    for errors in self.workerOutput:
                        if errors[0] != 0:
                            self.kindlegenErrorCode = errors
                            break
                    if not self.conversionAlive:
                        for item in outputPath:
                            if os.path.exists(item):
                                os.remove(item)
                            if os.path.exists(item.replace('.epub', '.mobi')):
                                os.remove(item.replace('.epub', '.mobi'))
                        self.clean()
                        return
                    if self.kindlegenErrorCode[0] == 0:
                        GUI.progress.content = ''
                        MW.addMessage.emit('Creating MOBI files... <b>Done!</b>', 'info', True)
                        MW.addMessage.emit('Processing MOBI files', 'info', False)
                        GUI.progress.content = 'Processing MOBI files'
                        self.workerOutput = []
                        for item in outputPath:
                            self.workerOutput.append(comic2ebook.makeMOBIFix(
                                item, comic2ebook.options.covers[outputPath.index(item)][1]))
                            MW.progressBarTick.emit('tick')
                        for success in self.workerOutput:
                            if not success[0]:
                                self.errors = True
                                break
                        if not self.errors:
                            for item in outputPath:
                                GUI.progress.content = ''
                                mobiPath = item.replace('.epub', '.mobi')
                                if GUI.targetDirectory and GUI.targetDirectory != os.path.dirname(mobiPath):
                                    try:
                                        move(mobiPath, GUI.targetDirectory)
                                    except Exception:
                                        pass
                            MW.addMessage.emit('Processing MOBI files... <b>Done!</b>', 'info', True)
                            k = kindle.Kindle(options.profile)
                            if k.path and k.coverSupport:
                                for item in outputPath:
                                    cover = comic2ebook.options.covers[outputPath.index(item)][0]
                                    if cover:
                                        cover.saveToKindle(
                                            k, comic2ebook.options.covers[outputPath.index(item)][1])
                                MW.addMessage.emit('Kindle detected. Uploading covers... <b>Done!</b>', 'info', False)
                        else:
                            GUI.progress.content = ''
                            for item in outputPath:
                                mobiPath = item.replace('.epub', '.mobi')
                                if os.path.exists(mobiPath):
                                    os.remove(mobiPath)
                            MW.addMessage.emit('Failed to process MOBI file!', 'error', False)
                            MW.addTrayMessage.emit('Failed to process MOBI file!', 'Critical')
                    else:
                        GUI.progress.content = ''
                        epubSize = (os.path.getsize(self.kindlegenErrorCode[2])) // 1024 // 1024
                        for item in outputPath:
                            if os.path.exists(item):
                                os.remove(item)
                            if os.path.exists(item.replace('.epub', '.mobi')):
                                os.remove(item.replace('.epub', '.mobi'))
                        MW.addMessage.emit('KindleGen failed to create MOBI!', 'error', False)
                        MW.addMessage.emit(self.kindlegenErrorCode[1], 'error', False)
                        MW.addTrayMessage.emit('KindleGen failed to create MOBI!', 'Critical')
                        if self.kindlegenErrorCode[0] == 1 and self.kindlegenErrorCode[1] != '':
                            MW.showDialog.emit("KindleGen error:\n\n" + self.kindlegenErrorCode[1], 'error')
                        if self.kindlegenErrorCode[0] == 23026:
                            MW.addMessage.emit('Created EPUB file was too big. Weird file structure?', 'error', False)
                            MW.addMessage.emit('EPUB file: ' + str(epubSize) + 'MB. Supported size: ~350MB.', 'error',
                                               False)
                else:
                    for item in outputPath:
                        if GUI.targetDirectory and GUI.targetDirectory != os.path.dirname(item):
                            try:
                                move(item, GUI.targetDirectory)
                            except Exception:
                                pass
        GUI.progress.content = ''
        GUI.progress.stop()
        MW.hideProgressBar.emit()
        GUI.needClean = True
        if not self.errors:
            MW.addMessage.emit(
                f'<b>Your book is ready — happy reading!</b> Find another manga on '
                f'<a href="{branding.ANILIST_URL}">AniList</a>, or '
                f'<a href="{branding.LINKEDIN_URL}">connect with Isaiah Lee on LinkedIn</a>. '
                f'Enjoying the Wizard? <a href="{branding.BUY_ME_A_COFFEE_URL}">Support MangaBookWizard</a>.',
                'info', False)
            MW.addTrayMessage.emit('Your book is ready!', 'Information')
        MW.modeConvert.emit(1)


class SystemTrayIcon(QSystemTrayIcon):
    def __init__(self):
        super().__init__()
        if self.isSystemTrayAvailable():
            self.setIcon(GUI.icons.programIcon)
            self.activated.connect(self.catchClicks)

    def catchClicks(self):
        MW.showNormal()
        MW.raise_()
        MW.activateWindow()

    def addTrayMessage(self, message, icon):
        icon = getattr(QSystemTrayIcon.MessageIcon, icon)
        if self.supportsMessages() and not MW.isActiveWindow():
            self.showMessage(branding.APP_NAME, message, icon)


class KCCGUI(KCC_ui.Ui_mainWindow):
    def _buildModernShell(self):
        """Build the friendly three-step window while preserving the conversion controls."""
        original_widgets = [
            self.toolWidget, self.progressBar, self.jobList, self.buttonWidget,
            self.optionWidget, self.chunkSizeWidget, self.gammaWidget,
            self.customWidget, self.croppingWidget, self.jpegQualityWidget,
        ]
        for widget in original_widgets:
            self.gridLayout.removeWidget(widget)

        self.mainScroll = QScrollArea(self.centralWidget)
        self.mainScroll.setObjectName('mainScroll')
        self.mainScroll.setWidgetResizable(True)
        self.mainScroll.setFrameShape(QFrame.Shape.NoFrame)
        self.mainScroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.mainPage = QWidget()
        self.mainPage.setObjectName('mainPage')
        page_layout = QVBoxLayout(self.mainPage)
        page_layout.setContentsMargins(22, 20, 22, 22)
        page_layout.setSpacing(14)
        self.mainScroll.setWidget(self.mainPage)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.addWidget(self.mainScroll, 0, 0, 1, 1)

        self.brandHeader = QFrame(self.mainPage)
        self.brandHeader.setObjectName('brandHeader')
        header_layout = QHBoxLayout(self.brandHeader)
        header_layout.setContentsMargins(18, 15, 16, 15)
        brand_icon = QLabel(self.brandHeader)
        brand_icon.setObjectName('brandIcon')
        brand_icon.setPixmap(QPixmap(':/Icon/icons/manga-book-wizard.png').scaled(
            70, 70, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        brand_icon.setFixedSize(76, 76)
        header_layout.addWidget(brand_icon)
        title_layout = QVBoxLayout()
        title_layout.setSpacing(2)
        title = QLabel(branding.APP_NAME, self.brandHeader)
        title.setObjectName('brandTitle')
        subtitle = QLabel('Turn manga, comics, and EPUB books into e-reader-friendly files', self.brandHeader)
        subtitle.setObjectName('brandSubtitle')
        subtitle.setWordWrap(True)
        title_layout.addWidget(title)
        title_layout.addWidget(subtitle)
        header_layout.addLayout(title_layout, 1)
        safety_badge = QLabel('✓ Page safety on', self.brandHeader)
        safety_badge.setObjectName('safetyBadge')
        safety_badge.setToolTip('The Wizard checks for likely blank pages and broken book files.')
        header_layout.addWidget(safety_badge)
        self.supportButton = QPushButton('Buy Me a Coffee', self.brandHeader)
        self.supportButton.setObjectName('supportButton')
        self.supportButton.setToolTip('Support the continued development of MangaBookWizard. Every app feature remains free.')
        header_layout.addWidget(self.supportButton)
        self.helpButton = QPushButton('Help && FAQ', self.brandHeader)
        self.helpButton.setObjectName('helpButton')
        header_layout.addWidget(self.helpButton)
        page_layout.addWidget(self.brandHeader)

        self.dropCard = QFrame(self.mainPage)
        self.dropCard.setObjectName('dropCard')
        drop_layout = QVBoxLayout(self.dropCard)
        drop_layout.setContentsMargins(22, 18, 22, 20)
        drop_layout.setSpacing(10)
        step_one = QLabel('STEP 1  ·  ADD YOUR BOOK', self.dropCard)
        step_one.setObjectName('stepLabel')
        drop_title = QLabel('Drop your manga or book here', self.dropCard)
        drop_title.setObjectName('dropTitle')
        drop_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        drop_subtitle = QLabel('PDF, EPUB, CBZ, ZIP, or a folder of page images', self.dropCard)
        drop_subtitle.setObjectName('dropSubtitle')
        drop_subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        drop_layout.addWidget(step_one)
        drop_layout.addWidget(drop_title)
        drop_layout.addWidget(drop_subtitle)
        self.jobList.setMinimumHeight(130)
        self.jobList.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.jobList.setToolTip('Drop files here. Double-click a source if you want to edit its book details.')
        drop_layout.addWidget(self.jobList)
        add_row = QHBoxLayout()
        self.fileButton.setText('Choose files')
        self.fileButton.setIcon(QIcon())
        self.fileButton.setToolTip('Choose one or more PDF, EPUB, CBZ, ZIP, CBR, RAR, or 7Z files.')
        self.directoryButton.setText('Choose a folder')
        self.directoryButton.setIcon(QIcon())
        self.directoryButton.setToolTip('Choose a folder containing the pages of one manga or comic.')
        self.clearButton.setText('Start over')
        self.clearButton.setIcon(QIcon())
        add_row.addStretch(1)
        add_row.addWidget(self.fileButton)
        add_row.addWidget(self.directoryButton)
        add_row.addWidget(self.clearButton)
        add_row.addStretch(1)
        drop_layout.addLayout(add_row)
        page_layout.addWidget(self.dropCard)

        self.setupCard = QFrame(self.mainPage)
        self.setupCard.setObjectName('setupCard')
        setup_layout = QVBoxLayout(self.setupCard)
        setup_layout.setContentsMargins(22, 18, 22, 20)
        setup_layout.setSpacing(12)
        step_two = QLabel('STEP 2  ·  PICK WHERE IT WILL GO', self.setupCard)
        step_two.setObjectName('stepLabel')
        setup_layout.addWidget(step_two)
        choices = QGridLayout()
        choices.setHorizontalSpacing(14)
        choices.setVerticalSpacing(7)
        device_label = QLabel('Which reader do you have?', self.setupCard)
        device_label.setObjectName('fieldLabel')
        format_label = QLabel('What should the Wizard make?', self.setupCard)
        format_label.setObjectName('fieldLabel')
        choices.addWidget(device_label, 0, 0)
        choices.addWidget(format_label, 0, 1)
        choices.addWidget(self.deviceBox, 1, 0)
        choices.addWidget(self.formatBox, 1, 1)
        for box in (self.deviceBox, self.formatBox):
            for index in range(box.count()):
                box.setItemIcon(index, QIcon())
        choices.setColumnStretch(0, 1)
        choices.setColumnStretch(1, 1)
        setup_layout.addLayout(choices)
        device_hint = QLabel('Not sure? Leave the recommended Paperwhite choice selected.', self.setupCard)
        device_hint.setObjectName('mutedLabel')
        setup_layout.addWidget(device_hint)

        quick_title = QLabel('Helpful defaults', self.setupCard)
        quick_title.setObjectName('fieldLabel')
        setup_layout.addWidget(quick_title)
        self.blankPageScanBox = QCheckBox('Check for blank or broken pages', self.setupCard)
        self.blankPageScanBox.setObjectName('blankPageScanBox')
        self.blankPageScanBox.setChecked(True)
        self.blankPageScanBox.setToolTip('Checks the book before and after conversion for common blank-page causes.')
        quick_options = QGridLayout()
        quick_options.setHorizontalSpacing(20)
        quick_options.setVerticalSpacing(8)
        quick_controls = [
            (self.mangaBox, 'Read manga right-to-left',
             'Turn this on for Japanese-style manga page order.'),
            (self.croppingBox, 'Trim empty page borders',
             'Removes empty margins and page-number space so artwork is easier to read.'),
            (self.upscaleBox, 'Fit small pages to the screen',
             'Makes undersized pages use more of your e-reader screen.'),
            (self.blankPageScanBox, self.blankPageScanBox.text(), self.blankPageScanBox.toolTip()),
        ]
        for index, (control, text, tip) in enumerate(quick_controls):
            control.setText(text)
            control.setToolTip(tip)
            if control in (self.mangaBox, self.croppingBox):
                control.setTristate(False)
            quick_options.addWidget(control, index // 2, index % 2)
        setup_layout.addLayout(quick_options)

        save_row = QHBoxLayout()
        self.defaultOutputFolderBox.setText('Save finished files in my chosen folder')
        self.defaultOutputFolderBox.setToolTip('Otherwise the finished file is saved beside the original.')
        self.defaultOutputFolderButton.setText('Choose save folder')
        self.defaultOutputFolderButton.setIcon(QIcon())
        self.defaultOutputFolderButton.setToolTip('Pick where finished books should be saved.')
        save_row.addWidget(self.defaultOutputFolderBox)
        save_row.addStretch(1)
        save_row.addWidget(self.defaultOutputFolderButton)
        setup_layout.addLayout(save_row)

        self.advancedButton = QPushButton('More choices  ▾', self.setupCard)
        self.advancedButton.setObjectName('advancedButton')
        self.advancedButton.setCheckable(True)
        self.advancedButton.setToolTip('Open extra controls. Most people can leave these alone.')
        setup_layout.addWidget(self.advancedButton)
        self.advancedPanel = QFrame(self.setupCard)
        self.advancedPanel.setObjectName('advancedPanel')
        advanced_layout = QVBoxLayout(self.advancedPanel)
        advanced_layout.setContentsMargins(14, 12, 14, 14)
        advanced_layout.setSpacing(9)
        advanced_note = QLabel('Extra controls — the helpful defaults above are enough for most books.', self.advancedPanel)
        advanced_note.setObjectName('mutedLabel')
        advanced_note.setWordWrap(True)
        advanced_layout.addWidget(advanced_note)
        self.editorButton.setText('Edit book details')
        self.editorButton.setToolTip('Change title, author, volume, and other embedded book information.')
        self.labelSpreadsButton.setText('Mark two-page artwork')
        self.labelSpreadsButton.setToolTip('Choose pages that should be treated as a two-page spread.')
        self.anilistButton.hide()
        self.linkedInButton.hide()
        advanced_layout.addWidget(self.toolWidget)
        advanced_layout.addWidget(self.optionWidget)
        advanced_layout.addWidget(self.chunkSizeWidget)
        advanced_layout.addWidget(self.gammaWidget)
        advanced_layout.addWidget(self.customWidget)
        advanced_layout.addWidget(self.croppingWidget)
        advanced_layout.addWidget(self.jpegQualityWidget)
        self.advancedPanel.hide()
        setup_layout.addWidget(self.advancedPanel)
        page_layout.addWidget(self.setupCard)

        self.actionDock = QWidget(self.centralWidget)
        self.actionDock.setObjectName('actionDock')
        dock_layout = QVBoxLayout(self.actionDock)
        dock_layout.setContentsMargins(22, 0, 22, 20)
        dock_layout.setSpacing(0)
        self.actionCard = QFrame(self.actionDock)
        self.actionCard.setObjectName('actionCard')
        action_layout = QVBoxLayout(self.actionCard)
        action_layout.setContentsMargins(22, 16, 22, 16)
        action_row = QHBoxLayout()
        action_text = QVBoxLayout()
        step_three = QLabel('STEP 3  ·  MAKE YOUR BOOK', self.actionCard)
        step_three.setObjectName('stepLabel')
        action_hint = QLabel('The page safety check runs automatically.', self.actionCard)
        action_hint.setObjectName('mutedLabel')
        action_text.addWidget(step_three)
        action_text.addWidget(action_hint)
        action_row.addLayout(action_text, 1)
        self.preflightButton = QPushButton('Check pages now', self.actionCard)
        self.preflightButton.setObjectName('preflightButton')
        self.preflightButton.setIcon(QIcon())
        self.preflightButton.setToolTip('Check selected books now for missing, damaged, or likely blank pages.')
        self.convertButton.setText('Make my book')
        self.convertButton.setIcon(QIcon())
        self.convertButton.setToolTip('Create the finished book using the choices above.')
        self.convertButton.setMinimumWidth(220)
        self.convertButton.setMinimumHeight(46)
        action_row.addWidget(self.preflightButton)
        action_row.addWidget(self.convertButton)
        action_layout.addLayout(action_row)
        action_layout.addWidget(self.progressBar)
        dock_layout.addWidget(self.actionCard)
        self.gridLayout.addWidget(self.actionDock, 1, 0, 1, 1)

        self.communityCard = QFrame(self.mainPage)
        self.communityCard.setObjectName('communityCard')
        community_layout = QVBoxLayout(self.communityCard)
        community_layout.setContentsMargins(22, 16, 22, 18)
        community_layout.setSpacing(8)
        community_title = QLabel('Need your next read?', self.communityCard)
        community_title.setObjectName('communityTitle')
        community_note = QLabel('AniList is great for manga recommendations and tracking. Reddit is great for reader advice.', self.communityCard)
        community_note.setObjectName('mutedLabel')
        community_note.setWordWrap(True)
        community_layout.addWidget(community_title)
        community_layout.addWidget(community_note)
        community_buttons = QGridLayout()
        self.anilistButton.setText('Find manga on AniList')
        self.anilistButton.setIcon(QIcon())
        self.anilistButton.show()
        self.linkedInButton.setText('Connect with Isaiah Lee on LinkedIn')
        self.linkedInButton.setIcon(QIcon())
        self.linkedInButton.show()
        self.redditMangaButton = QPushButton('Visit r/manga', self.communityCard)
        self.redditKindleButton = QPushButton('Visit r/kindle', self.communityCard)
        self.redditCollectorsButton = QPushButton('Visit r/MangaCollectors', self.communityCard)
        self.buyMeACoffeeButton = QPushButton('Support MangaBookWizard', self.communityCard)
        for button in (self.anilistButton, self.redditMangaButton, self.redditKindleButton,
                       self.redditCollectorsButton, self.linkedInButton, self.buyMeACoffeeButton):
            button.setProperty('community', True)
        community_buttons.addWidget(self.anilistButton, 0, 0)
        community_buttons.addWidget(self.redditMangaButton, 0, 1)
        community_buttons.addWidget(self.redditKindleButton, 0, 2)
        community_buttons.addWidget(self.redditCollectorsButton, 1, 0)
        community_buttons.addWidget(self.linkedInButton, 1, 1, 1, 2)
        community_buttons.addWidget(self.buyMeACoffeeButton, 2, 0, 1, 3)
        community_layout.addLayout(community_buttons)
        page_layout.addWidget(self.communityCard)

        footer = QLabel('Made for easy personal reading • Only convert books you own or have permission to use', self.mainPage)
        footer.setObjectName('footerLabel')
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        page_layout.addWidget(footer)

        friendly_labels = {
            'metadataTitleBox': 'Use the title already inside the book',
            'vertical4PanelBox': 'Open tall panels first',
            'webtoonBox': 'This is a scrolling webtoon',
            'webpBox': 'Use smaller WebP images',
            'smartCoverCropBox': 'Find the cover inside a wide image',
            'autocontrastBox': 'Improve faded pages',
            'mozJpegBox': 'Choose page image type',
            'coverFillBox': 'Fill the whole screen with the cover',
            'interPanelCropBox': 'Remove empty space between panels',
            'chunkSizeCheckBox': 'Split very large finished books',
            'disableProcessingBox': 'Keep page images unchanged',
            'spreadShiftBox': 'Move the first page for two-page art',
            'forcePngRgbBox': 'Keep color pages as PNG',
            'rotateBox': 'Rotate two-page spreads',
            'gammaBox': 'Adjust page brightness',
            'rotateRightBox': 'Turn wide pages the other way',
            'tempDirBox': 'Keep temporary work beside the source',
            'deleteBox': 'Delete originals after conversion (not recommended)',
            'maximizeStrips': 'Rearrange very tall 1×4 strips',
            'jpegQualityBox': 'Choose finished image quality',
            'rotateFirstBox': 'Show wide artwork first',
            'pdfWidthBox': 'Fit PDF pages by width',
            'eraseRainbowBox': 'Reduce rainbow patterns on color e-ink',
            'onePageLandscapeBox': 'Center one page in landscape view',
            'outputSplit': 'Split oversized Kindle books automatically',
            'fileFusionBox': 'Join selected chapters into one book',
            'colorBox': 'Keep pages in color',
            'legacyExtractBox': 'Try the backup PDF/EPUB reader',
            'borderBox': 'Choose white or black page borders',
            'invertDirectionBox': 'Reverse page-turn direction',
            'qualityBox': 'Use extra-clear panel zoom',
            'noRotateBox': 'Never turn wide pages',
            'autoLevelBox': 'Make dark ink look deeper',
            'lightnovelBox': 'This is a light novel',
            'pngLegacyBox': 'Use older-reader-safe PNG files',
            'ebokBox': 'Mark this as a personal document',
            'noQuantizeBox': 'Keep full PNG color depth',
            'keepComicInfoBox': 'Keep the original comic details file',
        }
        for name, text in friendly_labels.items():
            getattr(self, name).setText(text)

        # Reflow the inherited expert grid into two readable columns. The old
        # four-column layout was the main source of clipped, technical-looking UI.
        while self.gridLayout_2.count():
            self.gridLayout_2.takeAt(0)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setHorizontalSpacing(16)
        self.gridLayout_2.setVerticalSpacing(7)
        self.gridLayout_2.addWidget(self.titleEdit, 0, 0)
        self.gridLayout_2.addWidget(self.authorEdit, 0, 1)
        self.gridLayout_2.addWidget(self.languageEdit, 1, 0, 1, 2)
        advanced_control_names = [
            'rotateBox', 'qualityBox', 'metadataTitleBox', 'fileFusionBox',
            'webtoonBox', 'lightnovelBox', 'ebokBox', 'invertDirectionBox',
            'outputSplit', 'colorBox', 'autoLevelBox', 'autocontrastBox',
            'interPanelCropBox', 'borderBox', 'onePageLandscapeBox', 'noRotateBox',
            'spreadShiftBox', 'rotateRightBox', 'rotateFirstBox', 'vertical4PanelBox',
            'coverFillBox', 'smartCoverCropBox', 'pdfWidthBox', 'legacyExtractBox',
            'eraseRainbowBox', 'mozJpegBox', 'forcePngRgbBox', 'pngLegacyBox',
            'noQuantizeBox', 'webpBox', 'jpegQualityBox', 'maximizeStrips',
            'disableProcessingBox', 'tempDirBox', 'keepComicInfoBox', 'gammaBox',
            'chunkSizeCheckBox', 'deleteBox',
        ]
        for index, name in enumerate(advanced_control_names):
            control = getattr(self, name)
            control.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            self.gridLayout_2.addWidget(control, 2 + index // 2, index % 2)
        self.gridLayout_2.setColumnStretch(0, 1)
        self.gridLayout_2.setColumnStretch(1, 1)

        self.titleEdit.setPlaceholderText('Book title (optional)')
        self.authorEdit.setPlaceholderText('Author (optional)')
        self.languageEdit.setPlaceholderText('Book language, such as en-US (optional)')
        self.wLabel.setText('Screen width:')
        self.hLabel.setText('Screen height:')
        self.gammaLabel.setText('Page brightness: Auto')
        self.croppingPowerLabel.setText('Border trimming strength:')
        self.preserveMarginLabel.setText('Keep a little border (%):')
        self.jpegQualityLabel.setText('Finished image quality:')
        self.chunkSizeLabel.setText('Split after this many MB:')

        for drop_target in (self.centralWidget, self.mainPage, self.dropCard, self.jobList.viewport()):
            drop_target.setAcceptDrops(True)
            drop_target.dragEnterEvent = self.dragAndDrop
            drop_target.dropEvent = self.dragAndDropAccepted
        self.statusBar.hide()
        MW.setMinimumSize(QSize(860, 720))
        MW.resize(860, 860)

    def _toggleAdvanced(self, opened):
        self.advancedPanel.setVisible(opened)
        self.advancedButton.setText('Fewer choices  ▴' if opened else 'More choices  ▾')
        if opened:
            self.mainScroll.ensureWidgetVisible(self.advancedPanel)

    def _applyModernTheme(self):
        palette_color = APP.palette().window().color()
        APP.setStyleSheet(branding.stylesheet(palette_color.lightness() < 128))

    def scanSelectedSources(self):
        sources = [
            source_from_job_item(GUI.jobList.item(index))
            for index in range(GUI.jobList.count())
            if GUI.jobList.item(index).icon().isNull()
        ]
        if not sources:
            self.addMessage('Add one or more source files before running the safety scan.', 'warning')
            return
        if hasattr(self, 'preflightScanner') and self.preflightScanner.isRunning():
            return
        profile = self.profiles[str(self.deviceBox.currentText())]['Label']
        output_format = self.formats[str(self.formatBox.currentText())]['format']
        self.preflightButton.setEnabled(False)
        self.preflightButton.setText('Scanning…')
        self.addMessage('<b>Blank-page safety scan started.</b>', 'info')
        self.preflightScanner = SourcePreflightThread(sources, profile, output_format)
        self.preflightScanner.resultsReady.connect(self.showPreflightResults)
        self.preflightScanner.start()

    def showPreflightResults(self, reports):
        self.preflightButton.setEnabled(True)
        self.preflightButton.setText('Check pages now')
        total_errors = sum(len(report.errors) for report in reports)
        total_warnings = sum(len(report.warnings) for report in reports)
        for report in reports:
            icon = 'error' if report.errors else 'warning' if report.warnings else 'info'
            source_name = escape(os.path.basename(report.source.rstrip(os.sep)))
            self.addMessage(f'<b>{source_name}</b>: {escape(report.summary())}', icon)
            for issue in report.issues[:8]:
                issue_icon = 'error' if issue.severity == 'error' else 'warning' if issue.severity == 'warning' else 'info'
                self.addMessage(escape(issue.display()), issue_icon)
            if len(report.issues) > 8:
                self.addMessage(f'…and {len(report.issues) - 8} more issue(s).', 'warning')
        if total_errors:
            self.addMessage(f'<b>Scan blocked:</b> {total_errors} issue(s) must be fixed before safe conversion.', 'error')
        elif total_warnings:
            self.addMessage(f'<b>Scan passed:</b> review {total_warnings} possible issue(s) before conversion.', 'warning')
        else:
            self.addMessage('<b>Scan passed:</b> no likely blank-page causes found.', 'info')

    def selectDefaultOutputFolder(self):
        dname = QFileDialog.getExistingDirectory(MW, 'Select default output folder', self.defaultOutputFolder)
        if self.is_directory_on_kindle(dname):
            return
        if dname != '':
            if sys.platform.startswith('win'):
                dname = dname.replace('/', '\\')
            GUI.defaultOutputFolder = dname

    def is_directory_on_kindle(self, dname):
        path = Path(dname)
        for parent in itertools.chain([path], path.parents):
            if parent.name == 'documents' and parent.parent.joinpath('system').joinpath('thumbnails').is_dir():
                self.addMessage("Cannot select Kindle as output directory", 'error')
                return True

    def selectOutputFolder(self):
        dname = QFileDialog.getExistingDirectory(MW, 'Select output directory', self.lastPath)
        if self.is_directory_on_kindle(dname):
            return
        if dname != '':
            if sys.platform.startswith('win'):
                dname = dname.replace('/', '\\')
            GUI.targetDirectory = dname
        else:
            GUI.targetDirectory = ''
        return GUI.targetDirectory

    def selectFile(self):
        if self.needClean:
            self.needClean = False
            GUI.jobList.clear()
        if self.tar or self.sevenzip:
            fnames = QFileDialog.getOpenFileNames(MW, 'Select file', self.lastPath,
                                                            'Comic (*.cbz *.cbr *.cb7 *.zip *.rar *.7z *.epub *.pdf);;All (*.*)')
        else:
            fnames = QFileDialog.getOpenFileNames(MW, 'Select file', self.lastPath,
                                                            'Books and comics (*.epub *.cbz *.zip *.pdf);;All (*.*)')
        for fname in fnames[0]:
            if fname != '':
                self.lastPath = os.path.abspath(os.path.join(fname, os.pardir))
                self.addSource(fname)

    def selectDir(self):
        if self.needClean:
            self.needClean = False
            GUI.jobList.clear()
 
        dialog = QFileDialog(MW, 'Select input folder(s)', self.lastPath)
        dialog.setFileMode(QFileDialog.FileMode.Directory)
        dialog.setOption(QFileDialog.Option.ShowDirsOnly, True)
        dialog.setOption(QFileDialog.Option.DontUseNativeDialog, True)
        dialog.findChild(QTreeView).setSelectionMode(QAbstractItemView.ExtendedSelection)

        if dialog.exec():
            dnames = dialog.selectedFiles()
            for dname in dnames:
                if dname != '':
                    self.lastPath = os.path.abspath(os.path.join(dname, os.pardir))
                    self.addSource(dname)

    def labelSpreadsStart(self):
        currentJobs = []
        # TODO: make this a function since it's copy pasted
        for i in range(GUI.jobList.count()):
            # Make sure that we don't consider any system message as job to do
            if GUI.jobList.item(i).icon().isNull():
                currentJobs.append(source_from_job_item(GUI.jobList.item(i)))
        for job in currentJobs:
            images = []
            spreads = []
            options, _ = get_options()
            options.profileData = [(600, 800), (600,800)]
            path = getWorkFolder(job, options)
            removeNonImages(path)
            sanitizeTree(path, options)
            flattenTree(path)

            if options.tempdir:
                workdir = mkdtemp('', 'KCC-', os.path.dirname(job))
            else:
                workdir = mkdtemp('', 'KCC-')

            for root, _, files in os.walk(path):
                files.sort(key=OS_SORT_KEY)
                start_index = 0
                if job.endswith('.pdf') or job.endswith('.epub'):
                    start_index = 1
                if options.spreadshift:
                    start_index = 0 if start_index == 1 else 1
                for i in range(start_index, len(files), 2):
                    if i  == len(files) - 1:
                        continue 
                    # TODO: with statements
                    # TODO: ignore 1% of top and bottom too?
                    im1 = Image.open(os.path.join(root, files[i])).convert('1', dither=Dither.NONE)
                    size1 = im1.size
                    crop1 = im1.crop((0, 0, 0.2*size1[0], size1[1]))
                    crop11 = im1.crop((0.01*size1[0], 0, 0.04*size1[0], size1[1]))
                    #crop1 = crop11
                    im2 = Image.open(os.path.join(root, files[i+1])).convert('1', dither=Dither.NONE)
                    size2 = im2.size
                    crop2 = im2.crop((0.8*size2[0], 0, size2[0], size2[1]))
                    crop22 = im2.crop((0.96*size2[0], 0, .99* size2[0], size2[1]))
                    #crop2 = crop22
                    # dst = Image.new('1', (im1.width + im2.width, im1.height))
                    # dst.paste(im2, (0, 0))
                    # dst.paste(im1, (im1.width, 0))
                    hist1 = crop11.histogram()
                    hist2 = crop22.histogram()
                    # TODO: small percentage instead of zero
                    if hist1[0] == 0 or hist1[-1] == 0 or hist2[0] == 0 or hist2[-1] == 0:
                        continue

                    dst = Image.new('1', (crop1.width + crop2.width, crop1.height))

                    dst.paste(crop2, (0, 0))
                    dst.paste(crop1, (crop1.width, 0))
                    dst.save(os.path.join(workdir, f'label-{i:04}.png'))
                    images.append(os.path.join(workdir, f'label-{i:04}.png'))

                if images:
                    dlg = LabelSpreadsDialog(APP.primaryScreen().availableGeometry().height(), images, spreads)
                    dlg.setWindowTitle(job)
                    if dlg.exec() == 1:
                        with open(job+'.json', "w") as fp:
                            # TODO: not very clean to grab index from filename
                            spreads = [int(filename[6:10]) for filename in spreads]
                            json.dump({'spreads': sorted(set(spreads))} , fp) 
                rmtree(path, True)
                rmtree(workdir, True)

    def selectFileMetaEditor(self, sname):
        files = []
        if not sname:
            if QApplication.keyboardModifiers() == Qt.ShiftModifier:
                # Multi-directory selection for bulk editing ComicInfo.xml
                dialog = QFileDialog(MW, 'Select volume directories', self.lastPath)
                dialog.setFileMode(QFileDialog.FileMode.Directory)
                dialog.setOption(QFileDialog.Option.ShowDirsOnly, True)
                dialog.setOption(QFileDialog.Option.DontUseNativeDialog, True)
                
                # Enable multi-selection in the dialog (may not work with native dialog on all platforms)
                file_view = dialog.findChild(QListView, 'listView')
                if file_view:
                    file_view.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
                file_tree = dialog.findChild(QTreeView)
                if file_tree:
                    file_tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
                
                if dialog.exec():
                    selected_dirs = dialog.selectedFiles()
                    if selected_dirs:
                        files = [os.path.join(d, 'ComicInfo.xml') for d in selected_dirs]
                        self.lastPath = os.path.dirname(selected_dirs[0])
            else:
                if self.sevenzip:
                    fnames = QFileDialog.getOpenFileNames(MW, 'Select file(s)', self.lastPath,
                                                          'Comic (*.cbz *.cbr *.cb7)')
                    files = fnames[0]
                    if files:
                        self.lastPath = os.path.abspath(os.path.join(files[0], os.pardir))
                else:
                    self.showDialog("Editor is disabled due to a lack of 7z.", 'error')
                    self.addMessage(f'<a href="{branding.SEVEN_ZIP_URL}">Install 7-Zip from the official site</a>'
                                    ' to edit details inside CBR, RAR, CB7, and 7Z files.', 'warning')
        else:
            files = [sname]
        
        if files:
            try:
                self.editor.loadData(files)
            except Exception as err:
                _, _, traceback = sys.exc_info()
                self.showDialog("Failed to parse metadata!\n\n%s\n\nTraceback:\n%s"
                                % (str(err), sanitizeTrace(traceback)), 'error')
            else:
                self.editor.ui.exec_()

    def clearJobs(self):
        GUI.jobList.clear()

    @staticmethod
    def _openUrl(url):
        QDesktopServices.openUrl(QUrl(url))

    def openAniList(self):
        self._openUrl(branding.ANILIST_URL)

    def openLinkedIn(self):
        self._openUrl(branding.LINKEDIN_URL)

    def openBuyMeACoffee(self):
        self._openUrl(branding.BUY_ME_A_COFFEE_URL)

    def openRedditManga(self):
        self._openUrl(branding.REDDIT_MANGA_URL)

    def openRedditKindle(self):
        self._openUrl(branding.REDDIT_KINDLE_URL)

    def openRedditCollectors(self):
        self._openUrl(branding.REDDIT_COLLECTORS_URL)

    def openFriendlyHelp(self):
        dialog = QDialog(MW)
        dialog.setWindowTitle(f'{branding.APP_SHORT_NAME} — Help & FAQ')
        dialog.resize(660, 640)
        layout = QVBoxLayout(dialog)
        help_view = QTextBrowser(dialog)
        help_view.setOpenExternalLinks(True)
        help_view.setHtml(f'''
            <h1>Help without the tech talk</h1>
            <p><b>The easy recipe:</b> Drop in a book, pick your reader, choose what to make,
            and click <b>Make my book</b>. The safety check is already on.</p>
            <h2>What can I drop in?</h2>
            <p>EPUB, PDF, CBZ, ZIP, or a folder full of JPG/PNG page images. CBR, RAR,
            CB7, and 7Z also work after installing
            <a href="{branding.SEVEN_ZIP_URL}">7-Zip from its official website</a>.</p>
            <h2>Which finished file should I choose?</h2>
            <ul>
              <li><b>Kindle manga — best fit:</b> for manga/comic pages read by USB on Kindle.</li>
              <li><b>Send to Kindle — EPUB:</b> a convenient modern choice for Amazon's Send to Kindle service.</li>
              <li><b>EPUB book → MOBI:</b> for ordinary text EPUBs when you need the older MOBI format.</li>
              <li><b>EPUB, CBZ, or PDF:</b> useful for other readers and apps.</li>
            </ul>
            <h2>Why would pages appear blank?</h2>
            <p>Common causes include a damaged archive, a missing image, a nearly empty page image,
            mismatched file-name capitalization, huge images, or a PNG/device combination that a
            Kindle struggles to decode. The Wizard checks these before it starts and validates the
            finished EPUB again.</p>
            <h2>Why does MOBI ask for Kindle Previewer?</h2>
            <p>The older MOBI maker comes with
            <a href="{branding.KINDLE_PREVIEWER_URL}">Amazon Kindle Previewer</a>. Install it,
            reopen the Wizard, and try again. EPUB, CBZ, and PDF do not need it.</p>
            <h2>Where does the finished book go?</h2>
            <p>Beside the original file by default. Turn on <b>Save finished files in my chosen folder</b>
            if you want one familiar destination.</p>
            <h2>Where can I find manga recommendations?</h2>
            <p>Try <a href="{branding.ANILIST_URL}">AniList</a> for recommendations and tracking,
            <a href="{branding.REDDIT_MANGA_URL}">r/manga</a> for discussion,
            <a href="{branding.REDDIT_KINDLE_URL}">r/kindle</a> for device help, or
            <a href="{branding.REDDIT_COLLECTORS_URL}">r/MangaCollectors</a> for collecting.</p>
            <h2>Who made this friendly edition?</h2>
            <p>Follow or connect with <a href="{branding.LINKEDIN_URL}">Isaiah Lee on LinkedIn</a>.</p>
            <h2>Want to support MangaBookWizard?</h2>
            <p><a href="{branding.BUY_ME_A_COFFEE_URL}">Buy Me a Coffee</a> is an optional way to support
            continued work on the free app. Conversion features are never locked behind payment.</p>
            <p><i>Please only convert books you own or have permission to use.</i></p>
        ''')
        layout.addWidget(help_view)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, parent=dialog)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()

    def modeChange(self, mode):
        if mode == 1:
            self.currentMode = 1
            GUI.gammaWidget.setVisible(False)
            GUI.customWidget.setVisible(False)
        elif mode == 2:
            self.currentMode = 2
            GUI.gammaWidget.setVisible(True)
            GUI.customWidget.setVisible(False)
        elif mode == 3:
            self.currentMode = 3
            GUI.gammaWidget.setVisible(True)
            GUI.customWidget.setVisible(True)

    def modeConvert(self, enable):
        if enable < 1:
            status = False
        else:
            status = True
        GUI.editorButton.setEnabled(status)
        GUI.deviceBox.setEnabled(status)
        GUI.defaultOutputFolderButton.setEnabled(status)
        GUI.clearButton.setEnabled(status)
        GUI.fileButton.setEnabled(status)
        GUI.directoryButton.setEnabled(status)
        GUI.preflightButton.setEnabled(status)
        GUI.formatBox.setEnabled(status)
        GUI.optionWidget.setEnabled(status)
        GUI.gammaWidget.setEnabled(status)
        GUI.customWidget.setEnabled(status)
        GUI.convertButton.setEnabled(True)
        if enable == 1:
            self.conversionAlive = False
            self.worker.sync()
            GUI.convertButton.setIcon(QIcon())
            GUI.convertButton.setText('Make my book')
            GUI.centralWidget.setAcceptDrops(True)
        elif enable == 0:
            self.conversionAlive = True
            self.worker.sync()
            GUI.convertButton.setIcon(QIcon())
            GUI.convertButton.setText('Stop')
            GUI.centralWidget.setAcceptDrops(False)
        elif enable == -1:
            self.conversionAlive = True
            self.worker.sync()
            GUI.convertButton.setEnabled(False)
            GUI.centralWidget.setAcceptDrops(False)

    def togglegammaBox(self, value):
        if value:
            if self.currentMode != 3:
                self.modeChange(2)
        else:
            if self.currentMode != 3:
                self.modeChange(1)

    def togglecroppingBox(self, value):
        if value:
            GUI.croppingWidget.setVisible(True)
        else:
            GUI.croppingWidget.setVisible(False)
            self.changeCroppingPower(100)  # 1.0

    def togglejpegqualityBox(self, value):
        if value:
            GUI.jpegQualityWidget.setVisible(True)
        else:
            GUI.jpegQualityWidget.setVisible(False)

    def togglewebtoonBox(self, value):
        if value:
            self.addMessage('You can choose a taller device profile to get taller cuts in webtoon mode.', 'info')
            self.addMessage('Try reading webtoon panels side by side in landscape!', 'info')
            GUI.qualityBox.setEnabled(False)
            GUI.qualityBox.setChecked(False)
            GUI.mangaBox.setEnabled(False)
            GUI.mangaBox.setChecked(False)
            GUI.rotateBox.setEnabled(False)
            GUI.borderBox.setEnabled(False)
            GUI.borderBox.setCheckState(Qt.CheckState.PartiallyChecked)
            # GUI.upscaleBox.setEnabled(False)
            # GUI.upscaleBox.setChecked(False)
            GUI.croppingBox.setEnabled(False)
            GUI.croppingBox.setChecked(False)
            GUI.interPanelCropBox.setEnabled(False)
            GUI.interPanelCropBox.setChecked(False)
            GUI.autoLevelBox.setEnabled(False)
            GUI.autoLevelBox.setChecked(False)
            GUI.autocontrastBox.setEnabled(False)
            GUI.autocontrastBox.setChecked(False)
        else:
            profile = GUI.profiles[str(GUI.deviceBox.currentText())]
            if profile['PVOptions']:
                GUI.qualityBox.setEnabled(True)
            GUI.mangaBox.setEnabled(True)
            GUI.rotateBox.setEnabled(True)
            GUI.borderBox.setEnabled(True)
            profile = GUI.profiles[str(GUI.deviceBox.currentText())]
            if not profile['Label'].startswith('KS') or True:
                GUI.upscaleBox.setEnabled(True)
            GUI.croppingBox.setEnabled(True)
            GUI.interPanelCropBox.setEnabled(True)
            GUI.autoLevelBox.setEnabled(True)
            GUI.autocontrastBox.setEnabled(True)


    def togglequalityBox(self, value):
        profile = GUI.profiles[str(GUI.deviceBox.currentText())]
        if value == 2:
            if profile['Label'] not in ('K57', 'KPW', 'K810') :
                self.addMessage('This option is intended for older Kindle models.', 'warning')
                self.addMessage('On this device, there will be conversion speed and quality issues.', 'warning')
                self.addMessage('Use the Kindle Scribe profile if you want higher resolution when zooming.', 'warning')
            GUI.upscaleBox.setEnabled(False)
            GUI.upscaleBox.setChecked(True)
        else:
            GUI.upscaleBox.setEnabled(True)
            GUI.upscaleBox.setChecked(profile['DefaultUpscale'])

    def toggleImageFormatBox(self, value):
        profile = GUI.profiles[str(GUI.deviceBox.currentText())]
        if value == 1:
            if profile['Label'].startswith('KS'):
                current_format = GUI.formats[str(GUI.formatBox.currentText())]['format']
                for bad_format in ('MOBI', 'EPUB'):
                    if bad_format in current_format:
                        self.addMessage('Scribe PNG MOBI/EPUB has a lot of problems like blank pages/sections. Use JPG instead.', 'warning')
                        break
            GUI.pngLegacyBox.setEnabled(True)
            GUI.noQuantizeBox.setEnabled(True)
            GUI.forcePngRgbBox.setEnabled(True)
        else:
            GUI.pngLegacyBox.setEnabled(False)
            GUI.noQuantizeBox.setEnabled(False)
            GUI.forcePngRgbBox.setEnabled(False)           


    def togglechunkSizeCheckBox(self, value):
        GUI.chunkSizeWidget.setVisible(value)

    def toggletitleEdit(self, value):
        if value:
            self.metadataTitleBox.setChecked(False)

    def togglefileFusionBox(self, value):
        if value:
            GUI.metadataTitleBox.setChecked(False)
            GUI.metadataTitleBox.setEnabled(False)
        else:
            GUI.metadataTitleBox.setEnabled(True)

    def togglemetadataTitleBox(self, value):
        if value:
            GUI.titleEdit.setText(None)

    def editSourceMetadata(self, item):
        if item.icon().isNull():
            sname = source_from_job_item(item)
            if os.path.isdir(sname):
                sname = os.path.join(sname, "ComicInfo.xml")
            self.selectFileMetaEditor(sname)

    def changeGamma(self, value):
        valueRaw = int(5 * round(float(value) / 5))
        value = '%.2f' % (float(valueRaw) / 100)
        if float(value) <= 0.09:
            GUI.gammaLabel.setText('Gamma: Auto')
        else:
            GUI.gammaLabel.setText('Gamma: ' + str(value))
        GUI.gammaSlider.setValue(valueRaw)
        self.gammaValue = value

    def changeCroppingPower(self, value):
        valueRaw = int(5 * round(float(value) / 5))
        value = '%.2f' % (float(valueRaw) / 100)
        GUI.croppingPowerLabel.setText('Border trimming strength: ' + str(value))
        GUI.croppingPowerSlider.setValue(valueRaw)
        self.croppingPowerValue = value

    def changeDevice(self):
        profile = GUI.profiles[str(GUI.deviceBox.currentText())]
        if profile['ForceExpert']:
            self.modeChange(3)
        elif GUI.gammaBox.isChecked():
            self.modeChange(2)
        else:
            self.modeChange(1)
        GUI.colorBox.setChecked(profile['ForceColor'])
        self.changeFormat()
        if not GUI.webtoonBox.isChecked():
            GUI.qualityBox.setEnabled(profile['PVOptions'])
        GUI.upscaleBox.setChecked(profile['DefaultUpscale'])
        if profile['Label'].startswith('KS') and False:
            GUI.upscaleBox.setDisabled(True)
        else:
            if not GUI.webtoonBox.isChecked() or True:
                GUI.upscaleBox.setEnabled(True)
        if profile['Label'] == 'KCS':
            current_format = GUI.formats[str(GUI.formatBox.currentText())]['format']
            for bad_format in ('MOBI', 'EPUB'):
                if bad_format in current_format:
                    self.addMessage('Colorsoft MOBI/EPUB can have blank pages. Just go back a few pages, exit, and reenter book.', 'info')
                    break
        elif profile['Label'] == 'KDX':
            GUI.mozJpegBox.setCheckState(Qt.CheckState.PartiallyChecked)
            GUI.borderBox.setCheckState(Qt.CheckState.PartiallyChecked)
            GUI.pngLegacyBox.setChecked(True)
        if not profile['PVOptions']:
            GUI.qualityBox.setChecked(False)
        if str(GUI.deviceBox.currentText()) == 'Other':
            self.addMessage('For an unlisted reader, open More choices and enter its screen width and height.', 'info')

    def changeFormat(self, outputformat=None):
        profile = GUI.profiles[str(GUI.deviceBox.currentText())]
        if outputformat is not None:
            GUI.formatBox.setCurrentIndex(outputformat)
        else:
            GUI.formatBox.setCurrentIndex(profile['DefaultFormat'])
        if not GUI.webtoonBox.isChecked():
            GUI.qualityBox.setEnabled(profile['PVOptions'])
        if GUI.formats[str(GUI.formatBox.currentText())]['format'] == 'MOBI':
            GUI.outputSplit.setEnabled(True)
        else:
            GUI.outputSplit.setEnabled(False)
            GUI.outputSplit.setChecked(False)
        if (GUI.formats[str(GUI.formatBox.currentText())]['format'] == 'EPUB-200MB' or
            GUI.formats[str(GUI.formatBox.currentText())]['format'] == 'MOBI+EPUB-200MB'):
            GUI.chunkSizeCheckBox.setEnabled(False)
            GUI.chunkSizeCheckBox.setChecked(False)
        elif GUI.formats[str(GUI.formatBox.currentText())]['format'] == 'KFX':
            GUI.mozJpegBox.setCheckState(Qt.CheckState.PartiallyChecked)
            GUI.upscaleBox.setChecked(True)
        elif not GUI.webtoonBox.isChecked():
            GUI.chunkSizeCheckBox.setEnabled(True)
        if GUI.formats[str(GUI.formatBox.currentText())]['format'] in ('CBZ', 'PDF') and not GUI.webtoonBox.isChecked():
            self.addMessage("Partially check W/B Margins if you don't want the Wizard to extend the image margins.", 'info')
            GUI.borderBox.setCheckState(Qt.CheckState.PartiallyChecked)
        else:
            GUI.borderBox.setCheckState(Qt.CheckState.Unchecked)

    def stripTags(self, html):
        s = HTMLStripper()
        s.feed(html)
        return s.get_data()

    def addMessage(self, message, icon, replace=False):
        labels = {'info': 'INFO', 'warning': 'CHECK', 'error': 'ERROR', 'success': 'READY'}
        if icon:
            message = f'<b>{labels.get(icon, "NOTE")}:</b> {message}'
        item = QListWidgetItem('   ' + self.stripTags(message))
        if replace:
            GUI.jobList.takeItem(GUI.jobList.count() - 1)
        # Due to lack of HTML support in QListWidgetItem we overlay text field with QLabel
        # We still fill original text field with transparent content to trigger creation of horizontal scrollbar
        item.setForeground(QColor('transparent'))
        label = QLabel(message)
        label.setOpenExternalLinks(True)
        label.setWordWrap(True)
        label.setContentsMargins(4, 3, 4, 3)
        label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        GUI.jobList.addItem(item)
        GUI.jobList.setItemWidget(item, label)
        GUI.jobList.scrollToBottom()

    def addSource(self, source):
        source = str(source)
        friendly_name = Path(source.rstrip(os.sep)).name or source
        item = QListWidgetItem(friendly_name)
        item.setData(Qt.ItemDataRole.UserRole, source)
        item.setToolTip(source)
        GUI.jobList.addItem(item)
        GUI.jobList.scrollToBottom()

    def showDialog(self, message, kind):
        if kind == 'error':
            QMessageBox.critical(MW, f'{branding.APP_SHORT_NAME} - Error', message, QMessageBox.StandardButton.Ok)
        elif kind == 'question':
            GUI.versionCheck.setAnswer(QMessageBox.question(MW, f'{branding.APP_SHORT_NAME} - Question', message,
                                                                      QMessageBox.Yes,
                                                                      QMessageBox.No))

    def updateProgressbar(self, command):
        if command == 'tick':
            GUI.progressBar.setValue(GUI.progressBar.value() + 1)
        elif command.isdigit():
            GUI.progressBar.setMaximum(int(command) - 1)
            GUI.toolWidget.hide()
            GUI.progressBar.reset()
            GUI.progressBar.show()
        else:
            GUI.progressBar.setFormat(command)

    def hideProgressBar(self):
        GUI.progressBar.hide()
        GUI.toolWidget.show()

    def convertStart(self):
        if self.conversionAlive:
            GUI.convertButton.setEnabled(False)
            self.addMessage('The process will be interrupted. Please wait.', 'warning')
            self.conversionAlive = False
            self.worker.sync()
        else:
            if QApplication.keyboardModifiers() == Qt.KeyboardModifier.ShiftModifier:
                if not self.selectOutputFolder():
                    return
            elif GUI.defaultOutputFolderBox.isChecked():
                self.targetDirectory = self.defaultOutputFolder
            else:
                GUI.targetDirectory = ''
            self.progress.start()
            if self.needClean:
                self.needClean = False
                GUI.jobList.clear()
            if GUI.jobList.count() == 0:
                self.addMessage('No files selected! Please choose files to convert.', 'error')
                self.needClean = True
                return
            source_items = [self.jobList.item(i) for i in range(self.jobList.count())
                            if self.jobList.item(i).icon().isNull()]
            if not source_items:
                self.addMessage('Drop in a book or choose a file first.', 'error')
                self.needClean = True
                return
            if GUI.defaultOutputFolderBox.checkState() == Qt.CheckState.PartiallyChecked:
                parent = Path(source_from_job_item(source_items[0])).parent
                target_path = parent.joinpath(f"{parent.name}")
                if not target_path.exists():
                    target_path.mkdir()
                self.targetDirectory = str(target_path)
            if self.currentMode > 2 and (GUI.widthBox.value() == 0 or GUI.heightBox.value() == 0):
                GUI.jobList.clear()
                self.addMessage('Target resolution is not set!', 'error')
                self.needClean = True
                return
            if 'MOBI' in GUI.formats[str(GUI.formatBox.currentText())]['format'] and not self.kindleGen:
                self.detectKindleGen()
                if not self.kindleGen:
                    GUI.jobList.clear()
                    self.display_kindlegen_missing()
                    self.needClean = True
                    return
            self.worker.start()

    def display_kindlegen_missing(self):
        self.addMessage(
            f'Older Kindle/MOBI files need the free tools included with '
            f'<a href="{branding.KINDLE_PREVIEWER_URL}"><b>Amazon Kindle Previewer</b></a>. '
            f'Install it and reopen the Wizard, or choose an EPUB option instead.',
            'error'
        )

    def saveSettings(self, event):
        if self.conversionAlive:
            GUI.convertButton.setEnabled(False)
            self.addMessage('The process will be interrupted. Please wait.', 'warning')
            self.conversionAlive = False
            self.worker.sync()
            event.ignore()
        if not GUI.convertButton.isEnabled():
            event.ignore()
        self.settings.setValue('settingsVersion', __version__)
        self.settings.setValue('lastPath', self.lastPath)
        self.settings.setValue('defaultOutputFolder', self.defaultOutputFolder)
        self.settings.setValue('lastDevice', GUI.deviceBox.currentIndex())
        self.settings.setValue('currentFormat', GUI.formatBox.currentIndex())
        self.settings.setValue('startNumber', self.startNumber + 1)
        self.settings.setValue('windowSize', str(MW.size().width()) + 'x' + str(MW.size().height()))
        self.settings.setValue('options', {'mangaBox': GUI.mangaBox.checkState(),
                                           'lightnovelBox': GUI.lightnovelBox.checkState(),
                                           'ebokBox': GUI.ebokBox.checkState(),
                                           'invertDirectionBox': GUI.invertDirectionBox.checkState(),
                                           'languageEdit': GUI.languageEdit.text(),
                                           'rotateBox': GUI.rotateBox.checkState(),
                                           'qualityBox': GUI.qualityBox.checkState(),
                                           'vertical4PanelBox': GUI.vertical4PanelBox.checkState(),
                                           'gammaBox': GUI.gammaBox.checkState(),
                                           'autoLevelBox': GUI.autoLevelBox.checkState(),
                                           'autocontrastBox': GUI.autocontrastBox.checkState(),
                                           'croppingBox': GUI.croppingBox.checkState(),
                                           'croppingPowerSlider': float(self.croppingPowerValue) * 100,
                                           'preserveMarginBox': self.preserveMarginBox.value(),
                                           'interPanelCropBox': GUI.interPanelCropBox.checkState(),
                                           'upscaleBox': GUI.upscaleBox.checkState(),
                                           'borderBox': GUI.borderBox.checkState(),
                                           'webtoonBox': GUI.webtoonBox.checkState(),
                                           'outputSplit': GUI.outputSplit.checkState(),
                                           'colorBox': GUI.colorBox.checkState(),
                                           'eraseRainbowBox': GUI.eraseRainbowBox.checkState(),
                                           'disableProcessingBox': GUI.disableProcessingBox.checkState(),
                                           'legacyExtractBox': GUI.legacyExtractBox.checkState(),
                                           'pdfWidthBox': GUI.pdfWidthBox.checkState(),
                                           'smartCoverCropBox': GUI.smartCoverCropBox.checkState(),
                                           'coverFillBox': GUI.coverFillBox.checkState(),
                                           'metadataTitleBox': GUI.metadataTitleBox.checkState(),
                                           'keepComicInfoBox': GUI.keepComicInfoBox.checkState(),
                                           'mozJpegBox': GUI.mozJpegBox.checkState(),
                                           'forcePngRgbBox': GUI.forcePngRgbBox.checkState(),
                                           'webpBox': GUI.webpBox.checkState(),
                                           'pngLegacyBox': GUI.pngLegacyBox.checkState(),
                                           'noQuantizeBox': GUI.noQuantizeBox.checkState(),
                                           'jpegQualityBox': GUI.jpegQualityBox.checkState(),
                                           'jpegQuality': GUI.jpegQualitySpinBox.value(),
                                           'widthBox': GUI.widthBox.value(),
                                           'heightBox': GUI.heightBox.value(),
                                           'deleteBox': GUI.deleteBox.checkState(),
                                           'tempDirBox': GUI.tempDirBox.checkState(),
                                           'spreadShiftBox': GUI.spreadShiftBox.checkState(),
                                           'onePageLandscapeBox': GUI.onePageLandscapeBox.checkState(),
                                           'fileFusionBox': GUI.fileFusionBox.checkState(),
                                           'blankPageScanBox': GUI.blankPageScanBox.checkState(),
                                           'defaultOutputFolderBox': GUI.defaultOutputFolderBox.checkState(),
                                           'noRotateBox': GUI.noRotateBox.checkState(),
                                           'rotateRightBox': GUI.rotateRightBox.checkState(),
                                           'rotateFirstBox': GUI.rotateFirstBox.checkState(),
                                           'maximizeStrips': GUI.maximizeStrips.checkState(),
                                           'gammaSlider': float(self.gammaValue) * 100,
                                           'chunkSizeCheckBox': GUI.chunkSizeCheckBox.checkState(),
                                           'chunkSizeBox': GUI.chunkSizeBox.value()})
        self.settings.sync()
        self.tray.hide()

    def handleMessage(self, message):
        MW.raise_()
        MW.activateWindow()
        if type(message) is bytes:
            message = message.decode('UTF-8')
        existing_sources = {
            source_from_job_item(GUI.jobList.item(index))
            for index in range(GUI.jobList.count())
            if GUI.jobList.item(index).icon().isNull()
        }
        if not self.conversionAlive and message != 'ARISE' and message not in existing_sources:
            if self.needClean:
                self.needClean = False
                GUI.jobList.clear()
            formats = ['.pdf', '.epub', '.cbz', '.zip']
            if self.tar or self.sevenzip:
                formats.extend(['.cb7', '.7z', '.cbr', '.rar'])
            if os.path.isdir(message):
                self.addSource(message)
            elif os.path.isfile(message):
                extension = os.path.splitext(message)
                if extension[1].lower() in formats:
                    self.addSource(message)
                else:
                    self.addMessage('Unsupported file type for ' + message, 'error')

    def dragAndDrop(self, e):
        e.accept()

    def dragAndDropAccepted(self, e):
        for url in e.mimeData().urls():
            # QUrl handles spaces, Unicode, drive letters, and UNC shares more
            # reliably than rebuilding a filesystem path from the URL text.
            local_path = url.toLocalFile()
            if local_path:
                self.handleMessage(os.path.normpath(local_path))
        # sorting may conflict with manual file fusion order
        # GUI.jobList.sortItems()

    def forceShutdown(self):
        self.saveSettings(None)
        sys.exit(0)

    def detectKindleGen(self, startup=False):
        if not sys.platform.startswith('win'):
            try:
                os.chmod('/usr/local/bin/kindlegen', 0o755)
            except Exception:
                pass
        try:
            versionCheck = subprocess_run(['kindlegen', '-locale', 'en'], stdout=PIPE, stderr=STDOUT, encoding='UTF-8', errors='ignore', check=True)
            self.kindleGen = True
            for line in versionCheck.stdout.splitlines():
                if 'Amazon kindlegen' in line:
                    versionCheck = line.split('V')[1].split(' ')[0]
                    if Version(versionCheck) < Version('2.9'):
                        self.addMessage('Your <a href="https://www.amazon.com/b?node=23496309011">KindleGen</a>'
                                        ' is outdated! MOBI conversion might fail.', 'warning')
                    break
        except (FileNotFoundError, CalledProcessError):
            self.kindleGen = False
            if startup:
                self.display_kindlegen_missing()
        except OSError as e:
            self.kindleGen = False
            if startup:
                error = (f"The older Kindle/MOBI helper could not start: {e.strerror}\n\n"
                         "Reinstall Amazon Kindle Previewer, then reopen the Wizard.")
                self.showDialog(error, 'error')

    def __init__(self, kccapp, kccwindow):
        global APP, MW, GUI
        APP = kccapp
        MW = kccwindow
        GUI = self
        self.setupUi(MW)
        self._buildModernShell()
        self.editor = KCCGUI_MetaEditor()
        self.icons = Icons()
        self.settings = QSettings(branding.SETTINGS_ORGANIZATION, branding.SETTINGS_APPLICATION)
        self.settingsVersion = self.settings.value('settingsVersion', '', type=str)
        self.lastPath = self.settings.value('lastPath', '', type=str)
        self.defaultOutputFolder = str(self.settings.value('defaultOutputFolder', '', type=str))
        if not os.path.exists(self.defaultOutputFolder):
            self.defaultOutputFolder = ''

        # default is Kindle Paperwhite 12th Gen
        self.lastDevice = self.settings.value('lastDevice', 3, type=int)

        self.currentFormat = self.settings.value('currentFormat', 0, type=int)
        self.startNumber = self.settings.value('startNumber', 0, type=int)
        self.windowSize = self.settings.value('windowSize', '0x0', type=str)
        default_options = default_gui_options()
        try:
            self.options = self.settings.value('options', default_options)
        except Exception:
            self.options = default_options
        self.worker = WorkerThread()
        self.versionCheck = VersionThread()
        self.progress = ProgressThread()
        self.tray = SystemTrayIcon()
        self.conversionAlive = False
        self.needClean = True
        self.kindleGen = False
        self.gammaValue = 1.0
        self.croppingPowerValue = 1.0
        self.currentMode = 1
        self.targetDirectory = ''
        if sys.platform.startswith(('win', 'linux')):
            APP.setStyle('Fusion')
        if sys.platform.startswith('win'):
            # noinspection PyUnresolvedReferences
            from psutil import BELOW_NORMAL_PRIORITY_CLASS
            self.p = Process(os.getpid())
            self.p.nice(BELOW_NORMAL_PRIORITY_CLASS)
            self.p.ionice(1)
        elif sys.platform.startswith('linux'):
            APP.setStyle('fusion')
            if self.windowSize == '0x0':
                MW.resize(860, 860)
        elif sys.platform.startswith('darwin'):
            for element in ['editorButton', 'defaultOutputFolderButton', 'clearButton', 'fileButton', 'deviceBox',
                            'convertButton', 'formatBox']:
                getattr(GUI, element).setMinimumSize(QSize(0, 0))
            GUI.gridLayout.setContentsMargins(-1, -1, -1, -1)
            for element in ['gridLayout_2', 'gridLayout_3', 'gridLayout_4', 'gridLayout_6', 'horizontalLayout_2']:
                getattr(GUI, element).setContentsMargins(-1, 0, -1, 0)
            if self.windowSize == '0x0':
                MW.resize(860, 860)

        self.formats = {  # friendly text, icon, internal output format
            "Kindle manga — best fit (MOBI)": {'icon': 'MOBI', 'format': 'MOBI'},
            "EPUB — works almost everywhere": {'icon': 'EPUB', 'format': 'EPUB'},
            "CBZ — keep comic pages": {'icon': 'CBZ', 'format': 'CBZ'},
            "PDF — easy to share": {'icon': 'EPUB', 'format': 'PDF'},
            "Send to Kindle — EPUB": {'icon': 'KFX', 'format': 'KFX'},
            "EPUB book → older Kindle (MOBI)": {'icon': 'MOBI', 'format': 'MOBI-PASSTHROUGH'},
        }


        self.profiles = {
            "Kindle Oasis 9/10": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                                 'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KO'},
            "Kindle 8/10": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                       'DefaultUpscale': False, 'ForceColor': False, 'Label': 'K810'},
            "Kindle Oasis 8": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                             'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KPW34'},
            "Kindle Voyage": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                              'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KV'},
            "Kindle 1860x1920": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KS1860',
            },
            "Kindle 1920x1920": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KS1920',
            },
            "Kindle 1240x1860": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KS1240',
            },
            "Kindle 1324x1986": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KS1324',
            },
            "Kindle Scribe 1/2": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KS',
            },
            "Kindle Scribe 3": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 3, 'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KS3',
            },
            "Kindle Scribe Colorsoft": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 3, 'DefaultUpscale': False, 'ForceColor': True, 'Label': 'KSCS',
            },
            "Kindle 11": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': True, 'ForceColor': False, 'Label': 'K11',
            },
            "Kindle Paperwhite 11": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KPW5',
            },
            "Kindle Paperwhite 12": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KPW6',
            },
            "Kindle Colorsoft": {
                'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0, 'DefaultUpscale': True, 'ForceColor': True, 'Label': 'KCS',
            },
            "Kindle Paperwhite 7/10": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                              'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KPW34'},
            "Kindle Paperwhite 5/6": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                              'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KPW'},
            "Kindle 4/5/7": {'PVOptions': True, 'ForceExpert': False, 'DefaultFormat': 0,
                       'DefaultUpscale': False, 'ForceColor': False, 'Label': 'K57'},
            "Kindle DX": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 2,
                              'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KDX'},
            "Kobo Mini/Touch": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                                'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KoMT'},
            "Kobo Glo": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                         'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KoG'},
            "Kobo Glo HD": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                            'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KoGHD'},
            "Kobo Aura": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                          'DefaultUpscale': False, 'ForceColor': False, 'Label': 'KoA'},
            "Kobo Aura HD": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                             'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KoAHD'},
            "Kobo Aura H2O": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                              'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KoAH2O'},
            "Kobo Aura ONE": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                              'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KoAO'},
            "Kobo Clara HD": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                              'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KoC'},
            "Kobo Libra H2O": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                               'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KoL'},
            "Kobo Forma": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1,
                           'DefaultUpscale': True, 'ForceColor': False, 'Label': 'KoF'},
            "Kindle 1": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 0,
                         'DefaultUpscale': False, 'ForceColor': False, 'Label': 'K1'},
            "Kindle 2": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 0,
                         'DefaultUpscale': False, 'ForceColor': False, 'Label': 'K2'},
            "Kindle Keyboard": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 0,
                                'DefaultUpscale': False, 'ForceColor': False, 'Label': 'K34'},
            "Kindle Touch": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 0,
                             'DefaultUpscale': False, 'ForceColor': False, 'Label': 'K34'},
            "Kobo Nia": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': False,
                         'Label': 'KoN'},
            "Kobo Clara 2E": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': False,
                              'Label': 'KoC'},
            "Kobo Clara Colour": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': True,
                              'Label': 'KoCC'},
            "Kobo Libra 2": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': False,
                             'Label': 'KoL'},
            "Kobo Libra Colour": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': True,
                             'Label': 'KoLC'},
            "Kobo Sage": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': False,
                          'Label': 'KoS'},
            "Kobo Elipsa": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 1, 'DefaultUpscale': True, 'ForceColor': False,
                            'Label': 'KoE'},
            "reMarkable 1": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 3, 'DefaultUpscale': True, 'ForceColor': False,
                             'Label': 'Rmk1'},
            "reMarkable 2": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 3, 'DefaultUpscale': True, 'ForceColor': False,
                             'Label': 'Rmk2'},
            "reMarkable Paper Pro": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 3, 'DefaultUpscale': True, 'ForceColor': True,
                             'Label': 'RmkPP'},
            "reMarkable Paper Pro Move": {'PVOptions': False, 'ForceExpert': False, 'DefaultFormat': 3, 'DefaultUpscale': True, 'ForceColor': True,
                             'Label': 'RmkPPMove'},
            "Other": {'PVOptions': False, 'ForceExpert': True, 'DefaultFormat': 1, 'DefaultUpscale': False, 'ForceColor': False,
                      'Label': 'OTHER'},
        }
        profilesGUI = [
            "Kindle Scribe Colorsoft",
            "Kindle Scribe 3",
            "Kindle Colorsoft",
            "Kindle Paperwhite 12",
            "Kindle Scribe 1/2",
            "Kindle Paperwhite 11",
            "Kindle 11",
            "Kindle Oasis 9/10",
            "Separator",
            "Kobo Clara 2E",
            "Kobo Clara Colour",
            "Kobo Sage",
            "Kobo Libra 2",
            "Kobo Libra Colour",
            "Kobo Elipsa",
            "Kobo Nia",
            "Separator",
            "reMarkable 1",
            "reMarkable 2",
            "reMarkable Paper Pro",
            "reMarkable Paper Pro Move",
            "Separator",
            "Other",
            "Separator",
            "Kindle 1324x1986",
            "Kindle 1920x1920",
            "Kindle 1860x1920",
            "Kindle 1240x1860",
            "Kindle 8/10",
            "Kindle Oasis 8",
            "Kindle Paperwhite 7/10",
            "Kindle Voyage",
            "Kindle Paperwhite 5/6",
            "Kindle 4/5/7",
            "Kindle Touch",
            "Kindle Keyboard",
            "Kindle DX",
            "Kindle 2",
            "Kindle 1",
            "Separator",
            "Kobo Aura",
            "Kobo Aura ONE",
            "Kobo Aura H2O",
            "Kobo Aura HD",
            "Kobo Clara HD",
            "Kobo Forma",
            "Kobo Glo HD",
            "Kobo Glo",
            "Kobo Libra H2O",
            "Kobo Mini/Touch",
        ]

        self.addMessage('<b>Start here:</b> Drop a manga, book, PDF, comic archive, or page folder into this box.', 'info')
        self.addMessage('<b>No-fuss defaults are already on.</b> Pick your reader, then click “Make my book.”', 'info')
        
        self.tar = TAR in available_archive_tools()
        self.sevenzip = SEVENZIP in available_archive_tools()
        if not any([self.tar, self.sevenzip]):
            self.addMessage(f'<a href="{branding.SEVEN_ZIP_URL}">Install 7-Zip from the official site</a>'
                            ' only if you use CBR, RAR, CB7, or 7Z. EPUB, CBZ, ZIP, and PDF already work.', 'warning')
        self.detectKindleGen(False)

        APP.messageFromOtherInstance.connect(self.handleMessage)
        GUI.defaultOutputFolderButton.clicked.connect(self.selectDefaultOutputFolder)
        GUI.clearButton.clicked.connect(self.clearJobs)
        GUI.fileButton.clicked.connect(self.selectFile)
        GUI.directoryButton.clicked.connect(self.selectDir)
        GUI.editorButton.clicked.connect(self.selectFileMetaEditor)
        GUI.anilistButton.clicked.connect(self.openAniList)
        GUI.linkedInButton.clicked.connect(self.openLinkedIn)
        GUI.buyMeACoffeeButton.clicked.connect(self.openBuyMeACoffee)
        GUI.redditMangaButton.clicked.connect(self.openRedditManga)
        GUI.redditKindleButton.clicked.connect(self.openRedditKindle)
        GUI.redditCollectorsButton.clicked.connect(self.openRedditCollectors)
        GUI.supportButton.clicked.connect(self.openBuyMeACoffee)
        GUI.helpButton.clicked.connect(self.openFriendlyHelp)
        GUI.advancedButton.toggled.connect(self._toggleAdvanced)
        GUI.preflightButton.clicked.connect(self.scanSelectedSources)
        GUI.convertButton.clicked.connect(self.convertStart)
        GUI.labelSpreadsButton.clicked.connect(self.labelSpreadsStart)
        GUI.gammaSlider.valueChanged.connect(self.changeGamma)
        GUI.gammaBox.stateChanged.connect(self.togglegammaBox)
        GUI.croppingBox.stateChanged.connect(self.togglecroppingBox)
        GUI.croppingPowerSlider.valueChanged.connect(self.changeCroppingPower)
        GUI.jpegQualityBox.stateChanged.connect(self.togglejpegqualityBox)
        GUI.webtoonBox.stateChanged.connect(self.togglewebtoonBox)
        GUI.qualityBox.stateChanged.connect(self.togglequalityBox)
        GUI.mozJpegBox.stateChanged.connect(self.toggleImageFormatBox)
        GUI.chunkSizeCheckBox.stateChanged.connect(self.togglechunkSizeCheckBox)
        GUI.deviceBox.activated.connect(self.changeDevice)
        GUI.formatBox.activated.connect(self.changeFormat)
        GUI.titleEdit.textChanged.connect(self.toggletitleEdit)
        GUI.fileFusionBox.stateChanged.connect(self.togglefileFusionBox)
        GUI.metadataTitleBox.stateChanged.connect(self.togglemetadataTitleBox)
        GUI.jobList.itemDoubleClicked.connect(self.editSourceMetadata)
        MW.progressBarTick.connect(self.updateProgressbar)
        MW.modeConvert.connect(self.modeConvert)
        MW.addMessage.connect(self.addMessage)
        MW.showDialog.connect(self.showDialog)
        MW.hideProgressBar.connect(self.hideProgressBar)
        MW.forceShutdown.connect(self.forceShutdown)
        MW.closeEvent = self.saveSettings
        MW.addTrayMessage.connect(self.tray.addTrayMessage)

        GUI.centralWidget.setAcceptDrops(True)
        GUI.centralWidget.dragEnterEvent = self.dragAndDrop
        GUI.centralWidget.dropEvent = self.dragAndDropAccepted

        self.modeChange(1)
        for profile in profilesGUI:
            if profile == "Other":
                GUI.deviceBox.addItem(self.icons.deviceOther, profile)
            elif profile == "Separator":
                GUI.deviceBox.insertSeparator(GUI.deviceBox.count() + 1)
            elif 'reM' in profile:
                GUI.deviceBox.addItem(self.icons.deviceRmk, profile)
            elif 'Ko' in profile:
                GUI.deviceBox.addItem(self.icons.deviceKobo, profile)
            else:
                GUI.deviceBox.addItem(self.icons.deviceKindle, profile)
        for f in self.formats:
            GUI.formatBox.addItem(getattr(self.icons, self.formats[f]['icon'] + 'Format'), f)
        if self.lastDevice >= GUI.deviceBox.count():
            self.lastDevice = 0
        if profilesGUI[self.lastDevice] == "Separator":
            self.lastDevice = 0
        if self.currentFormat >= GUI.formatBox.count():
            self.currentFormat = 0
        GUI.deviceBox.setCurrentIndex(self.lastDevice)
        self.changeDevice()
        if self.currentFormat != self.profiles[str(GUI.deviceBox.currentText())]['DefaultFormat']:
            self.changeFormat(self.currentFormat)
        for option in self.options:
            if str(option) == "widthBox":
                GUI.widthBox.setValue(int(self.options[option]))
            elif str(option) == "heightBox":
                GUI.heightBox.setValue(int(self.options[option]))
            elif str(option) == "languageEdit":
                GUI.languageEdit.setText(str(self.options[option]))
            elif str(option) == "gammaSlider":
                if GUI.gammaSlider.isEnabled():
                    GUI.gammaSlider.setValue(int(self.options[option]))
                    self.changeGamma(int(self.options[option]))
            elif str(option) == "croppingPowerSlider":
                if GUI.croppingPowerSlider.isEnabled():
                    GUI.croppingPowerSlider.setValue(int(self.options[option]))
                    self.changeCroppingPower(int(self.options[option]))
                    GUI.preserveMarginBox.setValue(self.options.get('preserveMarginBox', 0))
            elif str(option) == "jpegQuality":
                GUI.jpegQualitySpinBox.setValue(int(self.options[option]))
            elif str(option) == "chunkSizeBox":
                GUI.chunkSizeBox.setValue(int(self.options[option]))
            else:
                try:
                    if getattr(GUI, option).isEnabled():
                        getattr(GUI, option).setCheckState(Qt.CheckState(self.options[option]))
                except AttributeError:
                    pass
        self.worker.sync()
        self.tray.show()

        # Cleanup unfinished conversion
        for root, dirs, _ in walkLevel(gettempdir(), 0):
            for tempdir in dirs:
                if tempdir.startswith('KCC-'):
                    rmtree(os.path.join(root, tempdir), True)

        if self.windowSize != '0x0':
            x, y = self.windowSize.split('x')
            MW.resize(int(x), int(y))
        self._applyModernTheme()
        MW.setWindowTitle(f"{branding.APP_NAME} {__version__}")
        MW.show()
        MW.raise_()


class KCCGUI_MetaEditor(KCC_ui_editor.Ui_editorDialog):
    def _buildBulkFieldToolTip(self, fieldLabel, valuesByFile):
        note = '<p><em>Note: Changing this field will overwrite all values in all selected files.</em></p>'

        if len(valuesByFile) <= 20:
            rows = ''.join(
                '<tr>'
                f'<td style="padding:2px 6px; white-space:nowrap;">{escape(os.path.basename(f))}</td>'
                f'<td style="padding:2px 6px;">{escape(v)}</td>'
                '</tr>'
                for f, v in valuesByFile
            )

            table = (
                '<table border="1" cellspacing="0" cellpadding="0">'
                '<tr>'
                '<th style="padding:2px 6px; text-align:left;">File</th>'
                '<th style="padding:2px 6px; text-align:left;">Value</th>'
                '</tr>'
                f'{rows}'
                '</table>'
            )
        else:
            counts = {}
            for _, v in valuesByFile:
                counts[v] = counts.get(v, 0) + 1

            rows = ''.join(
                '<tr>'
                f'<td style="padding:2px 6px;">{escape(v)}</td>'
                f'<td style="padding:2px 6px; text-align:right;">{c}</td>'
                '</tr>'
                for v, c in sorted(counts.items(), key=lambda t: (-t[1], t[0]))
            )

            table = (
                '<table border="1" cellspacing="0" cellpadding="0">'
                '<tr>'
                '<th style="padding:2px 6px; text-align:left;">Value</th>'
                '<th style="padding:2px 6px; text-align:right;">Count</th>'
                '</tr>'
                f'{rows}'
                '</table>'
            )

        tooltipHTML = f'\
            <b>{escape(fieldLabel)}</b>\
            {note}\
            {table}\
        '

        return tooltipHTML

    def loadData(self, files):
        self.files = files if isinstance(files, list) else [files]
        self.bulkMode = len(self.files) > 1
        
        # Sort files by name for consistent volume assignment
        self.files.sort()
        
        # Unified CBR check for all files (both single and bulk mode)
        for file in self.files:
            parser = metadata.MetadataParser(file)
            if parser.format in ['RAR', 'RAR5']:
                self.editorWidget.setEnabled(False)
                self.okButton.setEnabled(False)
                self.statusLabel.setText('CBR files in selection are read-only.')
                return
        
        if self.bulkMode:
            firstFile = self.files[0]
            self.parser = metadata.MetadataParser(firstFile)
            self.editorWidget.setEnabled(True)
            self.okButton.setEnabled(True)
            self.statusLabel.setText(f'Editing {len(self.files)} files.')

            # Show bulk volume checkbox
            self.bulkVolumeCheck.setVisible(True)
            self.bulkVolumeCheck.setChecked(False)

            for field in (self.volumeLine, self.numberLine, self.titleLine):
                field.setEnabled(False)
                field.setText('')
                field.setPlaceholderText('(multiple files)')
                field.setToolTip('')

            # Load metadata for all files and show common values, or “(multiple values)” + tooltip.
            parsed = []
            for file in self.files:
                parsed.append((file, metadata.MetadataParser(file)))

            field_specs = [
                (self.seriesLine, 'Series', lambda p: (p.data.get('Series', '') or '')),
                (self.writerLine, 'Writer', lambda p: ', '.join(p.data.get('Writers', []) or [])),
                (self.pencillerLine, 'Penciller', lambda p: ', '.join(p.data.get('Pencillers', []) or [])),
                (self.inkerLine, 'Inker', lambda p: ', '.join(p.data.get('Inkers', []) or [])),
                (self.coloristLine, 'Colorist', lambda p: ', '.join(p.data.get('Colorists', []) or [])),
            ]

            for line, label, extractor in field_specs:
                line.setEnabled(True)
                valuesByFile = [(f, extractor(p)) for f, p in parsed]
                uniqueValues = {v for _, v in valuesByFile}

                if len(uniqueValues) == 1:
                    common_value = valuesByFile[0][1] if valuesByFile else ''
                    line.setPlaceholderText('')
                    line.setToolTip('')
                    line.setText(common_value)
                else:
                    line.setText('')
                    line.setPlaceholderText('(multiple values)')
                    line.setToolTip(self._buildBulkFieldToolTip(label, valuesByFile))
        else:
            file = self.files[0]
            self.parser = metadata.MetadataParser(file)
            
            # Hide bulk volume checkbox in single file mode
            self.bulkVolumeCheck.setVisible(False)
            
            for field in (self.volumeLine, self.numberLine, self.titleLine, self.seriesLine,
                          self.writerLine, self.pencillerLine, self.inkerLine, self.coloristLine):
                field.setEnabled(True)
                field.setPlaceholderText('')
            
            self.editorWidget.setEnabled(True)
            self.okButton.setEnabled(True)
            self.statusLabel.setText('Separate authors with a comma.')
            
            for field in (self.seriesLine, self.volumeLine, self.numberLine, self.titleLine):
                field.setText(self.parser.data[field.objectName().capitalize()[:-4]])
            for field in (self.writerLine, self.pencillerLine, self.inkerLine, self.coloristLine):
                field.setText(', '.join(self.parser.data[field.objectName().capitalize()[:-4] + 's']))
            for field in (self.seriesLine, self.titleLine):
                if field.text() == '':
                    path = Path(file)
                    if file.endswith('.xml'):
                        field.setText(path.parent.name)
                    else:
                        field.setText(path.stem)

    def saveData(self):
        if self.bulkMode:
            bulkData = {}
            if self.cleanData(self.seriesLine.text()):
                bulkData['Series'] = self.cleanData(self.seriesLine.text())
            
            for field in (self.writerLine, self.pencillerLine, self.inkerLine, self.coloristLine):
                fieldName = field.objectName().capitalize()[:-4] + 's'
                values = self.cleanData(field.text()).split(',')
                tmpData = [self.cleanData(v) for v in values if self.cleanData(v)]
                if tmpData:
                    bulkData[fieldName] = tmpData
            # Handle bulk volume editing
            volumes = None
            if self.bulkVolumeCheck.isChecked():
                volumeText = self.volumeLine.text()
                volumes, error = self.parseVolumeInput(volumeText, len(self.files))
                if error:
                    self.statusLabel.setText(error)
                    return

            if not bulkData and volumes is None:
                self.statusLabel.setText('No changes to apply.')
                return

            errors = []
            total = len(self.files)
            self.okButton.setEnabled(False)
            self.cancelButton.setEnabled(False)

            for i, file in enumerate(self.files, 1):
                self.statusLabel.setText(f'Processing {i}/{total}: {os.path.basename(file)}')
                QApplication.processEvents()

                try:
                    parser = metadata.MetadataParser(file)
                    if parser.format in ['RAR', 'RAR5']:
                        errors.append(f'{os.path.basename(file)}: CBR is read-only')
                        continue
                    for key, value in bulkData.items():
                        parser.data[key] = value
                    # Set volume if bulk volume editing is enabled
                    if volumes is not None:
                        parser.data['Volume'] = str(volumes[i - 1])
                    parser.saveXML()
                except Exception as err:
                    errors.append(f'{os.path.basename(file)}: {str(err)}')

            self.okButton.setEnabled(True)
            self.cancelButton.setEnabled(True)

            if errors:
                GUI.showDialog("Some files failed to save:\n\n" + "\n".join(errors[:10]) +
                              (f"\n...and {len(errors) - 10} more" if len(errors) > 10 else ""), 'error')
                self.statusLabel.setText('Errors occurred.')
            else:
                self.statusLabel.setText(f'Successfully updated {total} files.')
                self.ui.close()
        else:
            for field in (self.volumeLine, self.numberLine):
                if field.text().isnumeric() or self.cleanData(field.text()) == '':
                    self.parser.data[field.objectName().capitalize()[:-4]] = self.cleanData(field.text())
                else:
                    self.statusLabel.setText(field.objectName().capitalize()[:-4] + ' field must be a number.')
                    break
            else:
                for field in (self.seriesLine, self.titleLine):
                    self.parser.data[field.objectName().capitalize()[:-4]] = self.cleanData(field.text())
                for field in (self.writerLine, self.pencillerLine, self.inkerLine, self.coloristLine):
                    values = self.cleanData(field.text()).split(',')
                    tmpData = []
                    for value in values:
                        if self.cleanData(value) != '':
                            tmpData.append(self.cleanData(value))
                    self.parser.data[field.objectName().capitalize()[:-4] + 's'] = tmpData
                try:
                    self.parser.saveXML()
                except Exception as err:
                    _, _, traceback = sys.exc_info()
                    GUI.showDialog("Failed to save metadata!\n\n%s\n\nTraceback:\n%s"
                                   % (str(err), sanitizeTrace(traceback)), 'error')
                self.ui.close()

    def cleanData(self, s):
        return escape(s.strip())

    def parseVolumeInput(self, text, fileCount):
        text = text.strip()
        if not text:
            return None, None
        
        volumes = []
        
        # Check if it's a range (e.g., "5-10")
        if '-' in text and ',' not in text:
            parts = text.split('-')
            if len(parts) != 2 or not parts[0].strip() or not parts[1].strip():
                return None, 'Invalid range format (use start-end)'
            try:
                start = int(parts[0].strip())
                end = int(parts[1].strip())
                if start < 0 or end < 0:
                    return None, 'Volume numbers must be positive'
                if start > end:
                    return None, 'Invalid range: start > end'
                volumes = list(range(start, end + 1))
            except ValueError:
                return None, 'Invalid range format'
        # Check if it's a comma-separated list (e.g., "1,3,5")
        elif ',' in text:
            try:
                volumes = [int(v.strip()) for v in text.split(',') if v.strip()]
                if any(v < 0 for v in volumes):
                    return None, 'Volume numbers must be positive'
            except ValueError:
                return None, 'Invalid list format'
        # Single number - generate sequence starting from that number
        else:
            try:
                start = int(text)
                if start < 0:
                    return None, 'Volume number must be positive'
                volumes = list(range(start, start + fileCount))
            except ValueError:
                return None, 'Invalid number'
        
        # Validate count
        if not volumes:
            return None, 'No valid volume numbers parsed'
        if len(volumes) != fileCount:
            return None, f'Volume count ({len(volumes)}) != file count ({fileCount})'
        
        return volumes, None
    
    def toggleBulkVolume(self, checked):
        self.volumeLine.setEnabled(checked)
        if checked:
            self.volumeLine.setText('')
            self.volumeLine.setPlaceholderText('e.g., 5 or 1-10 or 1,3,5')
        else:
            self.volumeLine.setText('')
            self.volumeLine.setPlaceholderText('(multiple files)')

    def __init__(self):
        self.ui = QDialog()
        self.parser = None
        self.files = []
        self.bulkMode = False
        self.setupUi(self.ui)
        self.ui.setWindowFlags(self.ui.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        
        self.bulkVolumeCheck.stateChanged.connect(self.toggleBulkVolume)
        
        self.okButton.clicked.connect(self.saveData)
        self.cancelButton.clicked.connect(self.ui.close)
        if sys.platform.startswith('linux'):
            self.ui.resize(450, 260)
            self.ui.setMinimumSize(QSize(450, 260))
        elif sys.platform.startswith('darwin'):
            self.ui.resize(450, 310)
            self.ui.setMinimumSize(QSize(450, 310))
