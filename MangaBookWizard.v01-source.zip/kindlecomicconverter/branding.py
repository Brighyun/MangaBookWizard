"""Product name, community links, and the shared Windows/macOS visual theme."""

APP_NAME = "MangaBookWizard"
APP_SHORT_NAME = "MangaBookWizard"
APP_ID = "manga-book-wizard"
SETTINGS_ORGANIZATION = "MangaBookWizard"
SETTINGS_APPLICATION = "desktop-v2"

ANILIST_URL = "https://anilist.co/"
REDDIT_MANGA_URL = "https://www.reddit.com/r/manga/"
REDDIT_KINDLE_URL = "https://www.reddit.com/r/kindle/"
REDDIT_COLLECTORS_URL = "https://www.reddit.com/r/MangaCollectors/"
LINKEDIN_URL = "https://www.linkedin.com/in/brigh-yun-lee-01130025b/"
BUY_ME_A_COFFEE_URL = "https://buymeacoffee.com/mangabookwizard"
KINDLE_PREVIEWER_URL = "https://kdp.amazon.com/en_US/help/topic/G202131170"
SEVEN_ZIP_URL = "https://www.7-zip.org/"


def stylesheet(_dark: bool) -> str:
    """Return the app's matte Material-inspired monochrome theme."""
    canvas = "#0E0F10"
    surface = "#18191A"
    elevated = "#232527"
    paper = "#F3F2EE"
    paper_bright = "#FAFAF7"
    paper_muted = "#E8E7E2"
    ink = "#111214"
    white = "#FAFAF8"
    muted_dark = "#666A6E"
    muted_light = "#B8BBC0"
    border_dark = "#383B3E"
    border_light = "#C9C8C2"

    return f"""
        QMainWindow, QWidget#centralWidget, QWidget#mainPage, QWidget#actionDock,
        QScrollArea#mainScroll, QScrollArea#mainScroll > QWidget > QWidget {{
            background: {canvas};
            color: {white};
        }}
        QWidget {{
            font-family: "Inter", "SF Pro Text", "Segoe UI", sans-serif;
            font-size: 14px;
        }}
        QFrame#brandHeader {{
            background: {surface};
            border: 1px solid {border_dark};
            border-radius: 14px;
        }}
        QLabel#brandIcon {{
            border: none;
            background: transparent;
        }}
        QLabel#brandTitle {{
            color: {white};
            font-size: 25px;
            font-weight: 800;
            border: none;
        }}
        QLabel#brandSubtitle {{
            color: {muted_light};
            font-size: 13px;
            border: none;
        }}
        QLabel#safetyBadge {{
            color: {ink};
            background: {paper};
            border: 1px solid {paper};
            border-radius: 10px;
            padding: 7px 11px;
            font-weight: 700;
        }}
        QFrame#dropCard, QFrame#setupCard, QFrame#actionCard {{
            background: {paper};
            border: 1px solid {border_light};
            border-radius: 14px;
        }}
        QFrame#dropCard {{
            border: 2px dashed #5A5D60;
        }}
        QFrame#communityCard {{
            background: {surface};
            border: 1px solid {border_dark};
            border-radius: 14px;
        }}
        QFrame#advancedPanel {{
            background: {paper_muted};
            border: 1px solid {border_light};
            border-radius: 10px;
        }}
        QLabel#stepLabel {{
            color: #34373A;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1px;
            border: none;
        }}
        QLabel#dropTitle {{
            color: {ink};
            font-size: 25px;
            font-weight: 800;
            border: none;
        }}
        QLabel#dropSubtitle, QLabel#mutedLabel {{
            color: {muted_dark};
            border: none;
        }}
        QLabel#fieldLabel {{
            color: {ink};
            font-size: 13px;
            font-weight: 700;
            border: none;
        }}
        QLabel#communityTitle {{
            color: {white};
            font-size: 19px;
            font-weight: 800;
            border: none;
        }}
        QFrame#communityCard QLabel#mutedLabel {{
            color: {muted_light};
        }}
        QLabel#footerLabel {{
            color: #969A9F;
            font-size: 12px;
        }}
        QWidget#buttonWidget, QWidget#toolWidget, QWidget#optionWidget,
        QWidget#gammaWidget, QWidget#croppingWidget, QWidget#customWidget,
        QWidget#chunkSizeWidget, QWidget#jpegQualityWidget {{
            background: transparent;
            color: {ink};
            border: none;
        }}
        QListWidget#jobList {{
            background: {paper_bright};
            color: {ink};
            border: 1px solid {border_light};
            border-radius: 10px;
            padding: 8px;
            outline: none;
        }}
        QListWidget#jobList QLabel {{
            color: {ink};
            background: transparent;
        }}
        QListWidget#jobList::item {{
            min-height: 34px;
            border-radius: 6px;
        }}
        QListWidget#jobList::item:selected {{
            color: {white};
            background: #292B2D;
        }}
        QPushButton, QComboBox, QLineEdit, QSpinBox {{
            min-height: 36px;
            color: {ink};
            background: {paper_bright};
            border: 1px solid {border_light};
            border-radius: 8px;
            padding: 0 12px;
        }}
        QPushButton:hover, QComboBox:hover, QLineEdit:hover, QSpinBox:hover {{
            border-color: #55595D;
            background: white;
        }}
        QPushButton:pressed {{
            background: #D9D8D3;
        }}
        QPushButton:focus, QComboBox:focus, QLineEdit:focus, QSpinBox:focus {{
            border: 2px solid #303336;
        }}
        QPushButton:disabled, QComboBox:disabled, QLineEdit:disabled,
        QSpinBox:disabled, QCheckBox:disabled {{
            color: #8A8C8E;
            background: #DDDDD8;
        }}
        QPushButton#helpButton, QPushButton#supportButton {{
            color: {white};
            background: transparent;
            border: 1px solid #65696D;
        }}
        QPushButton#helpButton:hover, QPushButton#supportButton:hover {{
            border-color: {white};
            color: {ink};
            background: {white};
        }}
        QPushButton#convertButton {{
            color: {white};
            background: {ink};
            border: 1px solid {ink};
            border-radius: 10px;
            font-size: 16px;
            font-weight: 800;
            padding: 0 22px;
        }}
        QPushButton#convertButton:hover {{
            background: #303336;
            border-color: #303336;
        }}
        QPushButton#convertButton:pressed {{
            background: #000000;
        }}
        QPushButton#preflightButton, QPushButton#advancedButton {{
            color: {ink};
            background: transparent;
            border: 1px solid #9B9B96;
            font-weight: 700;
        }}
        QPushButton#advancedButton {{
            text-align: left;
            padding-left: 14px;
        }}
        QFrame#communityCard QPushButton {{
            color: {white};
            background: {elevated};
            border: 1px solid #505357;
            font-weight: 700;
        }}
        QFrame#communityCard QPushButton:hover {{
            color: {ink};
            background: {white};
            border-color: {white};
        }}
        QCheckBox {{
            spacing: 8px;
            color: {ink};
        }}
        QCheckBox::indicator {{
            width: 18px;
            height: 18px;
        }}
        QProgressBar {{
            min-height: 26px;
            color: {ink};
            background: #D8D8D3;
            border: 1px solid {border_light};
            border-radius: 8px;
            text-align: center;
        }}
        QProgressBar::chunk {{
            background: {ink};
            border-radius: 7px;
        }}
        QSlider::groove:horizontal {{
            height: 6px;
            background: #BFC0BC;
            border-radius: 3px;
        }}
        QSlider::handle:horizontal {{
            width: 18px;
            margin: -6px 0;
            background: {ink};
            border-radius: 9px;
        }}
        QToolTip {{
            color: {white};
            background: #232527;
            border: 1px solid #565A5E;
            padding: 7px;
        }}
    """
