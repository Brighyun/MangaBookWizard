# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'KCC.ui'
##
## Created by: Qt User Interface Compiler version 6.9.3
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMainWindow, QProgressBar,
    QPushButton, QSizePolicy, QSlider, QSpinBox,
    QStatusBar, QWidget)
from . import KCC_rc

class Ui_mainWindow(object):
    def setupUi(self, mainWindow):
        if not mainWindow.objectName():
            mainWindow.setObjectName(u"mainWindow")
        mainWindow.resize(649, 706)
        icon = QIcon()
        icon.addFile(u":/Icon/icons/manga-book-wizard.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        mainWindow.setWindowIcon(icon)
        self.centralWidget = QWidget(mainWindow)
        self.centralWidget.setObjectName(u"centralWidget")
        self.gridLayout = QGridLayout(self.centralWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(-1, -1, -1, 5)
        self.croppingWidget = QWidget(self.centralWidget)
        self.croppingWidget.setObjectName(u"croppingWidget")
        self.croppingWidget.setVisible(False)
        self.gridLayout_5 = QGridLayout(self.croppingWidget)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setContentsMargins(0, 0, 0, 0)
        self.croppingPowerSlider = QSlider(self.croppingWidget)
        self.croppingPowerSlider.setObjectName(u"croppingPowerSlider")
        self.croppingPowerSlider.setMaximum(300)
        self.croppingPowerSlider.setSingleStep(1)
        self.croppingPowerSlider.setOrientation(Qt.Orientation.Horizontal)

        self.gridLayout_5.addWidget(self.croppingPowerSlider, 0, 1, 1, 1)

        self.preserveMarginBox = QSpinBox(self.croppingWidget)
        self.preserveMarginBox.setObjectName(u"preserveMarginBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.preserveMarginBox.sizePolicy().hasHeightForWidth())
        self.preserveMarginBox.setSizePolicy(sizePolicy)
        self.preserveMarginBox.setMaximum(99)
        self.preserveMarginBox.setSingleStep(5)
        self.preserveMarginBox.setValue(0)

        self.gridLayout_5.addWidget(self.preserveMarginBox, 1, 1, 1, 1)

        self.preserveMarginLabel = QLabel(self.croppingWidget)
        self.preserveMarginLabel.setObjectName(u"preserveMarginLabel")

        self.gridLayout_5.addWidget(self.preserveMarginLabel, 1, 0, 1, 1)

        self.croppingPowerLabel = QLabel(self.croppingWidget)
        self.croppingPowerLabel.setObjectName(u"croppingPowerLabel")

        self.gridLayout_5.addWidget(self.croppingPowerLabel, 0, 0, 1, 1)


        self.gridLayout.addWidget(self.croppingWidget, 9, 0, 1, 2)

        self.optionWidget = QWidget(self.centralWidget)
        self.optionWidget.setObjectName(u"optionWidget")
        self.gridLayout_2 = QGridLayout(self.optionWidget)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.metadataTitleBox = QCheckBox(self.optionWidget)
        self.metadataTitleBox.setObjectName(u"metadataTitleBox")
        self.metadataTitleBox.setTristate(True)

        self.gridLayout_2.addWidget(self.metadataTitleBox, 2, 3, 1, 1)

        self.vertical4PanelBox = QCheckBox(self.optionWidget)
        self.vertical4PanelBox.setObjectName(u"vertical4PanelBox")

        self.gridLayout_2.addWidget(self.vertical4PanelBox, 9, 2, 1, 1)

        self.webtoonBox = QCheckBox(self.optionWidget)
        self.webtoonBox.setObjectName(u"webtoonBox")

        self.gridLayout_2.addWidget(self.webtoonBox, 2, 0, 1, 1)

        self.webpBox = QCheckBox(self.optionWidget)
        self.webpBox.setObjectName(u"webpBox")

        self.gridLayout_2.addWidget(self.webpBox, 9, 0, 1, 1)

        self.smartCoverCropBox = QCheckBox(self.optionWidget)
        self.smartCoverCropBox.setObjectName(u"smartCoverCropBox")

        self.gridLayout_2.addWidget(self.smartCoverCropBox, 9, 1, 1, 1)

        self.croppingBox = QCheckBox(self.optionWidget)
        self.croppingBox.setObjectName(u"croppingBox")
        self.croppingBox.setTristate(True)

        self.gridLayout_2.addWidget(self.croppingBox, 4, 2, 1, 1)

        self.autocontrastBox = QCheckBox(self.optionWidget)
        self.autocontrastBox.setObjectName(u"autocontrastBox")
        self.autocontrastBox.setTristate(True)

        self.gridLayout_2.addWidget(self.autocontrastBox, 8, 2, 1, 1)

        self.mozJpegBox = QCheckBox(self.optionWidget)
        self.mozJpegBox.setObjectName(u"mozJpegBox")
        self.mozJpegBox.setTristate(True)

        self.gridLayout_2.addWidget(self.mozJpegBox, 4, 0, 1, 1)

        self.coverFillBox = QCheckBox(self.optionWidget)
        self.coverFillBox.setObjectName(u"coverFillBox")

        self.gridLayout_2.addWidget(self.coverFillBox, 7, 1, 1, 1)

        self.interPanelCropBox = QCheckBox(self.optionWidget)
        self.interPanelCropBox.setObjectName(u"interPanelCropBox")
        self.interPanelCropBox.setTristate(True)

        self.gridLayout_2.addWidget(self.interPanelCropBox, 5, 2, 1, 1)

        self.chunkSizeCheckBox = QCheckBox(self.optionWidget)
        self.chunkSizeCheckBox.setObjectName(u"chunkSizeCheckBox")

        self.gridLayout_2.addWidget(self.chunkSizeCheckBox, 5, 3, 1, 1)

        self.disableProcessingBox = QCheckBox(self.optionWidget)
        self.disableProcessingBox.setObjectName(u"disableProcessingBox")

        self.gridLayout_2.addWidget(self.disableProcessingBox, 6, 3, 1, 1)

        self.spreadShiftBox = QCheckBox(self.optionWidget)
        self.spreadShiftBox.setObjectName(u"spreadShiftBox")

        self.gridLayout_2.addWidget(self.spreadShiftBox, 5, 0, 1, 1)

        self.forcePngRgbBox = QCheckBox(self.optionWidget)
        self.forcePngRgbBox.setObjectName(u"forcePngRgbBox")
        self.forcePngRgbBox.setEnabled(False)

        self.gridLayout_2.addWidget(self.forcePngRgbBox, 8, 3, 1, 1)

        self.rotateBox = QCheckBox(self.optionWidget)
        self.rotateBox.setObjectName(u"rotateBox")
        self.rotateBox.setTristate(True)

        self.gridLayout_2.addWidget(self.rotateBox, 1, 1, 1, 1)

        self.gammaBox = QCheckBox(self.optionWidget)
        self.gammaBox.setObjectName(u"gammaBox")

        self.gridLayout_2.addWidget(self.gammaBox, 2, 2, 1, 1)

        self.languageEdit = QLineEdit(self.optionWidget)
        self.languageEdit.setObjectName(u"languageEdit")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.languageEdit.sizePolicy().hasHeightForWidth())
        self.languageEdit.setSizePolicy(sizePolicy1)
        self.languageEdit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.languageEdit.setClearButtonEnabled(False)

        self.gridLayout_2.addWidget(self.languageEdit, 0, 3, 1, 1)

        self.rotateRightBox = QCheckBox(self.optionWidget)
        self.rotateRightBox.setObjectName(u"rotateRightBox")

        self.gridLayout_2.addWidget(self.rotateRightBox, 8, 1, 1, 1)

        self.tempDirBox = QCheckBox(self.optionWidget)
        self.tempDirBox.setObjectName(u"tempDirBox")

        self.gridLayout_2.addWidget(self.tempDirBox, 10, 2, 1, 1)

        self.deleteBox = QCheckBox(self.optionWidget)
        self.deleteBox.setObjectName(u"deleteBox")

        self.gridLayout_2.addWidget(self.deleteBox, 1, 3, 1, 1)

        self.maximizeStrips = QCheckBox(self.optionWidget)
        self.maximizeStrips.setObjectName(u"maximizeStrips")

        self.gridLayout_2.addWidget(self.maximizeStrips, 4, 1, 1, 1)

        self.jpegQualityBox = QCheckBox(self.optionWidget)
        self.jpegQualityBox.setObjectName(u"jpegQualityBox")

        self.gridLayout_2.addWidget(self.jpegQualityBox, 7, 0, 1, 1)

        self.rotateFirstBox = QCheckBox(self.optionWidget)
        self.rotateFirstBox.setObjectName(u"rotateFirstBox")

        self.gridLayout_2.addWidget(self.rotateFirstBox, 6, 1, 1, 1)

        self.titleEdit = QLineEdit(self.optionWidget)
        self.titleEdit.setObjectName(u"titleEdit")
        sizePolicy1.setHeightForWidth(self.titleEdit.sizePolicy().hasHeightForWidth())
        self.titleEdit.setSizePolicy(sizePolicy1)
        self.titleEdit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.titleEdit.setClearButtonEnabled(False)

        self.gridLayout_2.addWidget(self.titleEdit, 0, 0, 1, 1)

        self.pdfWidthBox = QCheckBox(self.optionWidget)
        self.pdfWidthBox.setObjectName(u"pdfWidthBox")

        self.gridLayout_2.addWidget(self.pdfWidthBox, 4, 3, 1, 1)

        self.eraseRainbowBox = QCheckBox(self.optionWidget)
        self.eraseRainbowBox.setObjectName(u"eraseRainbowBox")

        self.gridLayout_2.addWidget(self.eraseRainbowBox, 6, 2, 1, 1)

        self.onePageLandscapeBox = QCheckBox(self.optionWidget)
        self.onePageLandscapeBox.setObjectName(u"onePageLandscapeBox")

        self.gridLayout_2.addWidget(self.onePageLandscapeBox, 10, 1, 1, 1)

        self.authorEdit = QLineEdit(self.optionWidget)
        self.authorEdit.setObjectName(u"authorEdit")
        sizePolicy1.setHeightForWidth(self.authorEdit.sizePolicy().hasHeightForWidth())
        self.authorEdit.setSizePolicy(sizePolicy1)
        self.authorEdit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.authorEdit.setClearButtonEnabled(False)

        self.gridLayout_2.addWidget(self.authorEdit, 0, 1, 1, 1)

        self.outputSplit = QCheckBox(self.optionWidget)
        self.outputSplit.setObjectName(u"outputSplit")

        self.gridLayout_2.addWidget(self.outputSplit, 3, 1, 1, 1)

        self.fileFusionBox = QCheckBox(self.optionWidget)
        self.fileFusionBox.setObjectName(u"fileFusionBox")

        self.gridLayout_2.addWidget(self.fileFusionBox, 6, 0, 1, 1)

        self.colorBox = QCheckBox(self.optionWidget)
        self.colorBox.setObjectName(u"colorBox")

        self.gridLayout_2.addWidget(self.colorBox, 3, 2, 1, 1)

        self.upscaleBox = QCheckBox(self.optionWidget)
        self.upscaleBox.setObjectName(u"upscaleBox")
        self.upscaleBox.setTristate(True)

        self.gridLayout_2.addWidget(self.upscaleBox, 2, 1, 1, 1)

        self.legacyExtractBox = QCheckBox(self.optionWidget)
        self.legacyExtractBox.setObjectName(u"legacyExtractBox")

        self.gridLayout_2.addWidget(self.legacyExtractBox, 3, 3, 1, 1)

        self.borderBox = QCheckBox(self.optionWidget)
        self.borderBox.setObjectName(u"borderBox")
        self.borderBox.setTristate(True)

        self.gridLayout_2.addWidget(self.borderBox, 3, 0, 1, 1)

        self.invertDirectionBox = QCheckBox(self.optionWidget)
        self.invertDirectionBox.setObjectName(u"invertDirectionBox")

        self.gridLayout_2.addWidget(self.invertDirectionBox, 9, 3, 1, 1)

        self.qualityBox = QCheckBox(self.optionWidget)
        self.qualityBox.setObjectName(u"qualityBox")
        self.qualityBox.setTristate(True)

        self.gridLayout_2.addWidget(self.qualityBox, 1, 2, 1, 1)

        self.noRotateBox = QCheckBox(self.optionWidget)
        self.noRotateBox.setObjectName(u"noRotateBox")

        self.gridLayout_2.addWidget(self.noRotateBox, 5, 1, 1, 1)

        self.mangaBox = QCheckBox(self.optionWidget)
        self.mangaBox.setObjectName(u"mangaBox")

        self.gridLayout_2.addWidget(self.mangaBox, 1, 0, 1, 1)

        self.outputFolderWidget = QWidget(self.optionWidget)
        self.outputFolderWidget.setObjectName(u"outputFolderWidget")
        self.horizontalLayout_3 = QHBoxLayout(self.outputFolderWidget)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.defaultOutputFolderBox = QCheckBox(self.outputFolderWidget)
        self.defaultOutputFolderBox.setObjectName(u"defaultOutputFolderBox")
        sizePolicy.setHeightForWidth(self.defaultOutputFolderBox.sizePolicy().hasHeightForWidth())
        self.defaultOutputFolderBox.setSizePolicy(sizePolicy)
        self.defaultOutputFolderBox.setTristate(True)

        self.horizontalLayout_3.addWidget(self.defaultOutputFolderBox)

        self.defaultOutputFolderButton = QPushButton(self.outputFolderWidget)
        self.defaultOutputFolderButton.setObjectName(u"defaultOutputFolderButton")
        self.defaultOutputFolderButton.setMinimumSize(QSize(0, 30))
        icon1 = QIcon()
        icon1.addFile(u":/Other/icons/folder_new.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.defaultOutputFolderButton.setIcon(icon1)

        self.horizontalLayout_3.addWidget(self.defaultOutputFolderButton)


        self.gridLayout_2.addWidget(self.outputFolderWidget, 0, 2, 1, 1)

        self.autoLevelBox = QCheckBox(self.optionWidget)
        self.autoLevelBox.setObjectName(u"autoLevelBox")

        self.gridLayout_2.addWidget(self.autoLevelBox, 7, 2, 1, 1)

        self.lightnovelBox = QCheckBox(self.optionWidget)
        self.lightnovelBox.setObjectName(u"lightnovelBox")

        self.gridLayout_2.addWidget(self.lightnovelBox, 10, 0, 1, 1)

        self.pngLegacyBox = QCheckBox(self.optionWidget)
        self.pngLegacyBox.setObjectName(u"pngLegacyBox")
        self.pngLegacyBox.setEnabled(False)

        self.gridLayout_2.addWidget(self.pngLegacyBox, 8, 0, 1, 1)

        self.ebokBox = QCheckBox(self.optionWidget)
        self.ebokBox.setObjectName(u"ebokBox")

        self.gridLayout_2.addWidget(self.ebokBox, 10, 3, 1, 1)

        self.noQuantizeBox = QCheckBox(self.optionWidget)
        self.noQuantizeBox.setObjectName(u"noQuantizeBox")
        self.noQuantizeBox.setEnabled(False)

        self.gridLayout_2.addWidget(self.noQuantizeBox, 7, 3, 1, 1)

        self.keepComicInfoBox = QCheckBox(self.optionWidget)
        self.keepComicInfoBox.setObjectName(u"keepComicInfoBox")

        self.gridLayout_2.addWidget(self.keepComicInfoBox, 11, 3, 1, 1)


        self.gridLayout.addWidget(self.optionWidget, 5, 0, 1, 2)

        self.toolWidget = QWidget(self.centralWidget)
        self.toolWidget.setObjectName(u"toolWidget")
        self.gridLayout_6 = QGridLayout(self.toolWidget)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.gridLayout_6.setContentsMargins(0, 0, 0, 0)
        self.editorButton = QPushButton(self.toolWidget)
        self.editorButton.setObjectName(u"editorButton")
        self.editorButton.setMinimumSize(QSize(0, 30))
        icon2 = QIcon()
        icon2.addFile(u":/Other/icons/editor.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.editorButton.setIcon(icon2)

        self.gridLayout_6.addWidget(self.editorButton, 0, 0, 1, 1)

        self.anilistButton = QPushButton(self.toolWidget)
        self.anilistButton.setObjectName(u"anilistButton")
        self.anilistButton.setMinimumSize(QSize(0, 30))

        self.gridLayout_6.addWidget(self.anilistButton, 0, 3, 1, 1)

        self.linkedInButton = QPushButton(self.toolWidget)
        self.linkedInButton.setObjectName(u"linkedInButton")
        self.linkedInButton.setMinimumSize(QSize(0, 30))

        self.gridLayout_6.addWidget(self.linkedInButton, 0, 2, 1, 1)

        self.labelSpreadsButton = QPushButton(self.toolWidget)
        self.labelSpreadsButton.setObjectName(u"labelSpreadsButton")
        self.labelSpreadsButton.setMinimumSize(QSize(0, 30))

        self.gridLayout_6.addWidget(self.labelSpreadsButton, 0, 1, 1, 1)


        self.gridLayout.addWidget(self.toolWidget, 0, 0, 1, 2)

        self.chunkSizeWidget = QWidget(self.centralWidget)
        self.chunkSizeWidget.setObjectName(u"chunkSizeWidget")
        sizePolicy1.setHeightForWidth(self.chunkSizeWidget.sizePolicy().hasHeightForWidth())
        self.chunkSizeWidget.setSizePolicy(sizePolicy1)
        self.chunkSizeWidget.setVisible(False)
        self.horizontalLayout_4 = QHBoxLayout(self.chunkSizeWidget)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.chunkSizeLabel = QLabel(self.chunkSizeWidget)
        self.chunkSizeLabel.setObjectName(u"chunkSizeLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.chunkSizeLabel.sizePolicy().hasHeightForWidth())
        self.chunkSizeLabel.setSizePolicy(sizePolicy2)

        self.horizontalLayout_4.addWidget(self.chunkSizeLabel)

        self.chunkSizeBox = QSpinBox(self.chunkSizeWidget)
        self.chunkSizeBox.setObjectName(u"chunkSizeBox")
        self.chunkSizeBox.setMinimum(50)
        self.chunkSizeBox.setMaximum(600)
        self.chunkSizeBox.setValue(400)

        self.horizontalLayout_4.addWidget(self.chunkSizeBox)

        self.chunkSizeWarnLabel = QLabel(self.chunkSizeWidget)
        self.chunkSizeWarnLabel.setObjectName(u"chunkSizeWarnLabel")
        sizePolicy2.setHeightForWidth(self.chunkSizeWarnLabel.sizePolicy().hasHeightForWidth())
        self.chunkSizeWarnLabel.setSizePolicy(sizePolicy2)

        self.horizontalLayout_4.addWidget(self.chunkSizeWarnLabel)


        self.gridLayout.addWidget(self.chunkSizeWidget, 6, 0, 1, 1)

        self.gammaWidget = QWidget(self.centralWidget)
        self.gammaWidget.setObjectName(u"gammaWidget")
        self.gammaWidget.setVisible(False)
        self.horizontalLayout_2 = QHBoxLayout(self.gammaWidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gammaLabel = QLabel(self.gammaWidget)
        self.gammaLabel.setObjectName(u"gammaLabel")

        self.horizontalLayout_2.addWidget(self.gammaLabel)

        self.gammaSlider = QSlider(self.gammaWidget)
        self.gammaSlider.setObjectName(u"gammaSlider")
        self.gammaSlider.setMaximum(250)
        self.gammaSlider.setSingleStep(5)
        self.gammaSlider.setOrientation(Qt.Orientation.Horizontal)

        self.horizontalLayout_2.addWidget(self.gammaSlider)


        self.gridLayout.addWidget(self.gammaWidget, 7, 0, 1, 2)

        self.jpegQualityWidget = QWidget(self.centralWidget)
        self.jpegQualityWidget.setObjectName(u"jpegQualityWidget")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.jpegQualityWidget.sizePolicy().hasHeightForWidth())
        self.jpegQualityWidget.setSizePolicy(sizePolicy3)
        self.jpegQualityWidget.setVisible(False)
        self.horizontalLayout_12 = QHBoxLayout(self.jpegQualityWidget)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.jpegQualityLabel = QLabel(self.jpegQualityWidget)
        self.jpegQualityLabel.setObjectName(u"jpegQualityLabel")

        self.horizontalLayout_12.addWidget(self.jpegQualityLabel)

        self.jpegQualitySpinBox = QSpinBox(self.jpegQualityWidget)
        self.jpegQualitySpinBox.setObjectName(u"jpegQualitySpinBox")
        self.jpegQualitySpinBox.setMaximum(95)
        self.jpegQualitySpinBox.setSingleStep(5)
        self.jpegQualitySpinBox.setValue(85)

        self.horizontalLayout_12.addWidget(self.jpegQualitySpinBox)


        self.gridLayout.addWidget(self.jpegQualityWidget, 10, 0, 1, 1)

        self.jobList = QListWidget(self.centralWidget)
        self.jobList.setObjectName(u"jobList")
        self.jobList.setMinimumSize(QSize(0, 90))
        self.jobList.setStyleSheet(u"")
        self.jobList.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.jobList.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.jobList.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)

        self.gridLayout.addWidget(self.jobList, 2, 0, 1, 2)

        self.customWidget = QWidget(self.centralWidget)
        self.customWidget.setObjectName(u"customWidget")
        self.customWidget.setVisible(False)
        self.gridLayout_3 = QGridLayout(self.customWidget)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setContentsMargins(0, 0, 0, 0)
        self.hLabel = QLabel(self.customWidget)
        self.hLabel.setObjectName(u"hLabel")
        sizePolicy3.setHeightForWidth(self.hLabel.sizePolicy().hasHeightForWidth())
        self.hLabel.setSizePolicy(sizePolicy3)

        self.gridLayout_3.addWidget(self.hLabel, 0, 2, 1, 1)

        self.widthBox = QSpinBox(self.customWidget)
        self.widthBox.setObjectName(u"widthBox")
        self.widthBox.setMaximum(6000)

        self.gridLayout_3.addWidget(self.widthBox, 0, 1, 1, 1)

        self.wLabel = QLabel(self.customWidget)
        self.wLabel.setObjectName(u"wLabel")
        sizePolicy3.setHeightForWidth(self.wLabel.sizePolicy().hasHeightForWidth())
        self.wLabel.setSizePolicy(sizePolicy3)

        self.gridLayout_3.addWidget(self.wLabel, 0, 0, 1, 1)

        self.heightBox = QSpinBox(self.customWidget)
        self.heightBox.setObjectName(u"heightBox")
        self.heightBox.setMaximum(8000)

        self.gridLayout_3.addWidget(self.heightBox, 0, 3, 1, 1)


        self.gridLayout.addWidget(self.customWidget, 8, 0, 1, 2)

        self.progressBar = QProgressBar(self.centralWidget)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setMinimumSize(QSize(0, 30))
        font = QFont()
        font.setBold(True)
        self.progressBar.setFont(font)
        self.progressBar.setVisible(False)
        self.progressBar.setAlignment(Qt.AlignmentFlag.AlignJustify|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout.addWidget(self.progressBar, 1, 0, 1, 2)

        self.buttonWidget = QWidget(self.centralWidget)
        self.buttonWidget.setObjectName(u"buttonWidget")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.buttonWidget.sizePolicy().hasHeightForWidth())
        self.buttonWidget.setSizePolicy(sizePolicy4)
        self.gridLayout_4 = QGridLayout(self.buttonWidget)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.gridLayout_4.setContentsMargins(0, 0, 0, 0)
        self.deviceBox = QComboBox(self.buttonWidget)
        self.deviceBox.setObjectName(u"deviceBox")
        self.deviceBox.setMinimumSize(QSize(0, 28))

        self.gridLayout_4.addWidget(self.deviceBox, 1, 1, 1, 1)

        self.clearButton = QPushButton(self.buttonWidget)
        self.clearButton.setObjectName(u"clearButton")
        self.clearButton.setMinimumSize(QSize(0, 30))
        icon3 = QIcon()
        icon3.addFile(u":/Other/icons/clear.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.clearButton.setIcon(icon3)

        self.gridLayout_4.addWidget(self.clearButton, 0, 3, 1, 1)

        self.directoryButton = QPushButton(self.buttonWidget)
        self.directoryButton.setObjectName(u"directoryButton")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.directoryButton.sizePolicy().hasHeightForWidth())
        self.directoryButton.setSizePolicy(sizePolicy5)
        self.directoryButton.setIcon(icon1)

        self.gridLayout_4.addWidget(self.directoryButton, 0, 4, 1, 1)

        self.convertButton = QPushButton(self.buttonWidget)
        self.convertButton.setObjectName(u"convertButton")
        self.convertButton.setMinimumSize(QSize(0, 30))
        self.convertButton.setFont(font)
        icon4 = QIcon()
        icon4.addFile(u":/Other/icons/convert.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.convertButton.setIcon(icon4)

        self.gridLayout_4.addWidget(self.convertButton, 1, 3, 1, 1)

        self.fileButton = QPushButton(self.buttonWidget)
        self.fileButton.setObjectName(u"fileButton")
        self.fileButton.setMinimumSize(QSize(0, 30))
        icon5 = QIcon()
        icon5.addFile(u":/Other/icons/document_new.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.fileButton.setIcon(icon5)

        self.gridLayout_4.addWidget(self.fileButton, 0, 1, 1, 1)

        self.formatBox = QComboBox(self.buttonWidget)
        self.formatBox.setObjectName(u"formatBox")
        self.formatBox.setMinimumSize(QSize(0, 28))

        self.gridLayout_4.addWidget(self.formatBox, 1, 4, 1, 1)

        self.clearButton.raise_()
        self.deviceBox.raise_()
        self.convertButton.raise_()
        self.fileButton.raise_()
        self.directoryButton.raise_()
        self.formatBox.raise_()

        self.gridLayout.addWidget(self.buttonWidget, 3, 0, 1, 2)

        mainWindow.setCentralWidget(self.centralWidget)
        self.statusBar = QStatusBar(mainWindow)
        self.statusBar.setObjectName(u"statusBar")
        self.statusBar.setSizeGripEnabled(False)
        mainWindow.setStatusBar(self.statusBar)
        QWidget.setTabOrder(self.jobList, self.fileButton)
        QWidget.setTabOrder(self.fileButton, self.clearButton)
        QWidget.setTabOrder(self.clearButton, self.deviceBox)
        QWidget.setTabOrder(self.deviceBox, self.widthBox)
        QWidget.setTabOrder(self.widthBox, self.heightBox)
        QWidget.setTabOrder(self.heightBox, self.convertButton)
        QWidget.setTabOrder(self.convertButton, self.mangaBox)
        QWidget.setTabOrder(self.mangaBox, self.rotateBox)
        QWidget.setTabOrder(self.rotateBox, self.qualityBox)
        QWidget.setTabOrder(self.qualityBox, self.webtoonBox)
        QWidget.setTabOrder(self.webtoonBox, self.upscaleBox)
        QWidget.setTabOrder(self.upscaleBox, self.gammaBox)
        QWidget.setTabOrder(self.gammaBox, self.gammaSlider)
        QWidget.setTabOrder(self.gammaSlider, self.borderBox)
        QWidget.setTabOrder(self.borderBox, self.outputSplit)
        QWidget.setTabOrder(self.outputSplit, self.colorBox)
        QWidget.setTabOrder(self.colorBox, self.mozJpegBox)
        QWidget.setTabOrder(self.mozJpegBox, self.maximizeStrips)
        QWidget.setTabOrder(self.maximizeStrips, self.croppingBox)
        QWidget.setTabOrder(self.croppingBox, self.croppingPowerSlider)
        QWidget.setTabOrder(self.croppingPowerSlider, self.preserveMarginBox)
        QWidget.setTabOrder(self.preserveMarginBox, self.spreadShiftBox)
        QWidget.setTabOrder(self.spreadShiftBox, self.fileFusionBox)
        QWidget.setTabOrder(self.fileFusionBox, self.chunkSizeBox)
        QWidget.setTabOrder(self.chunkSizeBox, self.editorButton)
        QWidget.setTabOrder(self.editorButton, self.linkedInButton)

        self.retranslateUi(mainWindow)

        QMetaObject.connectSlotsByName(mainWindow)
    # setupUi

    def retranslateUi(self, mainWindow):
        mainWindow.setWindowTitle(QCoreApplication.translate("mainWindow", u"MangaBookWizard", None))
#if QT_CONFIG(tooltip)
        self.preserveMarginLabel.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>After calculating the cropping boundaries, &quot;back up&quot; a specified percentage amount.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.preserveMarginLabel.setText(QCoreApplication.translate("mainWindow", u"Preserve Margin %", None))
        self.croppingPowerLabel.setText(QCoreApplication.translate("mainWindow", u"Cropping power:", None))
#if QT_CONFIG(tooltip)
        self.metadataTitleBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Don't use metadata Title<br/></span>Write default title.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - Add metadata Title to the default schema<br/></span>Write default title with Title from ComicInfo.xml or other embedded metadata.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Use metadata Title only<br/></span>Write Title from ComicInfo.xml or other embedded metadata.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.metadataTitleBox.setText(QCoreApplication.translate("mainWindow", u"Metadata Title", None))
#if QT_CONFIG(tooltip)
        self.vertical4PanelBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>In virtual panel mode:</p><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Horizontal<br/></span>First two panels are the top panels.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Vertical<br/></span>First two panels are the side panels.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.vertical4PanelBox.setText(QCoreApplication.translate("mainWindow", u"Vertical 4 Panel", None))
#if QT_CONFIG(tooltip)
        self.webtoonBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Enable special parsing mode for Korean Webtoons.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.webtoonBox.setText(QCoreApplication.translate("mainWindow", u"Webtoon mode", None))
#if QT_CONFIG(tooltip)
        self.webpBox.setToolTip(QCoreApplication.translate("mainWindow", u"Replace JPG with lossy WebP and PNG with lossless WebP. This includes the JPG Quality.\n"
"\n"
"Ignored for Kindle EPUB/MOBI and all PDF.", None))
#endif // QT_CONFIG(tooltip)
        self.webpBox.setText(QCoreApplication.translate("mainWindow", u"WebP (experimental)", None))
#if QT_CONFIG(tooltip)
        self.smartCoverCropBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Attempt to crop main cover from wide image.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.smartCoverCropBox.setText(QCoreApplication.translate("mainWindow", u"Smart Cover Crop", None))
#if QT_CONFIG(tooltip)
        self.croppingBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Disabled</span></p><p>Disabled</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - Margins<br/></span>Margins</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Margins + page numbers<br/></span>Margins +page numbers</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.croppingBox.setText(QCoreApplication.translate("mainWindow", u"Cropping mode", None))
#if QT_CONFIG(tooltip)
        self.autocontrastBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - BW only<br/></span>Only autocontrast bw pages. Ignored for pages where near blacks or whites don't exist.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - Disabled<br/></span>Disable autocontrast</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - BW and Color<br/></span>BW and color images will be autocontrasted. Ignored for pages where near blacks or whites don't exist.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.autocontrastBox.setText(QCoreApplication.translate("mainWindow", u"Custom Autocontrast", None))
#if QT_CONFIG(tooltip)
        self.mozJpegBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - JPEG<br/></span>Use JPEG files</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - force PNG<br/></span>Create PNG files instead JPEG for black and white images</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - mozJpeg<br/></span>10-20% smaller JPEG file, with the same image quality, but processing time multiplied by 2</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.mozJpegBox.setText(QCoreApplication.translate("mainWindow", u"JPEG/PNG/mozJpeg", None))
#if QT_CONFIG(tooltip)
        self.coverFillBox.setToolTip(QCoreApplication.translate("mainWindow", u"Resize cover to exact device resolution by center-cropping to aspect ratio first.\n"
"May crop top/bottom or left/right depending on source aspect ratio. Not implemented for Kindle Scribe.", None))
#endif // QT_CONFIG(tooltip)
        self.coverFillBox.setText(QCoreApplication.translate("mainWindow", u"Cover Fill", None))
#if QT_CONFIG(tooltip)
        self.interPanelCropBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Disabled<br/></span>Disabled</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - Horizontal<br/></span>Crop empty horizontal lines.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Both<br/></span>Crop empty horizontal and vertical lines.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.interPanelCropBox.setText(QCoreApplication.translate("mainWindow", u"Inter-panel crop", None))
#if QT_CONFIG(tooltip)
        self.chunkSizeCheckBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:700; text-decoration: underline;\">Unchecked<br/></span>Maximal output file size is 100 MB for Webtoon, 400 MB for others before split occurs.</p><p><span style=\" font-weight:700; text-decoration: underline;\">Checked</span><br/>Output file size specified in &quot;Chunk size MB&quot; before split occurs.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.chunkSizeCheckBox.setText(QCoreApplication.translate("mainWindow", u"Chunk size", None))
#if QT_CONFIG(tooltip)
        self.disableProcessingBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Do not process any image, ignore profile and processing options.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.disableProcessingBox.setText(QCoreApplication.translate("mainWindow", u"Disable processing", None))
#if QT_CONFIG(tooltip)
        self.spreadShiftBox.setToolTip(QCoreApplication.translate("mainWindow", u"Shift first page to opposite side in landscape for two page spread alignment", None))
#endif // QT_CONFIG(tooltip)
        self.spreadShiftBox.setText(QCoreApplication.translate("mainWindow", u"Spread shift", None))
#if QT_CONFIG(tooltip)
        self.forcePngRgbBox.setToolTip(QCoreApplication.translate("mainWindow", u"Force full color images to be saved in lossless PNG format, dramatically increases the filesize.", None))
#endif // QT_CONFIG(tooltip)
        self.forcePngRgbBox.setText(QCoreApplication.translate("mainWindow", u"Force PNG RGB", None))
#if QT_CONFIG(tooltip)
        self.rotateBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Split<br/></span>Double page spreads will be cut into two separate pages.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - Split and rotate<br/></span>Double page spreads will be displayed twice. First split and then rotated. </p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Rotate<br/></span>Double page spreads will be rotated.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.rotateBox.setText(QCoreApplication.translate("mainWindow", u"Spread splitter", None))
#if QT_CONFIG(tooltip)
        self.gammaBox.setToolTip(QCoreApplication.translate("mainWindow", u"Fine-tune page brightness. Most people can leave this on Auto.", None))
#endif // QT_CONFIG(tooltip)
        self.gammaBox.setText(QCoreApplication.translate("mainWindow", u"Custom gamma", None))
#if QT_CONFIG(tooltip)
        self.languageEdit.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Default EPUB language is en-US.</p><p>Only use if your EPUB reader has problems with English fonts.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.languageEdit.setPlaceholderText(QCoreApplication.translate("mainWindow", u"EPUB language", None))
#if QT_CONFIG(tooltip)
        self.rotateRightBox.setToolTip(QCoreApplication.translate("mainWindow", u"Rotate 2 page spreads in opposite direction than normal.", None))
#endif // QT_CONFIG(tooltip)
        self.rotateRightBox.setText(QCoreApplication.translate("mainWindow", u"Rotate Right", None))
#if QT_CONFIG(tooltip)
        self.tempDirBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Main Drive<br/></span>Use dedicated temporary directory on main OS drive.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Source File Drive<br/></span>Create temporary file directory on source file drive.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.tempDirBox.setText(QCoreApplication.translate("mainWindow", u"Temp Directory", None))
#if QT_CONFIG(tooltip)
        self.deleteBox.setToolTip(QCoreApplication.translate("mainWindow", u"Delete input file(s) or directory. It's not recoverable!", None))
#endif // QT_CONFIG(tooltip)
        self.deleteBox.setText(QCoreApplication.translate("mainWindow", u"Delete input", None))
#if QT_CONFIG(tooltip)
        self.maximizeStrips.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - 1x4<br/></span>Keep format 1x4 panels strips.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - 2x2<br/></span>Turn 1x4 strips to 2x2 to maximize screen usage.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.maximizeStrips.setText(QCoreApplication.translate("mainWindow", u"1x4 to 2x2 strips", None))
#if QT_CONFIG(tooltip)
        self.jpegQualityBox.setToolTip(QCoreApplication.translate("mainWindow", u"The JPEG quality, on a scale from 0 (worst) to 95 (best). \n"
"\n"
"Default is 85 for most devices besides Kindle Scribe and Colorsoft, which are 90.\n"
"\n"
"Higher values are larger and higher quality, and may resolve blank page issues.", None))
#endif // QT_CONFIG(tooltip)
        self.jpegQualityBox.setText(QCoreApplication.translate("mainWindow", u"Custom JPEG Quality", None))
#if QT_CONFIG(tooltip)
        self.rotateFirstBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>When the spread splitter option is partially checked,</p><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Rotate Last<br/></span>Put the rotated 2 page spread after the split spreads.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Rotate First<br/></span>Put the rotated 2 page spread before the split spreads.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.rotateFirstBox.setText(QCoreApplication.translate("mainWindow", u"Rotate First", None))
#if QT_CONFIG(tooltip)
        self.titleEdit.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Default Title</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.titleEdit.setPlaceholderText(QCoreApplication.translate("mainWindow", u"Default Title", None))
#if QT_CONFIG(tooltip)
        self.pdfWidthBox.setToolTip(QCoreApplication.translate("mainWindow", u"Render vector PDFs to device width instead of height.\n"
"\n"
"Useful if you plan to crop a little off the top and bottom to fill screen.", None))
#endif // QT_CONFIG(tooltip)
        self.pdfWidthBox.setText(QCoreApplication.translate("mainWindow", u"PDF Width Render", None))
#if QT_CONFIG(tooltip)
        self.eraseRainbowBox.setToolTip(QCoreApplication.translate("mainWindow", u"Erase rainbow effect on color eink screen by attenuating interfering frequencies", None))
#endif // QT_CONFIG(tooltip)
        self.eraseRainbowBox.setText(QCoreApplication.translate("mainWindow", u"Rainbow eraser", None))
#if QT_CONFIG(tooltip)
        self.onePageLandscapeBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - 2 page landscape<br/></span>2 viewports for left and right pages</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - 1 page landscape<br/></span>A single centered viewport for 1 page</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.onePageLandscapeBox.setText(QCoreApplication.translate("mainWindow", u"1 Page Landscape", None))
#if QT_CONFIG(tooltip)
        self.authorEdit.setToolTip(QCoreApplication.translate("mainWindow", u"Leave blank to use the author already stored in the book.", None))
#endif // QT_CONFIG(tooltip)
        self.authorEdit.setPlaceholderText(QCoreApplication.translate("mainWindow", u"Default Author", None))
#if QT_CONFIG(tooltip)
        self.outputSplit.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Automatic mode<br/></span>The output will be split automatically.</p><p style='white-space:pre'><span style=\" font-weight:600; text-decoration: underline;\">Checked - Volume mode<br/></span>Every subdirectory will be considered as a separate volume.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.outputSplit.setText(QCoreApplication.translate("mainWindow", u"Output split", None))
#if QT_CONFIG(tooltip)
        self.fileFusionBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Combines all selected files into a single file. (Helpful for combining chapters into volumes.)</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.fileFusionBox.setText(QCoreApplication.translate("mainWindow", u"File Fusion", None))
#if QT_CONFIG(tooltip)
        self.colorBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Disable conversion to grayscale.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.colorBox.setText(QCoreApplication.translate("mainWindow", u"Color mode", None))
#if QT_CONFIG(tooltip)
        self.upscaleBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Nothing<br/></span>Images smaller than device resolution will not be resized.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - Stretching<br/></span>Images smaller than device resolution will be resized. Aspect ratio will be not preserved.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Upscaling<br/></span>Images smaller than device resolution will be resized. Aspect ratio will be preserved.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.upscaleBox.setText(QCoreApplication.translate("mainWindow", u"Stretch/Upscale", None))
#if QT_CONFIG(tooltip)
        self.legacyExtractBox.setToolTip(QCoreApplication.translate("mainWindow", u"Try the backup PDF/EPUB reader if the normal reader cannot open this source.", None))
#endif // QT_CONFIG(tooltip)
        self.legacyExtractBox.setText(QCoreApplication.translate("mainWindow", u"Legacy Extract", None))
#if QT_CONFIG(tooltip)
        self.borderBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - Autodetection<br/></span>The color of margins fill will be detected automatically.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - White<br/></span>Margins will be untouched.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Black<br/></span>Margins will be filled with black color.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.borderBox.setText(QCoreApplication.translate("mainWindow", u"W/B margins", None))
#if QT_CONFIG(tooltip)
        self.invertDirectionBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Invert the page turn direction.</p><p>Usually used with right to left manga but you want to page turn left to right. Spread splitting would still be right to left in this case.</p><p>Will break various features like landscape mode order.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.invertDirectionBox.setText(QCoreApplication.translate("mainWindow", u"Invert Direction", None))
#if QT_CONFIG(tooltip)
        self.qualityBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - 4 panels<br/></span>Zoom each corner separately.</p><p style='white-space:pre'><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - 2 panels<br/></span>Zoom only the top and bottom of the page.</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - 4 high-quality panels<br/></span>Zoom each corner separately. Try to increase the quality of magnification. Check wiki for more details.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.qualityBox.setText(QCoreApplication.translate("mainWindow", u"Panel View 4/2/HQ", None))
#if QT_CONFIG(tooltip)
        self.noRotateBox.setToolTip(QCoreApplication.translate("mainWindow", u"Do not rotate double page spreads in spread splitter option.", None))
#endif // QT_CONFIG(tooltip)
        self.noRotateBox.setText(QCoreApplication.translate("mainWindow", u"No rotate", None))
#if QT_CONFIG(tooltip)
        self.mangaBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Enable right-to-left reading.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.mangaBox.setText(QCoreApplication.translate("mainWindow", u"Right-to-left (manga)", None))
#if QT_CONFIG(tooltip)
        self.defaultOutputFolderBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Unchecked - next to source<br/></span>Place output files next to source files</p><p><span style=\" font-weight:600; text-decoration: underline;\">Indeterminate - folder next to source<br/></span>Place output files in a folder next to source files</p><p><span style=\" font-weight:600; text-decoration: underline;\">Checked - Custom<br/></span>Place output files in custom directory specified by right button</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.defaultOutputFolderBox.setText(QCoreApplication.translate("mainWindow", u"Output Folder", None))
#if QT_CONFIG(tooltip)
        self.defaultOutputFolderButton.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Use this to select the default output directory.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.defaultOutputFolderButton.setText("")
#if QT_CONFIG(tooltip)
        self.autoLevelBox.setToolTip(QCoreApplication.translate("mainWindow", u"Makes the most common dark ink pure black. Helpful when text looks gray.", None))
#endif // QT_CONFIG(tooltip)
        self.autoLevelBox.setText(QCoreApplication.translate("mainWindow", u"Extreme Black Point", None))
#if QT_CONFIG(tooltip)
        self.lightnovelBox.setToolTip(QCoreApplication.translate("mainWindow", u"Only resize images and preserve original file structure.\n"
"\n"
"Ignores most options besides JPEG quality, color mode, output folder.", None))
#endif // QT_CONFIG(tooltip)
        self.lightnovelBox.setText(QCoreApplication.translate("mainWindow", u"Light novel mode", None))
#if QT_CONFIG(tooltip)
        self.pngLegacyBox.setToolTip(QCoreApplication.translate("mainWindow", u"Use a more compatible 8 bit PNG instead of 4 bit.", None))
#endif // QT_CONFIG(tooltip)
        self.pngLegacyBox.setText(QCoreApplication.translate("mainWindow", u"PNG Legacy Mode", None))
#if QT_CONFIG(tooltip)
        self.ebokBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Force Kindle MOBI to be be tagged as EBOK instead of PDOC.</p><p>This may cause USB loaded books to be deleted if you go online after a month offline.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.ebokBox.setText(QCoreApplication.translate("mainWindow", u"Force EBOK", None))
#if QT_CONFIG(tooltip)
        self.noQuantizeBox.setToolTip(QCoreApplication.translate("mainWindow", u"Don't quantize PNG images to 16 colors (4 bit)\n"
"\n"
"This will double file size but preserve all 256 colors (8 bit).\n"
"\n"
"Eink only has 16 shades of gray so you probably don't want this.", None))
#endif // QT_CONFIG(tooltip)
        self.noQuantizeBox.setText(QCoreApplication.translate("mainWindow", u"No Quantize", None))
#if QT_CONFIG(tooltip)
        self.keepComicInfoBox.setToolTip(QCoreApplication.translate("mainWindow", u"Keep any original ComicInfo.xml files.\n"
"\n"
"Keeping this file may crash some readers like the Kobo native CBZ reader.", None))
#endif // QT_CONFIG(tooltip)
        self.keepComicInfoBox.setText(QCoreApplication.translate("mainWindow", u"Keep ComicInfo.xml", None))
#if QT_CONFIG(tooltip)
        self.editorButton.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Shift+Click to edit directory.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.editorButton.setText(QCoreApplication.translate("mainWindow", u"Metadata Editor", None))
        self.anilistButton.setText(QCoreApplication.translate("mainWindow", u"Find manga on AniList", None))
        self.linkedInButton.setText(QCoreApplication.translate("mainWindow", u"Connect with Isaiah Lee on LinkedIn", None))
        self.labelSpreadsButton.setText(QCoreApplication.translate("mainWindow", u"Label Spreads", None))
#if QT_CONFIG(tooltip)
        self.chunkSizeWidget.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Warning: chunk size greater than default may cause<br/>performance/battery issues, especially on older devices.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.chunkSizeLabel.setText(QCoreApplication.translate("mainWindow", u"Chunk size MB:", None))
        self.chunkSizeWarnLabel.setText(QCoreApplication.translate("mainWindow", u"Greater than default may cause performance issues on older ereaders.", None))
        self.gammaLabel.setText(QCoreApplication.translate("mainWindow", u"Gamma: Auto", None))
        self.jpegQualityLabel.setText(QCoreApplication.translate("mainWindow", u"JPEG Quality:", None))
#if QT_CONFIG(tooltip)
        self.jobList.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p>Double click on source to open it in metadata editor.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.hLabel.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Resolution of the target device.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.hLabel.setText(QCoreApplication.translate("mainWindow", u"Custom height:", None))
#if QT_CONFIG(tooltip)
        self.widthBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Resolution of the target device.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.wLabel.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Resolution of the target device.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.wLabel.setText(QCoreApplication.translate("mainWindow", u"Custom width:", None))
#if QT_CONFIG(tooltip)
        self.heightBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Resolution of the target device.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.deviceBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Target device.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.clearButton.setText(QCoreApplication.translate("mainWindow", u"Clear list", None))
#if QT_CONFIG(tooltip)
        self.directoryButton.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Add directory containing JPG, PNG or GIF files to queue.<br/><span style=\" font-weight:600;\">CBR, CBZ and CB7 files inside will not be processed!</span></p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.directoryButton.setText(QCoreApplication.translate("mainWindow", u"Add input folder(s)", None))
#if QT_CONFIG(tooltip)
        self.convertButton.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Shift+Click to select the output directory for this list.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.convertButton.setText(QCoreApplication.translate("mainWindow", u"Convert", None))
#if QT_CONFIG(tooltip)
        self.fileButton.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Add CBR, CBZ, CB7 or PDF file to queue.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.fileButton.setText(QCoreApplication.translate("mainWindow", u"Add input file(s)", None))
#if QT_CONFIG(tooltip)
        self.formatBox.setToolTip(QCoreApplication.translate("mainWindow", u"<html><head/><body><p style='white-space:pre'>Output format.</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
    # retranslateUi
