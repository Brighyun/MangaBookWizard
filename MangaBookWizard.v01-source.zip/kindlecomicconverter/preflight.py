"""Preflight checks for EPUB and page-image problems that can render blank pages."""

from __future__ import annotations

from dataclasses import dataclass, field
from io import BytesIO
from pathlib import Path
import os
import posixpath
import re
import xml.etree.ElementTree as ET
from urllib.parse import unquote, urlsplit
from zipfile import BadZipFile, ZIP_STORED, ZipFile

from PIL import Image, UnidentifiedImageError

from .shared import IMAGE_TYPES

KINDLE_RISK_PROFILES = {"KCS", "KS", "KS3", "KSCS", "KS1240", "KS1324", "KS1860", "KS1920"}
KINDLE_OUTPUTS = {"MOBI", "EPUB", "KFX", "MOBI-PASSTHROUGH"}
MAX_IMAGE_PIXELS_WARNING = 40_000_000
MAX_IMAGE_BYTES_WARNING = 16 * 1024 * 1024


@dataclass(frozen=True)
class PreflightIssue:
    severity: str
    code: str
    message: str
    location: str = ""

    def display(self) -> str:
        location = f" ({self.location})" if self.location else ""
        return f"{self.severity.upper()}: {self.message}{location}"


@dataclass
class PreflightReport:
    source: str
    issues: list[PreflightIssue] = field(default_factory=list)
    pages_checked: int = 0
    images_checked: int = 0

    def add(self, severity: str, code: str, message: str, location: str = "") -> None:
        issue = PreflightIssue(severity, code, message, location)
        if issue not in self.issues:
            self.issues.append(issue)

    @property
    def errors(self) -> list[PreflightIssue]:
        return [issue for issue in self.issues if issue.severity == "error"]

    @property
    def warnings(self) -> list[PreflightIssue]:
        return [issue for issue in self.issues if issue.severity == "warning"]

    @property
    def ok(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        detail = f"{self.pages_checked} page(s), {self.images_checked} image(s) checked"
        if self.errors:
            return f"Safety scan found {len(self.errors)} blocking and {len(self.warnings)} possible issue(s); {detail}."
        if self.warnings:
            return f"Safety scan passed with {len(self.warnings)} possible issue(s); {detail}."
        return f"Safety scan passed; {detail}."

    def formatted(self, limit: int = 12) -> str:
        lines = [issue.display() for issue in self.issues[:limit]]
        if len(self.issues) > limit:
            lines.append(f"…and {len(self.issues) - limit} more issue(s).")
        return "\n".join(lines)


def scan_source(source: str, profile: str = "", output_format: str = "") -> PreflightReport:
    """Inspect a supported source without mutating it."""
    path = Path(source)
    if path.is_dir():
        return scan_image_tree(path, profile, output_format)
    suffix = path.suffix.lower()
    if suffix == ".epub":
        return scan_epub(path, profile, output_format)
    if suffix in {".cbz", ".zip"}:
        return scan_zip_images(path, profile, output_format)
    if suffix in IMAGE_TYPES:
        report = PreflightReport(str(path))
        _check_image_file(path, report, profile, output_format)
        return report

    report = PreflightReport(str(path))
    report.add(
        "info",
        "DEFERRED_SCAN",
        "This format is scanned after its pages are extracted during conversion.",
        path.name,
    )
    return report


def scan_image_tree(source: str | Path, profile: str = "", output_format: str = "") -> PreflightReport:
    path = Path(source)
    report = PreflightReport(str(path))
    images = sorted(
        item for item in path.rglob("*")
        if item.is_file() and item.suffix.lower() in IMAGE_TYPES
    )
    if not images:
        report.add("error", "NO_IMAGES", "No supported page images were found.", path.name)
        return report
    for image_path in images:
        _check_image_file(image_path, report, profile, output_format, path)
    _add_png_device_warning(report, images, profile, output_format)
    _add_device_format_warning(report, profile, output_format)
    return report


def scan_zip_images(source: str | Path, profile: str = "", output_format: str = "") -> PreflightReport:
    path = Path(source)
    report = PreflightReport(str(path))
    try:
        with ZipFile(path) as archive:
            bad_member = archive.testzip()
            if bad_member:
                report.add("error", "ZIP_CRC", "The archive contains damaged data.", bad_member)
            names = [name for name in archive.namelist() if Path(name).suffix.lower() in IMAGE_TYPES]
            if not names:
                report.add("error", "NO_IMAGES", "No supported page images were found in the archive.", path.name)
                return report
            png_count = 0
            for name in names:
                if Path(name).suffix.lower() == ".png":
                    png_count += 1
                try:
                    data = archive.read(name)
                except (BadZipFile, KeyError, RuntimeError) as exc:
                    report.add("error", "IMAGE_READ", f"Page image cannot be read: {exc}", name)
                    continue
                _check_image_bytes(data, name, report)
            if png_count:
                _add_png_device_warning(report, [Path(f"page-{i}.png") for i in range(png_count)], profile, output_format)
            _add_device_format_warning(report, profile, output_format)
    except (BadZipFile, OSError, RuntimeError) as exc:
        report.add("error", "BAD_ARCHIVE", f"The archive cannot be opened: {exc}", path.name)
    return report


def scan_epub(source: str | Path, profile: str = "", output_format: str = "") -> PreflightReport:
    """Validate container, manifest, spine, page references, and image payloads."""
    path = Path(source)
    report = PreflightReport(str(path))
    try:
        with ZipFile(path) as archive:
            bad_member = archive.testzip()
            if bad_member:
                report.add("error", "ZIP_CRC", "The EPUB contains damaged data.", bad_member)

            infos = archive.infolist()
            names = {info.filename for info in infos if not info.is_dir()}
            lower_names = {name.lower(): name for name in names}
            if not infos:
                report.add("error", "EMPTY_EPUB", "The EPUB archive is empty.", path.name)
                return report
            if "mimetype" not in names:
                report.add("warning", "MISSING_MIMETYPE", "EPUB mimetype file is missing.", "mimetype")
            else:
                mimetype = archive.read("mimetype").decode("ascii", "replace").strip()
                if mimetype != "application/epub+zip":
                    report.add("warning", "BAD_MIMETYPE", "EPUB mimetype has an unexpected value.", "mimetype")
                mimetype_info = archive.getinfo("mimetype")
                if infos[0].filename != "mimetype" or mimetype_info.compress_type != ZIP_STORED:
                    report.add("warning", "MIMETYPE_PACKAGING", "EPUB mimetype should be the first uncompressed file.", "mimetype")

            if "META-INF/encryption.xml" in names:
                _check_encryption(archive.read("META-INF/encryption.xml"), report)

            opf_name = _find_opf_name(archive, names, report)
            if not opf_name:
                return report
            try:
                opf_root = ET.fromstring(archive.read(opf_name))
            except (ET.ParseError, KeyError) as exc:
                report.add("error", "BAD_OPF", f"The EPUB package document is invalid: {exc}", opf_name)
                return report

            manifest: dict[str, tuple[str, str]] = {}
            for item in opf_root.findall(".//{*}manifest/{*}item"):
                item_id = item.attrib.get("id", "")
                href = item.attrib.get("href", "")
                media_type = item.attrib.get("media-type", "")
                if item_id and href:
                    manifest[item_id] = (_resolve_href(opf_name, href), media_type)

            if not manifest:
                report.add("error", "EMPTY_MANIFEST", "The EPUB manifest is empty.", opf_name)

            spine_refs = [
                item.attrib.get("idref", "")
                for item in opf_root.findall(".//{*}spine/{*}itemref")
                if item.attrib.get("idref")
            ]
            if not spine_refs:
                report.add("error", "EMPTY_SPINE", "The EPUB has no reading-order entries.", opf_name)

            checked_images: set[str] = set()
            png_count = 0
            for idref in spine_refs:
                if idref not in manifest:
                    report.add("error", "MISSING_SPINE_ITEM", "A reading-order item is absent from the manifest.", idref)
                    continue
                page_name, _ = manifest[idref]
                actual_page = _actual_name(page_name, names, lower_names, report)
                if not actual_page:
                    report.add("error", "MISSING_PAGE", "A reading-order document is missing.", page_name)
                    continue
                report.pages_checked += 1
                try:
                    page_data = archive.read(actual_page)
                except (BadZipFile, KeyError, RuntimeError) as exc:
                    report.add("error", "PAGE_READ", f"A reading-order document cannot be read: {exc}", actual_page)
                    continue
                references, has_visible_text = _page_references(page_data, actual_page, report)
                if not references and not has_visible_text:
                    report.add("warning", "BLANK_SPINE_PAGE", "A reading-order document appears to contain no visible content.", actual_page)
                for reference in references:
                    image_name = _resolve_href(actual_page, reference)
                    actual_image = _actual_name(image_name, names, lower_names, report)
                    if not actual_image:
                        report.add("error", "MISSING_IMAGE", "A page references an image that is missing.", image_name)
                        continue
                    if actual_image in checked_images:
                        continue
                    checked_images.add(actual_image)
                    if Path(actual_image).suffix.lower() == ".png":
                        png_count += 1
                    try:
                        _check_image_bytes(archive.read(actual_image), actual_image, report)
                    except (BadZipFile, KeyError, RuntimeError) as exc:
                        report.add("error", "IMAGE_READ", f"A referenced image cannot be read: {exc}", actual_image)

            # Validate image assets even if a malformed page forgot to reference them.
            for _, (asset_name, media_type) in manifest.items():
                if not media_type.startswith("image/") or asset_name in checked_images:
                    continue
                actual_image = _actual_name(asset_name, names, lower_names, report)
                if not actual_image:
                    report.add("error", "MISSING_MANIFEST_ASSET", "An image listed in the manifest is missing.", asset_name)
                    continue
                checked_images.add(actual_image)
                if Path(actual_image).suffix.lower() == ".png":
                    png_count += 1
                try:
                    _check_image_bytes(archive.read(actual_image), actual_image, report)
                except (BadZipFile, KeyError, RuntimeError) as exc:
                    report.add("error", "IMAGE_READ", f"A manifest image cannot be read: {exc}", actual_image)

            # CSS can introduce page backgrounds that are invisible to XHTML-only checks.
            for _, (asset_name, media_type) in manifest.items():
                if media_type != "text/css":
                    continue
                actual_css = _actual_name(asset_name, names, lower_names, report)
                if not actual_css:
                    report.add("error", "MISSING_STYLESHEET", "A stylesheet listed in the manifest is missing.", asset_name)
                    continue
                css = archive.read(actual_css).decode("utf-8", "replace")
                for css_href in re.findall(r"url\(\s*['\"]?([^'\")]+)", css, re.IGNORECASE):
                    if css_href.startswith("data:"):
                        continue
                    resource_name = _resolve_href(actual_css, css_href)
                    actual_resource = _actual_name(resource_name, names, lower_names, report)
                    if not actual_resource:
                        report.add("error", "MISSING_CSS_RESOURCE", "A stylesheet references a missing resource.", resource_name)
                        continue
                    if Path(actual_resource).suffix.lower() in IMAGE_TYPES and actual_resource not in checked_images:
                        checked_images.add(actual_resource)
                        _check_image_bytes(archive.read(actual_resource), actual_resource, report)

            if not checked_images and not report.errors:
                report.add("info", "TEXT_EPUB", "No page images were found; this appears to be a text-focused EPUB.", path.name)
            if png_count:
                _add_png_device_warning(report, [Path(f"page-{i}.png") for i in range(png_count)], profile, output_format)
            _add_device_format_warning(report, profile, output_format)
    except (BadZipFile, OSError, RuntimeError) as exc:
        report.add("error", "BAD_EPUB", f"The EPUB cannot be opened: {exc}", path.name)
    return report


def _find_opf_name(archive: ZipFile, names: set[str], report: PreflightReport) -> str:
    container_name = "META-INF/container.xml"
    if container_name in names:
        try:
            container = ET.fromstring(archive.read(container_name))
            rootfile = container.find(".//{*}rootfile")
            if rootfile is not None:
                opf_name = rootfile.attrib.get("full-path", "")
                if opf_name in names:
                    return opf_name
                report.add("error", "MISSING_OPF", "The package document named by container.xml is missing.", opf_name)
                return ""
            report.add("error", "NO_ROOTFILE", "container.xml does not name a package document.", container_name)
            return ""
        except (ET.ParseError, KeyError) as exc:
            report.add("error", "BAD_CONTAINER", f"container.xml is invalid: {exc}", container_name)
            return ""

    report.add("warning", "MISSING_CONTAINER", "META-INF/container.xml is missing; attempting recovery.", container_name)
    candidates = sorted(name for name in names if name.lower().endswith(".opf"))
    if len(candidates) == 1:
        return candidates[0]
    report.add("error", "MISSING_OPF", "A unique EPUB package document could not be found.", path_name(report.source))
    return ""


def _check_encryption(data: bytes, report: PreflightReport) -> None:
    """Allow standard font obfuscation but block content encryption/DRM."""
    location = "META-INF/encryption.xml"
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        report.add("error", "BAD_ENCRYPTION_XML", f"Encryption metadata is invalid: {exc}", location)
        return
    algorithms = {
        method.attrib.get("Algorithm", "")
        for method in root.findall(".//{*}EncryptionMethod")
    }
    font_obfuscation = {
        "http://www.idpf.org/2008/embedding",
        "http://ns.adobe.com/pdf/enc#RC",
    }
    unsupported = sorted(algorithm for algorithm in algorithms if algorithm not in font_obfuscation)
    if unsupported or not algorithms:
        report.add("error", "ENCRYPTED_EPUB", "Encrypted or DRM-protected EPUB content cannot be safely converted.", location)
    else:
        report.add("info", "OBFUSCATED_FONTS", "The EPUB uses supported embedded-font obfuscation.", location)


def _page_references(data: bytes, page_name: str, report: PreflightReport) -> tuple[list[str], bool]:
    references: list[str] = []
    visible_text = ""
    try:
        root = ET.fromstring(data)
        visible_text = " ".join(part.strip() for part in root.itertext() if part.strip())
        for element in root.iter():
            tag = element.tag.rsplit("}", 1)[-1].lower()
            if tag not in {"img", "image", "object", "embed", "video"}:
                continue
            for key, value in element.attrib.items():
                attribute = key.rsplit("}", 1)[-1].lower()
                if attribute in {"src", "href", "data", "poster"} and value and not value.startswith("data:"):
                    references.append(value)
    except ET.ParseError as exc:
        text = data.decode("utf-8", "replace")
        references.extend(re.findall(r"<(?:img|image|object|embed|video)[^>]+(?:src|href|data|poster)=[\"']([^\"']+)", text, re.IGNORECASE))
        visible_text = re.sub(r"<[^>]+>", " ", text)
        report.add("warning", "MALFORMED_PAGE", f"A reading-order document is not valid XML: {exc}", page_name)
    return references, bool(re.sub(r"\s+", "", visible_text))


def _resolve_href(base_name: str, href: str) -> str:
    path = unquote(urlsplit(href).path).replace("\\", "/")
    resolved = posixpath.normpath(posixpath.join(posixpath.dirname(base_name), path))
    return resolved.lstrip("/")


def _actual_name(name: str, names: set[str], lower_names: dict[str, str], report: PreflightReport) -> str:
    if name in names:
        return name
    case_match = lower_names.get(name.lower())
    if case_match:
        report.add("warning", "CASE_MISMATCH", "A resource reference differs in letter case and may fail on some readers.", name)
        return case_match
    return ""


def _check_image_file(
    image_path: Path,
    report: PreflightReport,
    profile: str,
    output_format: str,
    relative_to: Path | None = None,
) -> None:
    location = str(image_path.relative_to(relative_to)) if relative_to else image_path.name
    try:
        if image_path.stat().st_size == 0:
            report.add("error", "EMPTY_IMAGE", "A page image is empty.", location)
            return
        with image_path.open("rb") as image_file:
            data = image_file.read()
        _check_image_bytes(data, location, report)
    except OSError as exc:
        report.add("error", "IMAGE_READ", f"A page image cannot be read: {exc}", location)


def _check_image_bytes(data: bytes, location: str, report: PreflightReport) -> None:
    if not data:
        report.add("error", "EMPTY_IMAGE", "A page image is empty.", location)
        return
    if Path(location).suffix.lower() == ".svg":
        try:
            root = ET.fromstring(data)
            if root.tag.rsplit("}", 1)[-1].lower() != "svg":
                raise ET.ParseError("root element is not SVG")
            drawable = {"path", "rect", "circle", "ellipse", "line", "polyline", "polygon", "image", "text", "use"}
            if not any(element.tag.rsplit("}", 1)[-1].lower() in drawable for element in root.iter()):
                report.add("warning", "BLANK_SVG", "An SVG page image has no visible drawing elements.", location)
            report.images_checked += 1
        except ET.ParseError as exc:
            report.add("error", "CORRUPT_IMAGE", f"An SVG image is invalid: {exc}", location)
        return
    try:
        with Image.open(BytesIO(data)) as verifier:
            verifier.verify()
        with Image.open(BytesIO(data)) as opened:
            width, height = opened.size
            image_format = opened.format or "unknown"
            if width <= 1 or height <= 1:
                report.add("error", "INVALID_DIMENSIONS", "A page image has unusable dimensions.", location)
            if width * height > MAX_IMAGE_PIXELS_WARNING:
                report.add("warning", "HUGE_DIMENSIONS", f"A {width}×{height} page may exceed an e-reader's decoder limits.", location)
            if len(data) > MAX_IMAGE_BYTES_WARNING:
                report.add("warning", "HUGE_IMAGE", f"A {len(data) // 1024 // 1024} MB page may exceed an e-reader's decoder limits.", location)
            blank_reason = _blank_reason(opened)
            if blank_reason:
                report.add("warning", "BLANK_IMAGE", f"A page image appears blank ({blank_reason}).", location)
            if image_format.upper() not in {"JPEG", "PNG", "GIF", "WEBP", "JPEG2000", "AVIF"}:
                report.add("warning", "UNUSUAL_IMAGE", f"Image format {image_format} may not be supported by the target reader.", location)
        report.images_checked += 1
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError) as exc:
        report.add("error", "CORRUPT_IMAGE", f"A page image cannot be decoded: {exc}", location)


def _blank_reason(opened: Image.Image) -> str:
    sample = opened.copy()
    sample.thumbnail((256, 256))
    if "A" in sample.getbands():
        rgba = sample.convert("RGBA")
        background = Image.new("RGBA", rgba.size, "white")
        sample = Image.alpha_composite(background, rgba).convert("L")
    else:
        sample = sample.convert("L")
    extrema = sample.getextrema()
    if extrema[1] - extrema[0] <= 2:
        return "nearly uniform"
    histogram = sample.histogram()
    pixels = max(1, sample.width * sample.height)
    if sum(histogram[250:]) / pixels >= 0.998:
        return "almost entirely white"
    if sum(histogram[:6]) / pixels >= 0.998:
        return "almost entirely black"
    return ""


def _add_png_device_warning(
    report: PreflightReport,
    images: list[Path],
    profile: str,
    output_format: str,
) -> None:
    png_count = sum(1 for image in images if image.suffix.lower() == ".png")
    normalized_format = output_format.split("+", 1)[0]
    if png_count and profile in KINDLE_RISK_PROFILES and normalized_format in KINDLE_OUTPUTS:
        report.add(
            "warning",
            "KINDLE_PNG_RISK",
            f"{png_count} PNG page(s) may render blank on Scribe or Colorsoft; JPEG output is safer.",
            profile,
        )


def _add_device_format_warning(report: PreflightReport, profile: str, output_format: str) -> None:
    normalized_format = output_format.split("+", 1)[0]
    if profile in {"KCS", "KSCS"} and normalized_format in KINDLE_OUTPUTS:
        report.add(
            "warning",
            "COLORSOFT_FIRMWARE_RISK",
            "Colorsoft firmware can intermittently show blank pages even when the book passes every structural check.",
            profile,
        )


def path_name(value: str) -> str:
    return os.path.basename(value.rstrip(os.sep))
