# Help & FAQ

## I do not know anything about e-book formats. What should I do?

Use the default choices:

1. Drop your manga or book into the large box.
2. Pick the Kindle or reader model you own.
3. Click **Make my book**.

The finished file is saved beside the original unless you choose a save folder.

## Which Mac download should I use?

- Choose **`MangaBookWizard.v01-macOS-ARM64`** if your Mac has an M-series chip.
- Choose **`MangaBookWizard.v01-macOS-Intel-x86_64`** if About This Mac says the processor is Intel.

Both builds require **macOS Monterey 12 or newer**. They contain the same MangaBookWizard features; only the processor type is different.

## What can I drop into the app?

You can use EPUB, PDF, CBZ, ZIP, or a folder containing JPG/PNG page images. CBR, RAR, CB7, and 7Z also work after you install [7-Zip from its official website](https://www.7-zip.org/).

A folder should represent one book or chapter and should contain its pages in reading order. Names such as `001.jpg`, `002.jpg`, and `003.jpg` make that order clear.

## Which finished-file choice should I use?

- **Kindle manga — best fit (MOBI):** choose this for manga/comic page images that you plan to copy to a Kindle by USB.
- **Send to Kindle — EPUB:** choose this for Amazon's Send to Kindle service.
- **EPUB book → older Kindle (MOBI):** choose this for an ordinary EPUB novel or book when you specifically need MOBI.
- **EPUB:** choose this for most non-Kindle e-readers and reading apps.
- **CBZ:** choose this when your comic reader already supports comic archives.
- **PDF:** choose this for a portable fixed-page copy.

## Why does MOBI ask me to install something?

MOBI uses the conversion helper included with [Amazon Kindle Previewer](https://kdp.amazon.com/en_US/help/topic/G202131170). Install Kindle Previewer, close and reopen the Wizard, then try again.

If you do not need MOBI, choose an EPUB, CBZ, or PDF option instead.

## My Kindle still shows a blank page. What should I try?

1. Make sure you chose the exact or closest Kindle model.
2. Leave the page-image choices at their defaults.
3. Try **Send to Kindle — EPUB** instead of MOBI.
4. For a Colorsoft or Scribe, avoid forcing PNG in **More choices**.
5. Remove the book from the device, restart the Kindle, and copy/send it again.

## Where is my finished book?

By default, it is beside the source file. Turn on **Save finished files in my chosen folder** to keep every result in one location.

## Can I join several chapters into one volume?

Yes. Add the chapters in the desired order, open **More choices**, and turn on **Join selected chapters into one book**.

## What is “Mark two-page artwork”?

It lets you identify pages that should stay together as a wide spread. Most books do not need it.

## Where can I find something new to read?

- [AniList](https://anilist.co/) for recommendations and tracking.
- [r/manga](https://www.reddit.com/r/manga/) for manga discussion.
- [r/kindle](https://www.reddit.com/r/kindle/) for Kindle help.
- [r/MangaCollectors](https://www.reddit.com/r/MangaCollectors/) for collecting and shelf ideas.

These are discovery/community links, not places to download books from this app.

## Who maintains this friendly edition?

[Follow or connect with Isaiah Lee on LinkedIn](https://www.linkedin.com/in/brigh-yun-lee-01130025b/).

You can also [support MangaBookWizard on Buy Me a Coffee](https://buymeacoffee.com/mangabookwizard). Support is optional, and every conversion feature remains free.

## Can I convert any book I find online?

Only convert books you own or have permission to use. The Wizard does not remove DRM.
