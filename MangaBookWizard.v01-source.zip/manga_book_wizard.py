#!/usr/bin/env python3
"""Desktop launcher for MangaBookWizard."""

# The path-discovery behavior below is derived from the ISC-licensed engine.
# Copyright notices and permission terms are preserved in LICENSE.txt.

import os
import platform
import sys
from multiprocessing import freeze_support, set_start_method
from pathlib import Path


def modify_path():
    """Make optional Kindle Previewer and archive helpers discoverable."""
    if platform.system() == 'Darwin':
        mac_paths = [
            '/Applications/Kindle Comic Creator/Kindle Comic Creator.app/Contents/MacOS',
            '/Applications/Kindle Previewer 3.app/Contents/lib/fc/bin/',
        ]
        if getattr(sys, 'frozen', False):
            mac_paths.extend(['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin'])
            os.chdir(os.path.dirname(os.path.abspath(sys.executable)))
        else:
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
        os.environ['PATH'] += os.pathsep + os.pathsep.join(mac_paths)
    elif platform.system() == 'Linux':
        if getattr(sys, 'frozen', False):
            os.environ['PATH'] += os.pathsep + os.pathsep.join([
                str(Path.home() / '.local' / 'bin'),
                '/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin',
            ])
            os.chdir(os.path.dirname(os.path.abspath(sys.executable)))
        else:
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
    elif platform.system() == 'Windows':
        win_paths = [
            os.path.expandvars(r'%LOCALAPPDATA%\Amazon\KC2'),
            os.path.expandvars(r'%LOCALAPPDATA%\Amazon\Kindle Previewer 3\lib\fc\bin'),
            os.path.expandvars(r'%UserProfile%\Kindle Previewer 3\lib\fc\bin'),
            r'C:\Apps\Kindle Previewer 3\lib\fc\bin',
            r'D:\Apps\Kindle Previewer 3\lib\fc\bin',
            r'E:\Apps\Kindle Previewer 3\lib\fc\bin',
            r'C:\Program Files\7-Zip',
            r'D:\Program Files\7-Zip',
            r'E:\Program Files\7-Zip',
        ]
        os.environ['PATH'] += os.pathsep + os.pathsep.join(win_paths)
        os.chdir(os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__)))


def main():
    if sys.version_info < (3, 8):
        raise SystemExit('MangaBookWizard requires Python 3.8 or newer.')
    modify_path()
    set_start_method('spawn')
    freeze_support()
    from kindlecomicconverter.startup import start
    start()


if __name__ == '__main__':
    main()
