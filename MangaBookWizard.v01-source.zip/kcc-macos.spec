# -*- mode: python ; coding: utf-8 -*-
# macOS GUI build, used by setup.py build_binary

import os
import sys

sys.path.insert(0, SPECPATH)
from kindlecomicconverter import __version__


MINIMUM_MACOS_VERSION = os.getenv('MACOSX_DEPLOYMENT_TARGET', '12.0')


a = Analysis(
    ['manga_book_wizard.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['_cffi_backend'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='MangaBookWizard',
    debug=False,
    bootloader_ignore_signals=False,
    strip=True,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['icons/manga-book-wizard.icns'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=True,
    upx=True,
    upx_exclude=[],
    name='MangaBookWizard',
)
app = BUNDLE(
    coll,
    name='MangaBookWizard.app',
    icon='icons/manga-book-wizard.icns',
    bundle_identifier='app.mangabookwizard.desktop',
    info_plist={
        'CFBundleShortVersionString': __version__,
        'CFBundleVersion': __version__,
        'LSMinimumSystemVersion': MINIMUM_MACOS_VERSION,
    },
)
